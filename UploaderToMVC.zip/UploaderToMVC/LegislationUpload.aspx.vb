﻿Imports System.IO

Partial Class LegislationUpload
    Inherits System.Web.UI.Page
    Dim XmlFile As String
    Dim ClsUpload As New ClsLegislationUpload("ConnectionString")
    Dim XmlExit As Boolean
    Dim DirPath As String
    Protected Sub btnUpload_Click(sender As Object, e As EventArgs) Handles btnUpload.Click
        Dim FlgUpload As String = ""
        Dim FlgSectionUpload As String = ""
        Dim flgDefinitionUpload As String = ""
        Dim lstImg As IList(Of String)
        Dim StrImg As String = ""
        lblcheckupload.Text = ""
        If fu_file.HasFile Then   'xmlFiles\legislation\

            Dim FileExtension As String = Path.GetExtension(fu_file.FileName)
            If FileExtension = ".xml" Then
                DirPath = "C:\eLaw\eLaw_Data_Files\eLaw_Data_Files\legislation\" + fu_file.FileName
                ClsLegislationUpload.FileXmlToClass = DirPath
                ClsLegislationUpload.FileNameToClass = fu_file.FileName
                XmlFile = fu_file.FileName
                XmlExit = ClsUpload.IsXmlExit(DirPath)
                If XmlExit = True Then
                    My.Computer.FileSystem.DeleteFile(DirPath)
                    ' File.Delete(DirPath)
                End If
                fu_file.SaveAs(DirPath)
                FlgUpload = ClsUpload.UploadxmlFile()
                FlgSectionUpload = ClsUpload.UploadSection()
                flgDefinitionUpload = ClsUpload.UploadDefinition()
                lstImg = ClsUpload.GetImgTag()
                lblcheckupload.Text = "Legislation : " & FlgUpload & "<br>File Name : " & XmlFile & "<br>Sections :" & FlgSectionUpload & "<br>Definition : " & flgDefinitionUpload
                If lstImg.Count Then
                    StrImg = String.Join(" , ", lstImg.ToArray())
                    lblcheckupload.Text &= "<br><br><br>Images avaiable and need to be upload: <br>" & StrImg
                    UploadPhoto.Visible = True
                Else
                    lblcheckupload.Text &= "<br><br><br> No Images avaiable For This File <br>" & StrImg
                    UploadPhoto.Visible = False
                End If
                ClsLegislationUpload.FileXmlToClass = ""
                ClsLegislationUpload.FileNameToClass = ""
                fu_file.Dispose()
                fu_file.PostedFile.InputStream.Flush()
                fu_file.FileContent.Dispose()
                fu_file.FileContent.Close()
                ClsUpload = Nothing
                DirPath = ""
                FileExtension = ""
            Else
                lblcheckupload.Text = "Upload only file as Xml "
            End If

        Else
            lblcheckupload.Text = "Please Select files to upload"
        End If
        
    End Sub

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        fu_file.Attributes.Clear()
        
    End Sub

    Protected Sub Button1_Click(sender As Object, e As System.EventArgs) Handles Button1.Click
        Dim filepath As String '= "C:\Elaw\web\elaw\12-9-2013\xmlfiles\legislation\legislation"
        filepath = "C:\eLaw\eLaw-Images\LegImg"
        ' Dim AlaternatePath As String = "C:\Elaw\web\elaw\12-9-2013\Legislation"

        Dim uploadedFiles As HttpFileCollection = Request.Files
        Dim FileExtension As String
        Dim ImgName As String = ""
        Span1.Text = String.Empty
        For i As Integer = 0 To uploadedFiles.Count - 1
            Dim userPostedFile As HttpPostedFile = uploadedFiles(i)
            Try
                If userPostedFile.ContentLength > 0 Then
                    FileExtension = Path.GetExtension(userPostedFile.FileName)
                    ImgName = Path.GetFileName(userPostedFile.FileName)
                    Span1.Text += "<u>File #" & (i + 1) & "</u><br>"
                    Span1.Text += "File Content Type: " & userPostedFile.ContentType & "  --" & FileExtension & "<br>"
                    Span1.Text += "File Size: " & userPostedFile.ContentLength & "kb<br>"
                    Span1.Text += "File Name: " & userPostedFile.FileName & "<br>"
                    If (FileExtension = ".png" Or FileExtension = ".jpg" Or FileExtension = ".jpeg") And (ImgName.Contains("MY_") = True Or ImgName.Contains("_PU_") = True)  Then
                        userPostedFile.SaveAs(filepath & "\" & Path.GetFileName(userPostedFile.FileName))
                        ' userPostedFile.SaveAs(AlaternatePath & "\" & Path.GetFileName(userPostedFile.FileName))

                        Span1.Text &= "Imgage Uploaded successfully"
                    Else
                        Span1.Text &= "Only Imgage file allowed to upload"
                    End If
                    'Span1.Text &= "Location where saved: " & filepath + "\" & Path.GetFileName(userPostedFile.FileName) & "<p>"
                End If
            Catch Ex As Exception
                Span1.Text &= "Error: <br>" & Ex.Message
            End Try
        Next


    End Sub
End Class
