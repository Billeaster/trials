﻿Imports System.IO
Imports System.XML

Partial Class CasesUpload
    Inherits System.Web.UI.Page
    Dim XmlFile As String
    Dim ClsUpload As New ClsCasesUpload("ConnectionString")
    Dim XmlExit As Boolean
    Dim DirPath As String
    Dim PdfPath As String = ""


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Try

        Catch ex As Exception
            ' My.Computer.FileSystem.WriteAllText("C:\Elaw\Calculate_Execution_Timetest.txt", String.Join(vbCrLf, ex.Message), False)
        End Try
    End Sub

    Protected Sub btnUpload_Click(sender As Object, e As EventArgs) Handles btnUpload.Click

        Dim FlgUploadJudge As String = ""
        Dim FlgUploadCouncel As String = ""


        Dim FlgUpload As String = ""
        Dim FlgCasesReferred As String = ""
        Dim flgLegislationReferred As String = ""
        Dim lstImg As IList(Of String)
        Dim StrImg As String = ""
        Dim TempDir As String = "C:\eLaw\eLaw_Data_Files\eLaw_Data_Files\cases\"   ' Server.MapPath("~/cases/")
        PdfPath = "C:\eLaw\eLaw_Data_Files\eLaw_Data_Files\pdf\"
        lblcheckupload.Text = ""

        If fu_file.HasFile Then
            Dim FileExtension As String = Path.GetExtension(fu_file.FileName)

            If FileExtension = ".xml" Or FileExtension = ".pdf" Then
                If FileExtension = ".pdf" Then
                    Dim CaseExist As Boolean = ClsUpload.IsCaseExist("CasesIndustrialCourt", fu_file.FileName.Replace(".pdf", ".xml"))
                    If CaseExist = False Then
                        lblcheckupload.Text = "Please Upload XML file first."
                        Exit Sub
                    End If

                    fu_file.SaveAs(PdfPath & fu_file.FileName)
                    Dim info As New FileInfo(PdfPath & fu_file.FileName)
                    Dim length As Long = info.Length
                    lblcheckupload.Text = "<span color:Green; font-weight:700;>Pdf File Uploaded Successfully. </span>"
                Else
                    DirPath = "C:\eLaw\eLaw_Data_Files\eLaw_Data_Files\cases\" & fu_file.FileName
                    ClsCasesUpload.FileXmlToClass = DirPath
                    ClsCasesUpload.FileNameToClass = fu_file.FileName
                    XmlFile = fu_file.FileName
                    XmlExit = ClsUpload.IsXmlExit(DirPath)
                    fu_file.SaveAs(DirPath)

                    Dim rootTagName As String = GetRootTagName(DirPath)
                    Dim fileName As String = ClsCasesUpload.FileNameToClass.Replace(".xml", "")

                    If rootTagName = fileName Then
                    Else
                        lblcheckupload.Text = "<span color:Red; font-weight:700;> Check your FILENAME or ROOT TAG NAME, didnt match </span>"
                        'lblcheckupload.Text = " <span color:Red; font-weight:700;>Please Select files to upload </span> "
                        Exit Sub
                    End If

                    FlgUpload = ClsUpload.UploadCase()
                    If FlgUpload.Contains("Please Check Xml File Citation") Then
                        lblcheckupload.Text = FlgUpload
                        Exit Sub
                    End If

                    Dim iistr As Boolean = ClsUpload.UploadSubjectIndex()
                    If FlgUpload.IndexOf("Please Check Xml File Error is") > -1 Then
                        lblcheckupload.Text = "<br>Upload Information  <br>File Name : " & XmlFile & "<br>Case : " & FlgUpload
                        Exit Sub
                    End If

                    FlgCasesReferred = ClsUpload.UploadCaseReferred()
                    flgLegislationReferred = ClsUpload.UploadLegislationReferred()
                    lstImg = ClsUpload.GetImgTag()
                    '======================
                    lblcheckupload.Text = "<span color:Green; font-weight:700;><br>Upload Information  <br>File Name : " & XmlFile & "<br>Case : " & FlgUpload & "<br> Case Referred : <br> </span>" & FlgCasesReferred
                    lblcheckupload.Text &= "<span color:Green; font-weight:700;> <br>Legislation Referred : </span> " & flgLegislationReferred
                    If lstImg.Count Then
                        StrImg = String.Join(" , ", lstImg.ToArray())
                        lblcheckupload.Text &= "<br><br><br><span color:Green; font-weight:700;>Images avaiable and need to be upload: </span> <br>" & StrImg
                        UploadPhoto.Visible = True
                    Else
                        lblcheckupload.Text &= "<br><br><br><span color:Red; font-weight:700;> No Images avaiable For This File</span> <br>" & StrImg
                        UploadPhoto.Visible = False
                    End If
                    '' New Counsel strcture - Ali
                    lblcheckupload.Text &= "<br>" & ClsUpload.AddingCounselToDB(DirPath)
                    ClsCasesUpload.FileXmlToClass = ""
                    ClsCasesUpload.FileNameToClass = ""
                    ClsUpload = Nothing
                End If
            Else
                lblcheckupload.Text = "Upload only file as Xml "
            End If

        Else
            lblcheckupload.Text = "<span color:Red; font-weight:700;>Please Select files to upload </span> "
        End If
    End Sub

    Public Function GetRootTagName(ByVal strpath As String) As String
        Dim xmlDocument As New XDocument
        xmlDocument = XDocument.Load(strpath)
        Dim root As String = ""
        root = xmlDocument.Document.Root.Name.ToString
        Return root
    End Function

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim filepath As String = "C:\eLaw\eLaw-Images\case_notes\cases\"
        Dim uploadedFiles As HttpFileCollection = Request.Files
        Dim FileExtension As String
        Span1.Text = String.Empty
        For i As Integer = 0 To uploadedFiles.Count - 1
            Dim userPostedFile As HttpPostedFile = uploadedFiles(i)
            Try
                If userPostedFile.ContentLength > 0 Then
                    FileExtension = Path.GetExtension(userPostedFile.FileName)
                    Span1.Text += "<u>File #" & (i + 1) & "</u><br>"
                    Span1.Text += "File Content Type: " & userPostedFile.ContentType & "  --" & FileExtension & "<br>"
                    Span1.Text += "File Size: " & userPostedFile.ContentLength & "kb<br>"
                    Span1.Text += "File Name: " & userPostedFile.FileName & "<br>"
                    If FileExtension.ToLower() = ".png" Or FileExtension.ToLower() = ".jpg" Or FileExtension.ToLower() = ".jpeg" Then
                        userPostedFile.SaveAs(filepath & "\" & Path.GetFileName(userPostedFile.FileName))
                        Span1.Text &= " Uploaded"
                    Else
                        Span1.Text &= "Only Imgage file allowed to upload"
                    End If
                    'Span1.Text &= "Location where saved: " & filepath + "\" & Path.GetFileName(userPostedFile.FileName) & "<p>"
                End If
            Catch Ex As Exception
                Span1.Text &= "Error: <br>" & Ex.Message
                'My.Computer.FileSystem.WriteAllText("C:\Elaw\Calculate_Execution_Timetest.txt", String.Join(vbCrLf, Ex.Message), False)
            End Try
        Next


    End Sub
End Class
