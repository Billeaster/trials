'/********************************************************************/
'/*	Developer 	    : Usman Sarwar  								*/
'/*	Company     	: Mylawbox Sdn Bhd		    					*/
'/* Date Modified	: 17 apr 2005          									*/  
'/*	Description		: Deprecated library used for reporting          */
'/*	Version			: 1.0											*/
'/********************************************************************/

Imports System.Data.SqlClient
Imports System.Exception


Namespace admin1



Public Class clsReports
    Private ConnectionString As String
    Public Sub New()

        ConnectionString = ConfigurationSettings.AppSettings("ConnectionString")

        If ConnectionString = "" Then
            Throw New ApplicationException("Missing ConnectionString variable in web.config file.")
        End If

    End Sub

    Public Overloads Function getRevenueReport(ByVal selDate1 As String, ByVal selDate2 As String) As DataSet
        Dim currentDateTime1 As Date  ' String = selDate
        Dim currentDateTime2 As Date
        currentDateTime1 = System.Convert.ToDateTime(selDate1)
        currentDateTime2 = System.Convert.ToDateTime(selDate2)
            Dim Query As String = "select Firm_Name,First_Name,User_Name,user_id_no,Registration_Date,Acct_Expiry from master_users where Access_Type<>'Free' and (Acct_Expiry>'" & currentDateTime1 & "' and Acct_Expiry<'" & currentDateTime1 & "') "
            Dim DS As DataSet = FetchDataSet(Query, "master_users")
            Return DS
        End Function


        Public Overloads Function getMonthlyReport(ByVal selDate1 As String, ByVal selDate2 As String) As DataSet
            Dim currentDateTime1 As Date  ' String = selDate
            Dim currentDateTime2 As Date
            currentDateTime1 = System.Convert.ToDateTime(selDate1)
            currentDateTime2 = System.Convert.ToDateTime(selDate2)
            Dim Query As String = "select First_Name,Firm_Name,User_Name,Registration_Date,Acct_Expiry from master_users where Access_Type<>'Free' and (Acct_Expiry>'" & currentDateTime1 & "' and Acct_Expiry<'" & currentDateTime1 & "') "
            Dim DS As DataSet = FetchDataSet(Query, "master_users")
            Return DS
        End Function

        Public Overloads Function getMonthlyReport(ByVal selDate1 As String, ByVal selDate2 As String, ByVal sortByChar As String) As DataSet
            Dim currentDateTime1 As Date  ' String = selDate
            Dim currentDateTime2 As Date
            currentDateTime1 = System.Convert.ToDateTime(selDate1)
            currentDateTime2 = System.Convert.ToDateTime(selDate2)

            sortByChar = " First_Name LIKE  '" & sortByChar & "%" & "' "
            Dim Query As String = "select First_Name,Firm_Name,User_Name,Registration_Date,Acct_Expiry from master_users where Access_Type<>'Free' and " & sortByChar & "  and (Acct_Expiry>'" & currentDateTime1 & "' and Acct_Expiry<'" & currentDateTime1 & "') "
            Dim DS As DataSet = FetchDataSet(Query, "master_users")
            Return DS
        End Function

    '''/*Fetch Data*/
    Private Function FetchDataSet(ByVal Query As String, ByVal tblName As String) As DataSet
        Dim ds As New DataSet()
        'Dim Reader1 As SqlClient.SqlDataReader
        Try
            Dim conn As New SqlConnection(ConnectionString)
            Dim cmd As New SqlCommand(Query, conn)

            Dim adapter As New SqlDataAdapter(cmd)

            adapter.Fill(ds, tblName)
            conn.Close()

        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally

        End Try

        Return ds
    End Function


End Class

End Namespace
