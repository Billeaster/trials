﻿Imports Microsoft.VisualBasic

''' 
''' <filename>
''' clsConfigs.vb
''' </filename>
''' <description> 
''' This purpose of this file is to provide global accessibility of some variable may be for development purpose
''' </description>
''' <author>
''' usman sarwar
''' </author>
''' <date>
''' 08 april 2011
''' </date>
''' 
''' <todo>
''' 1- need to read from config.web file the configurations.
''' 2- need to check what are the new configurations useful
''' </todo>
''' 


Public Class clsConfigs

    Public Function ConnString() As String
        Dim sGlobalConnectionString As String = "Data Source=DS09-DATASOLUTI\SQLELAW;Initial Catalog=elawdb;User ID=sa;Password=DSelaw@2017"

        Return sGlobalConnectionString
    End Function

    Public Shared ReadOnly sGlobalConnectionString As String = "Data Source=DS09-DATASOLUTI\SQLELAW;Initial Catalog=elawdb;User ID=sa;Password=DSelaw@2017"

End Class
