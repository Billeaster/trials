﻿Imports Microsoft.VisualBasic
Imports System.IO
Imports System.Xml
Imports System.Data.SqlClient
Imports System.Data
Imports System.Globalization
Imports iTextSharp.text.pdf
Imports elawKeyPassage
Imports System.Xml.Serialization

Public Class ImgUpload

End Class

Class caseinfo
    Public CaseId As String
    Public CaseTitle As String
    Shared conn As String = ClsCasesUpload.ConnectionStr
    Public Shared strConnection As String
    Public Sub New()
        strConnection = ConfigurationSettings.AppSettings(conn) ' ConfigurationManager.ConnectionStrings(conn).ConnectionString
    End Sub
    Public Sub New(ByVal id As String, ByVal title As String)
        CaseId = id
        CaseTitle = title
    End Sub
    Public Shared Function GetCaseId(ByVal StartIndex As String, ByVal Str As String) As String
        Dim StrIndex As String = StartIndex
        Dim FlgIndex As Boolean = False
        Dim Found As Match = Regex.Match("MLRH", Str, RegexOptions.IgnoreCase)
        Dim Found1 As Match = Regex.Match("MLRA", Str, RegexOptions.IgnoreCase)
        Dim Found2 As Match = Regex.Match("MELR", Str, RegexOptions.IgnoreCase)
        ' New Update For MLRS
        Dim Found3 As Match = Regex.Match("MLRS", Str, RegexOptions.IgnoreCase)
        Dim Found4 As Match = Regex.Match("SSLR", Str, RegexOptions.IgnoreCase)
        Dim Found5 As Match = Regex.Match("MSLR", Str, RegexOptions.IgnoreCase)
				' New Update For MLRS 
        If Str.Contains(StrIndex) = False Then
            FlgIndex = True
            StrIndex = ""
			
            If Found.Success Then
                StrIndex = "MLRH"
            End If
            If Found1.Success Then
                StrIndex = "MLRA"
            End If
            If Found2.Success Then
                StrIndex = "MELR"
            End If
            'New Update For MLRS 13-03-2014
            If Found3.Success Then
                StrIndex = "MLRS"
            End If
            If Found4.Success Then
                StrIndex = "SSLR"
            End If
			If Found5.Success Then
                StrIndex = "MSLR"
            End If
        End If

        Dim StrCut As String = ""

        If FlgIndex = False Then
            StrCut = Str.Substring(Str.IndexOf(StrIndex) + StrIndex.Length)
        ElseIf StrIndex <> "" Then
            StrCut = Str.Substring(Str.IndexOf(StrIndex))
        Else
            StrCut = ""
        End If

        If StrCut <> "" Then
            StrCut = StrCut & ".xml"
        End If
        StrCut = StrCut.Replace(";", "").Trim
        Return StrCut
    End Function

    Public Shared Function GetLegislationId(ByVal StartIndex As String, ByVal Str As String) As String
        Dim StrIndex As String = StartIndex
        Dim StrCut As String = ""
        Dim StrArrJoin As String = ""
        StrCut = Str.Substring(Str.IndexOf(StrIndex))
        Dim result As List(Of String) = StrCut.Split(";"c).ToList()
        For i = 0 To result.Count - 1
            result.Remove("")
        Next
        StrArrJoin = String.Join(";", result.ToArray())
        Return StrArrJoin
    End Function
    Public Shared Function GetCasesInfo(ByVal CaseIDs As String) As DataTable
        Dim CasesInfo As New DataTable

        Dim con As New SqlConnection(strConnection)
        Dim cmd As New SqlCommand()
        Try
            Dim strSelect As String = "select DATAFILENAME, title,CITATION,COURT from CasesIndustrialCourt  " & CaseIDs
            cmd.Connection = con
            cmd.CommandType = CommandType.Text
            cmd.CommandText = strSelect
            con.Open()
            CasesInfo.Load(cmd.ExecuteReader)
        Catch ex As Exception

        Finally
            con.Close()
        End Try

        Return CasesInfo
    End Function

End Class
Public Class ClsCasesUpload
    Public XmlFile As String
    Private ConnectionString As String
    Public Shared FileXmlToClass As String ' Include Dir
    Private Shared CnString As String
    Public Shared FileNameToClass As String 'File Name for DB
    Public Shared ConnectionStr As String
    'Public Shared ReadOnly sGlobalConnectionString As String = "Data Source=182.239.43.29,58664;initial catalog=elawdb;uid=sa;pwd=D4t4S0lut10n$sqL"
    Dim CaseReferred As New List(Of caseinfo)

    Public Shared Error_XMLFile As String = "" ' to display error in XML if any
    Public Shared ListOfCaseProgression As String = ""

    Public Shared strIndexStatus As String = "N/A"

    Structure LegStrcut
        Public actid As String
        Public secid As String
        Public actTitle As String
    End Structure
    Public Sub New(ByVal conn As String)
        ConnectionString = ConfigurationSettings.AppSettings(conn)
        ConnectionStr = conn
        If ConnectionString = "" Then
            Throw New ApplicationException("Missing ConnectionString variable in web.config file.")
        End If
    End Sub
    ''' <summary>
    ''' Check if file already uploaded Return Exist= True
    ''' </summary>
    ''' <param name="XmlFile"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    ''' 
    Public Function IsXmlExit(ByVal XmlFile As String) As Boolean
        Dim flg As Boolean = False
        If File.Exists(XmlFile) = True Then
            flg = True
        End If
        Return flg

    End Function
    Public Function isValidFileForHeadnotes(ByVal filename As String) As Boolean

        '' this is for chking if the case has our headnotes & if not don't show it
        Dim i As Integer
        Dim FileType As String
        Dim Valid As Boolean = False
        Dim FileList = ValidFileName()
        FileType = Left(UCase(Trim(filename)), 4)
        For i = 0 To FileList.Count - 1
            If FileType = FileList.Item(i) Then
                Valid = True
                Exit For
            End If
        Next
        FileList = Nothing
        Return Valid

    End Function

    Public Function ValidFileName() As Collections.ArrayList
        Dim TypeList As New ArrayList()
        TypeList.Add("MLRH")
        TypeList.Add("MLRA")
        TypeList.Add("MELR")
        TypeList.Add("MLRHU")
        TypeList.Add("MLRAU")
        TypeList.Add("MELRU")
        TypeList.Add("MLRS")
        TypeList.Add("MLRSU")
        TypeList.Add("SSLR")
        TypeList.Add("MSLR")
        TypeList.Add("MSLRU")
        Return TypeList
    End Function

    Private Function SplitCitation(ByVal fn As String) As String
        Dim citation, CaseType, JudgementYear, VOL, Storepage As String
        fn = fn.Replace(".xml", "")
        Dim SplitDBfn() As String = fn.Split(New Char() {"_"c})
        If SplitDBfn.Count = 3 Then
            CaseType = SplitDBfn(0)
            JudgementYear = SplitDBfn(1)
            VOL = SplitDBfn(2)
            citation = "[" & JudgementYear & "] " & " " & CaseType & " " & VOL
        Else
            CaseType = SplitDBfn(0)
            JudgementYear = SplitDBfn(1)
            VOL = SplitDBfn(2)
            Storepage = SplitDBfn(3)
            citation = "[" & JudgementYear & "] " & " " & VOL & " " & CaseType & " " & Storepage
        End If
        Return citation
    End Function
	
    Private Function RebuildCitation(ByVal T As String) As String
        Dim RC As String = T  '[2011] 2 MLJ 160 >> MLJ_2011_2_160     [2013] MLRHU 580>> MLRHU_2013_580
        ' New Citation formate 

        If RC.Contains("_") Then
            RC = RC.Trim()
        Else

            RC = RC.Replace("[", "").Replace("]", "").Trim()
            Dim ArrTag() As String = RC.Split(New Char() {" "c})

            If ArrTag.Count = 4 Then
                RC = ArrTag(2) & "_" & ArrTag(0) & "_" & ArrTag(1) & "_" & ArrTag(3) & ".xml"
            Else
                RC = ArrTag(1) & "_" & ArrTag(0) & "_" & ArrTag(2) & ".xml"
            End If

        End If

        Return RC

    End Function

    Private Function DeleteUnreportedCase(ByVal Unreport As String) As Boolean
        Dim delFlg As Boolean
        Dim strpath As String = ""
        Dim position As Integer = FileXmlToClass.LastIndexOf("\"c)
        If position > -1 Then
            strpath = FileXmlToClass.Substring(0, position + 1)
            If File.Exists(strpath & Unreport.Trim & ".xml") = True Then
                File.Delete(strpath & Unreport)
                delFlg = True
            End If
        End If

        ' Delete from DB 
        Dim SqlQuery As String
        'Dim SqlQuery As String = "Delete from cases where"
        'SqlQuery &= " datafilename= '" & Unreport.Trim & ".xml" & "' "
        'delFlg = DeleteRecord(SqlQuery)
        SqlQuery = "Delete from CasesIndustrialCourt where"
        SqlQuery &= " datafilename= '" & Unreport.Trim & ".xml" & "' "
        delFlg = DeleteRecord(SqlQuery)
        'SqlQuery = "Delete from Cases_SYA where"
        'SqlQuery &= " datafilename= '" & Unreport.Trim & ".xml" & "' "
        'delFlg = DeleteRecord(SqlQuery)

        Return delFlg

    End Function

    Public Function isMonthInMalay(ByVal strMonth As String) As Boolean
        If strMonth = "Januari" Or strMonth = "Februari" Or strMonth = "Mac" Or strMonth = "April" _
            Or strMonth = "Mei" Or strMonth = "Jun" Or strMonth = "Julai" Or strMonth = "Ogos" _
            Or strMonth = "September" Or strMonth = "Oktober" Or strMonth = "November" Or strMonth = "Disember" Then
            Return True
        Else
            Return False
        End If
    End Function

    Public Function isMonthInEnglish(ByVal strMonth As String) As Boolean
        If strMonth = "January" Or strMonth = "February" Or strMonth = "March" Or strMonth = "April" _
            Or strMonth = "May" Or strMonth = "June" Or strMonth = "July" Or strMonth = "August" _
            Or strMonth = "September" Or strMonth = "October" Or strMonth = "November" Or strMonth = "December" Then
            Return True
        Else
            Return False
        End If
    End Function

    Private Function DateFormatChecker(ByVal JudgmentDate As String, ByVal Language As String) As Boolean
        If Language.Contains(" ") Then
            Language = Language.Replace(" ", "")
        End If

        Dim result As Boolean = False
        Dim strDay As String = ""
        Dim strMonth As String = ""
        Dim strYear As String = ""

        Try
            strDay = JudgmentDate.Split(" ")(0)
            strYear = JudgmentDate.Split(" ")(2)
            strMonth = JudgmentDate.Split(" ")(1).Split(" ")(0)

            If Language = "MALAYSIAN" Then
                result = isMonthInMalay(strMonth)
                Return result

            ElseIf Language = "ENGLISH" Then
                result = isMonthInEnglish(strMonth)
                Return result
            Else

            End If
        Catch ex As Exception
            result = False
        End Try
        Return result
    End Function

    Private Function UpdateIndex(ByVal xmlFileName As String) As String
        Dim xmlPath As String = "C:\eLaw\eLaw_Data_Files\eLaw_Data_Files\cases"
        Dim indexPath As String = "C:\eLaw\eLaw-KeyPassage2"
        Dim indexObj As New elawKeyPassage.elawKPMain(xmlPath, indexPath, ConnectionString, xmlFileName)
        Dim AddToDb = indexObj.StartIndex()
        Return AddToDb
    End Function
#Region " XML "

    ''' <summary>
    ''' '''''''''''''''''''' Code Added by shahnila to Judge

    'Public Function UpdateRecord(ByVal Query As String) As Boolean
    '    'Dim Query As String = "insert into tblUserPrimary "
    '    UpdateRecord = False
    '    Dim Statement As String
    '    Statement = Query
    '    Dim conn As New SqlConnection(ConnectionString)
    '    Dim cmd As New SqlCommand

    '    Try
    '        cmd.Connection = conn
    '        cmd.CommandType = CommandType.Text
    '        cmd.CommandText = Query
    '        conn.Open()
    '        cmd.ExecuteNonQuery()
    '        UpdateRecord = True

    '    Catch err As Exception
    '        Throw New Exception("Error in inserting to DB  " & err.Message)
    '        UpdateRecord = False

    '    Finally
    '        conn.Close()
    '        cmd = Nothing
    '    End Try
    '    Return UpdateRecord

    'End Function

    Public Function ExecuteMyQuery(ByVal Query As String) As DataTable
        Dim DT As New DataTable
        Dim conn As New SqlConnection(ConnectionString)
        Dim MSG As String
        Try
            Dim cmd As New SqlCommand(Query, conn)
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)
        Catch err As Exception
            'Throw New ApplicationException("Error in connecting to DB  " & err.Message)
            MSG = err.Message
        Finally
            conn.Close()
        End Try
        conn = Nothing
        Return DT
    End Function


    Private Function ExtractJudgeTagInfo(ByVal TagName As String) As String
        Dim TagInfo As String = ""
        Dim Info As New System.Text.StringBuilder()
        Dim Nodelst As XmlNodeList
        Dim XDoc As New XmlDocument()
        Dim Judge As String = ""
        Dim StrSQL As String = ""
        Dim dtCheck As New DataTable()
        Dim objUtility As New admin1.clsMyUtility()

        Try
            XDoc.Load(FileXmlToClass)
            Dim i As Integer
            Nodelst = XDoc.GetElementsByTagName(TagName)
            For i = 0 To Nodelst.Count - 1
                TagInfo = Trim(Nodelst(i).InnerXml())
                If TagInfo <> "" Then
                    If TagInfo.Contains(",") Then
                        Judge = TagInfo
                        If Judge.Contains(",") Then

                            Dim tempjdg As String() = Judge.Split(",")
                            For b = 0 To tempjdg.Length() - 1
                                If tempjdg(b).Trim().Length > 0 Then
                                    Dim s_SplitJudge As String = tempjdg(b).Trim()

                                    If s_SplitJudge.Contains(":") Then
                                        Dim start As Int32 = s_SplitJudge.IndexOf(":") + 1
                                        s_SplitJudge = s_SplitJudge.Substring(start, s_SplitJudge.Length - start)
                                    End If

                                    If s_SplitJudge.Contains("'") Then
                                        s_SplitJudge = s_SplitJudge.Replace("'", "''")
                                    End If

                                    s_SplitJudge = objUtility.refineNoice_wordsJudge(s_SplitJudge)
                                    Dim SqlQuery As String = " select  JudgeName from  JUDGE where JudgeName = '" & s_SplitJudge & "'"
                                    dtCheck = ExecuteMyQuery(SqlQuery)

                                    If dtCheck.Rows.Count = 0 Then

                                        StrSQL = "Insert into  Judge ( JudgeName ) values ( '" & s_SplitJudge & "' )   "
                                        Dim bFound As Boolean = UpdateRecord(StrSQL)
                                    End If


                                End If
                            Next


                        Else
                            If Judge <> "" Then
                                StrSQL = "Insert into  Judge ( JudgeName ) values ( '" & Judge & "' )   "
                                Dim bFound As Boolean = UpdateRecord(StrSQL)
                            End If

                        End If
                    End If
                    Info.Append(TagInfo & " ")
                End If
            Next i
        Catch Exp As Exception
            TagInfo = Exp.Message.ToString
        End Try

        TagInfo = Info.ToString
        If Len(TagInfo) = 0 Then
            TagInfo = "" ' not to send null
        End If

        TagInfo = Clear(TagInfo)
        Return TagInfo
    End Function

    Private Function ExtractCouncelTagInfo(ByVal TagName As String) As String
        Dim TagInfo As String = ""
        Dim Info As New System.Text.StringBuilder()
        Dim Nodelst As XmlNodeList
        Dim XDoc As New XmlDocument()
        Dim Councel As String = ""
        Dim StrSQL As String = ""
        Dim dtCheck As New DataTable()

        Try
            XDoc.Load(FileXmlToClass)
            Dim i As Integer
            Nodelst = XDoc.GetElementsByTagName(TagName)
            For i = 0 To Nodelst.Count - 1
                TagInfo = Trim(Nodelst(i).InnerXml())
                TagInfo = StripTags(TagInfo)
                If TagInfo <> "" Then
                    Councel = TagInfo
                    If TagInfo.Contains(";") Then

                        If Councel.Contains(";") Then

                            Dim tempjdg As String() = Councel.Split(";")
                            For b = 0 To tempjdg.Length() - 1
                                If tempjdg(b).Trim().Length > 0 Then
                                    Dim s_SplitJudge As String = tempjdg(b).Trim()

                                    Dim SqlQuery As String = " select * from  Counsel_2016 where Counsel = '" & s_SplitJudge & "'"
                                    dtCheck = ExecuteMyQuery(SqlQuery)

                                    If dtCheck.Rows.Count = 0 Then
                                        StrSQL = "Insert into  Counsel_2016 (Counsel) values ( '" & s_SplitJudge & "' )   "
                                        Dim bFound As Boolean = UpdateRecord(StrSQL)
                                    End If


                                End If
                            Next


                        Else
                            If Councel <> "" Then
                                StrSQL = "Insert into  Counsel_2016 (Counsel) values ( '" & Councel & "' )   "
                                Dim bFound As Boolean = UpdateRecord(StrSQL)
                            End If

                        End If
                    ElseIf Councel.Contains("-") Then
                        Dim tempjdg As String() = Councel.Split("-")
                        For b = 0 To tempjdg.Length() - 1
                            If tempjdg(b).Trim().Length > 0 Then
                                Dim s_SplitJudge As String = tempjdg(b).Trim()
                                If tempjdg.Length() = 2 Then
                                    s_SplitJudge = tempjdg(1).Trim()
                                ElseIf tempjdg.Length() = 3 Then
                                    s_SplitJudge = tempjdg(1).Trim()

                                ElseIf tempjdg.Length() = 4 Then
                                    s_SplitJudge = tempjdg(3).Trim()
                                ElseIf tempjdg.Length() = 6 Then
                                    s_SplitJudge = tempjdg(5).Trim()
                                End If

                                If s_SplitJudge.Contains("-") Then
                                    Dim start As Int32 = s_SplitJudge.IndexOf("-") + 1
                                    s_SplitJudge = s_SplitJudge.Substring(start, s_SplitJudge.Length - start)
                                End If
                                Dim SqlQuery As String = " select * from  Counsel_2016 where Counsel = '" & s_SplitJudge & "'"
                                dtCheck = ExecuteMyQuery(SqlQuery)

                                If dtCheck.Rows.Count = 0 Then
                                    StrSQL = "Insert into  Counsel_2016 ( Counsel ) values ( '" & s_SplitJudge & "' )   "
                                    Dim bFound As Boolean = UpdateRecord(StrSQL)
                                End If


                            End If
                        Next
                    End If
                    Info.Append(TagInfo & " ")
                End If
            Next i
        Catch Exp As Exception
            TagInfo = Exp.Message.ToString
        End Try
        TagInfo = Info.ToString
        If Len(TagInfo) = 0 Then
            TagInfo = "" ' not to send null
        End If

        TagInfo = Clear(TagInfo)
        Return TagInfo
    End Function

    Function StripTags(ByVal html As String) As String
        ' Remove HTML tags.
        Return Regex.Replace(html, "<.*?>", "")
    End Function

    ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

    Private Function ExtractTagInfo(ByVal TagName As String) As String
        Dim TagInfo As String = ""
        Dim Info As New System.Text.StringBuilder()
        Dim Nodelst As XmlNodeList
        Dim XDoc As New XmlDocument()
        Try
            XDoc.Load(FileXmlToClass)
            Dim i As Integer
            Nodelst = XDoc.GetElementsByTagName(TagName)
            For i = 0 To Nodelst.Count - 1
                TagInfo = Trim(Nodelst(i).InnerXml())
                If TagInfo <> "" Then
                    Info.Append(TagInfo & " ")
                End If
            Next i
        Catch Exp As Exception
            TagInfo = Exp.Message.ToString
        End Try
        TagInfo = Info.ToString
        If Len(TagInfo) = 0 Then
            TagInfo = "" ' not to send null
        End If

        TagInfo = Clear(TagInfo)
        Return TagInfo
    End Function

    Private Function ExtractTagInfoLink(ByVal TagName As String) As String
        Dim TagInfo As String = ""
        Dim Info As New System.Text.StringBuilder()
        Dim Nodelst As XmlNodeList
        Dim XDoc As New XmlDocument()
        Try
            XDoc.Load(FileXmlToClass)
            Dim i As Integer
            Nodelst = XDoc.GetElementsByTagName(TagName)
            For i = 0 To Nodelst.Count - 1
                TagInfo = Trim(Nodelst(i).InnerXml())
                If TagInfo <> "" Then
                    Info.Append(TagInfo & " ")
                End If
            Next i
        Catch Exp As Exception
            TagInfo = Exp.Message.ToString
        End Try
        TagInfo = Info.ToString
        If Len(TagInfo) = 0 Then
            TagInfo = "" ' not to send null
        End If

        'TagInfo = Clear(TagInfo)
        Return TagInfo
    End Function

    Private Function ValidateXML() As String
        Dim XmlError As String = ""
        Dim XDoc As New XmlDocument()
        Try
            XDoc.Load(FileXmlToClass)
        Catch Exp As Exception
            XmlError = Exp.Message.ToString
        End Try
        Return XmlError
    End Function
    Public Function ReadXmlFile(ByVal DirFilePath As String) As String

        Dim FileContent As New System.Text.StringBuilder()
        Dim Result As String
        Dim R As XmlTextReader = New XmlTextReader(DirFilePath)
        Try
            Do While R.Read
                If R.Value <> "" Then
                    FileContent.Append(R.Value)
                End If
            Loop
        Catch Err As Exception
            Result = Err.Message.ToString
            R.Close()
        Finally
            Result = FileContent.ToString
            FileContent = Nothing
            R.Close()
        End Try
        R.Close()
        ReadXmlFile = Nothing
        Result = Clear(Result)
        Return Result
    End Function
    Public Function GetBooleanText() As String
        Dim Title As String
        Title = ReadXmlFile(FileXmlToClass)
        Return Title
    End Function

    Public Function GetByTagName(ByVal XmlTag As String) As String
        Dim Tag As String
        Tag = ExtractTagInfo(XmlTag)
        Return Tag
    End Function

#Region " Citation MLJ,CLJ,AMR, UNREPORTED"
    Public Function MLJ_CITATION() As String
        Dim Tag As String
        Tag = ExtractTagInfo("MLJ_CITATION")
        If Tag <> "" AndAlso Tag.Contains("_") = False Then
            Tag = RebuildCitation(Tag)
        End If
        Return Tag
    End Function
    Public Function MLJU_CITATION() As String
        Dim Tag As String
        Tag = ExtractTagInfo("MLJU_CITATION")
        ' If Tag <> "" AndAlso Tag.Contains("_") = False Then
        If Tag <> "" And Tag.Contains("_") = True Then

            Tag = RebuildCitation(Tag)
        End If
        Return Tag
    End Function
    Public Function CLJ_CITATION() As String
        Dim Tag As String
        Tag = ExtractTagInfo("CLJ_CITATION")
        If Tag <> "" AndAlso Tag.Contains("_") = False Then
            Tag = RebuildCitation(Tag)
        End If
        Return Tag
    End Function
    Public Function LNS_CITATION() As String
        Dim Tag As String
        Tag = ExtractTagInfo("LNS_CITATION")
        If Tag <> "" AndAlso Tag.Contains("_") = False Then
            Tag = RebuildCitation(Tag)
        End If
        Return Tag
    End Function
    Public Function AMR_CITATION() As String
        Dim Tag As String
        Tag = ExtractTagInfo("AMR_CITATION")
        If Tag <> "" AndAlso Tag.Contains("_") = False Then
            Tag = RebuildCitation(Tag)
        End If
        Return Tag
    End Function
    Public Function ILJ_CITATION() As String
        Dim Tag As String
        Tag = ExtractTagInfo("ILJ_CITATION")
        If Tag <> "" AndAlso Tag.Contains("_") = False Then
            Tag = RebuildCitation(Tag)
        End If
        Return Tag
    End Function
    Public Function ILR_CITATION() As String
        Dim Tag As String
        Tag = ExtractTagInfo("ILR_CITATION")
        If Tag <> "" AndAlso Tag.Contains("_") = False Then
            Tag = RebuildCitation(Tag)
        End If
        Return Tag
    End Function
    Public Function UNREPORTED_CITATION() As String
        Dim Tag As String
        Tag = ExtractTagInfo("UNREPORTED_CITATION")
        If Tag <> "" AndAlso Tag.Contains("_") = False Then
            Tag = RebuildCitation(Tag)
        End If
        Return Tag
    End Function
#End Region
#Region " Get Single Tag Info "
    Public Function GetCountry() As String
        Dim Title As String
        Title = ExtractTagInfo("JUDGMENT_COUNTRY")
        Return Title
    End Function
    Public Function GetLanguage() As String
        Dim Title As String
        Title = ExtractTagInfo("JUDGMENT_LANGUAGE")
        Return Title
    End Function
    Public Function GetTitle() As String
        Dim Title As String
        Title = ExtractTagInfo("JUDGMENT_NAME")
        Return Title
    End Function
    Public Function GetCourt() As String
        Dim Title As String
        Title = ExtractTagInfo("COURT_TYPE")
        Return Title
    End Function
    Public Function GetJudge() As String
        Dim Title As String
        ' Title = ExtractTagInfo("JUDGE_NAME")
        Title = ExtractJudgeTagInfo("JUDGE_NAME")
        Return Title
    End Function
    Public Function GetJudNumber() As String
        Dim Title As String
        Title = ExtractTagInfo("JUDGMENT_NUMBER")
        Return Title
    End Function
    Public Function GetJudDate() As String
        Dim Title As String
        Title = ExtractTagInfo("JUDGMENT_DATE")
        Return Title
    End Function
    Public Function GetCatchWord() As String
        Dim Title As String
        Title = ExtractTagInfo("CATCHWORDS")
        Return Title
    End Function
    Public Function GetCounsel() As String
        Dim Title As String
        ' Title = ExtractTagInfo("COUNSELS")
        Title = ExtractCouncelTagInfo("COUNSELS")
        Return Title
    End Function
    Public Function GetVerdict() As String
        Dim Title As String
        Title = ExtractTagInfo("VERDICT")
        Return Title
    End Function
    Public Function GetHeadNote() As String
        Dim Title As String
        Title = ExtractTagInfo("HEADNOTE")
        Return Title
    End Function
    Public Function GetJudgment() As StringBuilder
        Dim Title As New StringBuilder
        Title.Append(ExtractTagInfo("JUDGMENT"))
        Return Title
    End Function

    Public Function GetJudgmentLink() As StringBuilder
        Dim Title As New StringBuilder
        Title.Append(ExtractTagInfoLink("JUDGMENT"))
        Return Title
    End Function
    'New declare by Rozidee on 13-09-2016
    Public Function GetCaseProgression() As String
        Dim Title As String
        Title = ExtractTagInfo("CASE_PROGRESSION")
        Return Title
    End Function

    Public Function GetImgTag() As List(Of String)
        Dim img As New List(Of String)
        Dim XDoc As New XmlDocument()
        Dim Nodelst As XmlNodeList

        Try
            XDoc.Load(FileXmlToClass)
            'get REFERRED_CASES 
            Nodelst = XDoc.GetElementsByTagName("img")
            If Nodelst.Count Then
                For i = 0 To Nodelst.Count - 1
                    img.Add(Nodelst(i).Attributes("src").Value)
                Next
            End If
        Catch ex As Exception
            img.Add(ex.ToString)
        End Try
        Return img
    End Function
#End Region
#Region "Case Referred, Legislation Referred"
    Private Function ExtractCaseReferred() As String
        Dim TagInfo As String = ""
        Dim Info As New System.Text.StringBuilder()
        Dim Nodelst As XmlNodeList
        Dim xmlLink As XmlNodeList
        Dim xmlType As XmlNodeList
        Dim XDoc As New XmlDocument()
        Dim XmlSub As New XmlDocument
        Dim TempCaseType As String
        Dim CaseType As String = ""
        '========================================
        Try
            XDoc.Load(FileXmlToClass)
            'get REFERRED_CASES 
            Nodelst = XDoc.GetElementsByTagName("REFERRED_CASES")
            For Each xn As XmlNode In Nodelst
                XmlSub.LoadXml(xn.OuterXml())
                xmlLink = XmlSub.GetElementsByTagName("LINK")
                xmlType = XmlSub.GetElementsByTagName("i")
                If xmlLink.Count > 0 Then
                    For i = 0 To xmlLink.Count - 1
                        TempCaseType = xmlType(i).InnerText.ToLower()
                        TempCaseType = Regex.Replace(TempCaseType, "</?(link|LINK).*?>", "")
                        If TempCaseType.IndexOf("(refd)") > -1 Then
                            CaseType = "REFD"
                        ElseIf TempCaseType.IndexOf("(foll)") > -1 Then
                            CaseType = "FOLL"
                        ElseIf TempCaseType.IndexOf("(not foll)") > -1 Then
                            CaseType = "not foll"
                        ElseIf TempCaseType.IndexOf("(dist)") > -1 Or TempCaseType.IndexOf("(distd)") > -1 Then
                            CaseType = "DIST"
                        ElseIf TempCaseType.IndexOf("(ovrld)") > -1 Then
                            CaseType = "OVRLD"
                        Else
                            CaseType = "REFD"
                        End If
                        CaseReferred.Add(New caseinfo(xmlLink(i).Attributes("HREF").Value(), CaseType))
                        CaseType = ""
                    Next
                End If
            Next
            Dim lstcid As New List(Of String)
            For i = 0 To CaseReferred.Count - 1
                CaseReferred(i).CaseId = caseinfo.GetCaseId("pageid=", CaseReferred(i).CaseId.ToString())
                If CaseReferred(i).CaseId.ToString <> "" Then
                    lstcid.Add(CaseReferred(i).CaseId)
                End If

            Next
            If lstcid.Count Then
                TagInfo = " where datafilename in ('" & String.Join("','", lstcid.ToArray) & "')"
            End If
        Catch Exp As Exception
            TagInfo = "Error While reading Cases Referred, Please check case xml tags(REFERRED_CASES)" & Exp.Message.ToString
        End Try
        Return TagInfo
    End Function

    Private Function ExtractLegislarionReferred() As List(Of LegStrcut)
        Dim TagInfo As String = ""
        Dim Nodelst As XmlNodeList
        Dim xmlLink As XmlNodeList
        Dim XDoc As New XmlDocument()
        Dim XmlSub As New XmlDocument
        Dim LegislationReferred As New List(Of caseinfo)
        Dim lstLegislationIds As New List(Of String)
        Dim s As New List(Of LegStrcut)
        Dim sdb As New List(Of LegStrcut)
        Dim sfinal As New List(Of LegStrcut)
        Dim secinfo As LegStrcut
        Dim DT As New DataTable
        '========================================
        Try
            XDoc.Load(FileXmlToClass)
            'get REFERRED_CASES 
            Nodelst = XDoc.GetElementsByTagName("REFERRED_LEGISLATIONS")
            For Each xn As XmlNode In Nodelst
                XmlSub.LoadXml(xn.OuterXml())
                xmlLink = XmlSub.GetElementsByTagName("LINK")
                If xmlLink.Count > 0 Then
                    For i = 0 To xmlLink.Count - 1
                        LegislationReferred.Add(New caseinfo(xmlLink(i).Attributes("HREF").Value(), ""))
                    Next
                End If
            Next
            For i = 0 To LegislationReferred.Count - 1
                ' LegislationReferred(i).CaseId = caseinfo.GetLegislationId("MY", LegislationReferred(i).CaseId.ToString())

                If LegislationReferred(i).CaseId.Contains("MY_") Then
                    LegislationReferred(i).CaseId = caseinfo.GetLegislationId("MY", LegislationReferred(i).CaseId.ToString())

                Else
                    If LegislationReferred(i).CaseId.Contains("?") Then
                        Dim index As Int32 = LegislationReferred(i).CaseId.IndexOf("?") + 1
                        Dim length As Int32 = LegislationReferred(i).CaseId.Length
                        Dim Start As String = LegislationReferred(i).CaseId.Substring(index, length - index)
                        Dim first As Int32 = Start.IndexOf("_")
                        Start = Start.Substring(0, first)
                        LegislationReferred(i).CaseId = caseinfo.GetLegislationId(Start, LegislationReferred(i).CaseId.ToString())
                    End If
                End If

                If LegislationReferred(i).CaseId.ToString <> "" Then
                    secinfo.actid = LegislationReferred(i).CaseId.Split(New Char() {";"c})(0)
                    secinfo.secid = LegislationReferred(i).CaseId
                    secinfo.actTitle = ""
                    s.Add(secinfo)
                    lstLegislationIds.Add(secinfo.actid)
                End If
            Next
            '======================================
            If Not s.Any Then
                secinfo.actid = "NoLegislation"
                secinfo.actTitle = ""
                secinfo.secid = ""
                sfinal.Add(secinfo)
                Return sfinal
            End If
            '======================================
            Dim noDupes As List(Of String) = lstLegislationIds.Distinct().ToList()
            If noDupes.Count Then
                TagInfo = " where DATAFILENAME in ('" & String.Join(".xml','", noDupes.ToArray) & ".xml')"
            End If

            noDupes.Clear()
            ' Get Title 
            Dim Query As String = "select DATAFILENAME ,title from legislation " & TagInfo
            DT = EXcuteQuery(Query)
            For i = 0 To DT.Rows.Count - 1
                secinfo.actid = DT.Rows(i).Item(0).ToString().Replace(".xml", "").Replace(".XML", "").Trim
                secinfo.actTitle = DT.Rows(i).Item(1).ToString()
                secinfo.secid = ""
                sdb.Add(secinfo)
            Next
            For i = 0 To s.Count - 1
                secinfo.actid = s(i).actid
                secinfo.actTitle = sdb.Find(Function(r) r.actid = s(i).actid).actTitle
                If secinfo.actTitle = Nothing Or secinfo.actTitle = "" Then
                    secinfo.actTitle = "NOTITLE"
                End If
                secinfo.secid = s(i).secid
                sfinal.Add(secinfo)
            Next
        Catch Exp As Exception
            sfinal.Clear()
            secinfo.actid = "ErrorInReadingTag"
            secinfo.actTitle = Exp.Message.ToString
            secinfo.secid = ""
            sfinal.Add(secinfo)
        End Try
        LegislationReferred.Clear()
        TagInfo = ""
        DT = Nothing
        Return sfinal
    End Function
#End Region
#End Region
#Region " database Area"

    Public Function UploadCase() As String
        Dim StrError As String = ""
        strIndexStatus = ""
        Dim Fn As String = FileNameToClass.Replace(".xml", "")
        Dim flgInsert As Boolean = False
        Dim CheckFileName As Boolean = False


        ' Update Check File Name 
        CheckFileName = isValidFileForHeadnotes(Fn)

        If Fn.Contains("MLRFU") Then
            CheckFileName = True
        End If

        If CheckFileName = False Then
            StrError = "Please Check Xml File Error is : Invalid File Name " & Fn
            Return StrError
        End If

        If FileNameToClass.Contains(" .xml") Then
            StrError = "Please Check Xml File Error is : Invalid File Name with ' .xml' in " & Fn
            Return StrError
        End If

        Dim Str_ILJ_CITATION As String = ""
        Dim Str_ILR_CITATION As String = ""
        Dim Str_MLJ_CITATION As String = ""
        Dim Str_MLJU_CITATION As String = ""
        Dim Str_CLJ_CITATION As String = ""
        Dim Str_LNS_CITATION As String = ""
        Dim Str_AMR_CITATION As String = ""
        Dim Str_UNREPORTED_CITATION As String = ""

        Dim JUDGMENT_COUNTRY As String = ""
        Dim JUDGMENT_LANGUAGE As String = ""
        Dim JUDGMENT_NAME As String = ""
        Dim COURT_TYPE As String = ""
        Dim JUDGE_NAME As String = ""
        Dim JUDGMENT_NUMBER As String = ""
        Dim JUDGMENT_DATE As String = ""
        Dim HEADNOTE As String = ""
        Dim CATCHWORDS As String = ""
        Dim COUNSELS As String = ""
        Dim VERDICT As String = ""
        Dim BooleanText As String = ""

        Dim CASE_PROGRESSION As String = "" ' declared by Rozidee

        Dim Splitfn() As String = Fn.Split(New Char() {"_"c})
        Dim CaseType As String = Splitfn(0)
        Dim JudgementYear As String = Splitfn(1)
        Dim VOL As String = Splitfn(2)
        Dim Storepage As String = ""
        Dim CaseReported As Integer
        If Splitfn.Count = 4 Then
            Storepage = Splitfn(3)
            CaseReported = 0
        Else
            CaseReported = 1
        End If

        Dim Citation As String = SplitCitation(FileNameToClass)
        Dim PerpareQuery() As String
        Dim FnSize As Long = (New FileInfo(FileXmlToClass)).Length
        Dim Judgment As New StringBuilder
        Dim JudgementLinks As New StringBuilder

        Dim ValidateXmlFile As String = ValidateXML()
        If String.IsNullOrEmpty(ValidateXmlFile) Then
            Str_ILR_CITATION = ILR_CITATION()
            Str_ILJ_CITATION = ILJ_CITATION()
            Str_MLJ_CITATION = MLJ_CITATION()
            Str_MLJU_CITATION = MLJU_CITATION()
            Str_CLJ_CITATION = CLJ_CITATION()
            Str_LNS_CITATION = LNS_CITATION()
            Str_AMR_CITATION = AMR_CITATION()
            Str_UNREPORTED_CITATION = UNREPORTED_CITATION()
            JUDGMENT_COUNTRY = GetCountry()
            JUDGMENT_LANGUAGE = GetLanguage()
            JUDGMENT_NAME = GetTitle()
            COURT_TYPE = GetCourt()
            JUDGE_NAME = GetJudge()
            JUDGMENT_NUMBER = GetJudNumber()
            JUDGMENT_DATE = GetJudDate()
            HEADNOTE = GetHeadNote()
            CATCHWORDS = GetCatchWord()
            COUNSELS = GetCounsel()
            VERDICT = GetVerdict()
            Judgment.Append(GetJudgment())
            JudgementLinks.Append(GetJudgmentLink())

            CASE_PROGRESSION = GetCaseProgression()

            ''Validate for wrong case citation
            Dim s_Link As String = JudgementLinks.Append(GetJudgmentLink()).ToString()
            Dim strSplit As String() = Split(s_Link, "pageid=", , CompareMethod.Text)

            strIndexStatus = Me.UpdateIndex(FileNameToClass.Trim)

            Dim DT As New DataTable
            Dim objUser As New clsUsers
            Try
                For Each s_Citation In strSplit
                    If s_Citation.StartsWith("M") Then
                        s_Citation = s_Citation.Substring(0, s_Citation.IndexOf(";"">")).Replace("[", "").Replace("]", "")
                        'Check if Citation exist in our database
                        Dim StrSQL As String = "select DATAFILENAME from casesindustrialcourt WHERE DATAFILENAME LIKE '%" & s_Citation & "%'"
                        DT = objUser.ExecuteMyQuery(StrSQL)
                        If DT.Rows.Count = 0 Then
                            StrError = "<span style='color:Red; font-weight:700;'>Please Check XML File Citation " & s_Citation & " does not exist in dataBase </span> "
                            Return StrError
                        End If
                    End If
                Next

            Catch ex As Exception
                Dim trace = New Diagnostics.StackTrace(ex, True)
                Dim lineNumber = Right(trace.ToString, 5)
                StrError = " Please Check Xml File Error is : " & ex.Message & " at line num " & lineNumber
            End Try

            BooleanText = JUDGMENT_COUNTRY & " " & JUDGMENT_LANGUAGE & " " & JUDGMENT_NAME & " " & COURT_TYPE & " " & JUDGE_NAME & " " & JUDGMENT_NUMBER & " " & JUDGMENT_DATE & " " & HEADNOTE & " " & Judgment.ToString()
        Else
            StrError = "Please Check Xml File Error is : " & ValidateXmlFile
            Return StrError
        End If
        'New Update Check if some Tag are empty 

        If JUDGMENT_COUNTRY.Length < 2 Or JUDGMENT_LANGUAGE.Length < 2 Or JUDGMENT_NUMBER.Length < 2 Or JUDGE_NAME.Length < 2 Or JUDGMENT_DATE.Length < 2 Or JUDGMENT_NAME.Length < 2 Then
            StrError = "<span style='color:Red; font-weight:700;'>Please Check Xml File Error is : Main Tags Are Empty</span>"
            Return StrError
        Else
            If VERDICT.Length < 2 Then
                StrError = "<span style='color:Red; font-weight:700;'>Please Check Xml File Error is : VERDICT Is Empty</span>"
                Return StrError
            End If
            '   ''code date checker validation goes here >>>>>>
            JUDGMENT_LANGUAGE = JUDGMENT_LANGUAGE.Replace(" ", "")

            If DateFormatChecker(JUDGMENT_DATE, JUDGMENT_LANGUAGE) = False Then
                StrError = JUDGMENT_LANGUAGE & "<span style='color:Red; font-weight:700;'>Please Check Xml File Error is : JUDGMENT_DATE is not in correct format</span>"
                Return StrError
            End If
        End If

        'REFERRED_CASES CHECKING
        '=======================
        Try
            Dim strCasesReferredResult As String = ""
            strCasesReferredResult = UploadCaseReferred()
            If strCasesReferredResult.Contains("Please Check Xml File Error is") = True Then
                StrError = strCasesReferredResult
            End If
        Catch ex As Exception
            Dim trace = New Diagnostics.StackTrace(ex, True)
            Dim lineNumber = Right(trace.ToString, 5)
            StrError = " Please Check Xml File Error is : " & ex.Message & "in CASES_REFERRED TAG at line number : " & lineNumber
            Return StrError
        End Try


        ''''' =============================================================================ROZIDEE 18-08-2016 START
        'REFERRED_LEGISLATIONS CHECKER
        '=============================
        Try
            Dim strLegisChecker As String = ""
            strLegisChecker = LegislationLinkChecker()

            If strLegisChecker.Contains("Please Check Xml File Error is") = True Then
                StrError = strLegisChecker
                'GoTo ReturnResultAndExit
                Return StrError
            End If
            '=============================================================================ROZIDEE 18-08-2016 END

        Catch ex As Exception
            Dim trace = New Diagnostics.StackTrace(ex, True)
            Dim lineNumber = Right(trace.ToString, 5)
            StrError = " Please Check Xml File Error is : " & ex.Message & "in LEGISLATION_REFERRED TAG at line number : " & lineNumber
            Return StrError
        End Try


        ' Delete File For Unreported Cases 
        If Str_UNREPORTED_CITATION <> "" Then
            DeleteUnreportedCase(Str_UNREPORTED_CITATION)
        End If


        Dim JDATE As String
        Dim jdateVal As String
        Try
            Dim Year As String = " " & JudgementYear & " "
            Dim Volume As String = " " & VOL & " "
            'PerpareQuery = {"Datafilename", FileNameToClass.Trim, "LANGUAGE", JUDGMENT_LANGUAGE, "CITATION", Citation, "COUNTRY", JUDGMENT_COUNTRY,
            '           "TITLE", JUDGMENT_NAME, "COURT", COURT_TYPE, "JUDGE", JUDGE_NAME, "CASENUMBER", JUDGMENT_NUMBER,
            '           "JUDGEMENTDATE", JUDGMENT_DATE, "HEADNOTES", HEADNOTE, "COUNSEL", COUNSELS, "VERDICT", VERDICT,
            '          "BOOLEANTEXT", BooleanText, "CASETYPE", CaseType, "JUDGEMENTYEAR", Year, "SortValue", Volume,
            '           "Pageno", Storepage, "FileSize", FnSize, "CATCHWORDS", CATCHWORDS, "UploadedDate", DateTime.Now.ToString,
            '           "CaseReported", CaseReported, "clj", Str_CLJ_CITATION, "mlj", Str_MLJ_CITATION, "amr", Str_AMR_CITATION}


            'If JUDGMENT_LANGUAGE = "MALAYSIAN" Then
            ' JDATE = ConvertStringToDateTimeValue(JUDGMENT_DATE)
            ' Else
            'JDATE = Convert.ToDateTime(JUDGMENT_DATE)
            'JDATE = ConvertStringToDateTimeValue(JUDGMENT_DATE)

            'JDATE = Convert.ToDateTime(JDATE)
            ' End If
            'Dim culture As IFormatProvider = New CultureInfo("en-US", True)
            'Dim printDate As Date = Date.ParseExact(JDATE, "yyyy-M-d", System.Globalization.DateTimeFormatInfo.InvariantInfo)
            'jdateVal = printDate.ToString("yyyy-MM-dd HH:mm:ss.fff")
            JDATE = ConvertStringToDateValue(JUDGMENT_DATE).ToString("yyyy-MM-dd")
            jdateVal = ConvertDateToDateTimeValue(JDATE).ToString("yyyy-MM-dd HH:mm:ss")
            Dim dateNow As String = Date.Now.ToString("yyyy-MM-dd")
            ' UPDATED CODE BY ROZIDEE ------------------------------------>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
            Dim SqlQuery As String = ""
            Dim selectQuery As String = "select * from casesindustrialcourt where datafilename ='" & FileNameToClass & "'"
            Dim dtSelect As DataTable = EXcuteQuery(selectQuery)
            Dim updateQuery As String = ""
            If dtSelect.Rows.Count > 0 Then
                '====== Delete from case & CasesIndustrialCourt before Insert 
                Dim OriginalUploadDate As Date = dtSelect.Rows(0).Item("uploadeddate").ToString

                SqlQuery = ""
                SqlQuery = "Delete from CasesIndustrialCourt where datafilename= '" & FileNameToClass & "' "
                DeleteRecord(SqlQuery)

                PerpareQuery = {"Datafilename", FileNameToClass.Trim, "LANGUAGE", JUDGMENT_LANGUAGE, "CITATION", Citation, "COUNTRY", JUDGMENT_COUNTRY,
                           "TITLE", JUDGMENT_NAME, "COURT", COURT_TYPE, "JUDGE", JUDGE_NAME, "CASENUMBER", JUDGMENT_NUMBER,
                           "JUDGEMENTDATE", JUDGMENT_DATE, "HEADNOTES", HEADNOTE, "COUNSEL", COUNSELS, "VERDICT", VERDICT,
                          "BOOLEANTEXT", BooleanText, "CASETYPE", CaseType, "JUDGEMENTYEAR", Year, "SortValue", Volume,
                           "Pageno", Storepage, "FileSize", FnSize, "CATCHWORDS", CATCHWORDS, "reuploaddate", dateNow,
                           "CaseReported", CaseReported, "clj", Str_CLJ_CITATION, "mlj", Str_MLJ_CITATION, "amr", Str_AMR_CITATION, "LNS", Str_LNS_CITATION, "MLJU",
                                Str_MLJU_CITATION, "JUDGEMENTDATESort", jdateVal, "ILR", Str_ILR_CITATION, "ILJ", Str_ILJ_CITATION, "uploadeddate", OriginalUploadDate.ToString("yyyy-MM-dd")}

                SqlQuery = PrepareInsert_Statement("CasesIndustrialCourt", PerpareQuery)
                flgInsert = AddRecord(SqlQuery)

                'updateQuery = "update casesindustrialcourt set language = '" & JUDGMENT_LANGUAGE & "', citation='" & Citation & "', title='" & JUDGMENT_NAME & "', judgementdate='" & JUDGMENT_DATE & "', headnotes='" & HEADNOTE & "', counsel='" & COUNSELS & "', verdict='" & VERDICT & "', booleantext='" & BooleanText & "', casetype='" & "', judgementyear='" & Year & "', sortvalue='" & Volume & "', pageno='" & Storepage & "', filesize='" & FnSize & "', catchwords='" & CATCHWORDS & "', reuploaddate='" & dateNow & "', casereported='" & CaseReported & "', clj='" & Str_CLJ_CITATION & "', mlj='" & Str_MLJ_CITATION & "', amr='" & Str_AMR_CITATION & "', lns='" & Str_LNS_CITATION & "', mlju='" & Str_MLJU_CITATION & "', judgementdatesort='" & jdateVal & "', ilr='" & Str_ILR_CITATION & "', ilj='" & Str_ILJ_CITATION & "', uploadeddate='" & OriginalUploadDate.ToString("yyyy-MM-dd") & "' where datafilename ='" & FileNameToClass.Trim & "'"

                'SqlQuery = PrepareUpdate_Statement("casesindustrialcourt", updateQuery)
                'flgInsert = UpdateRecord(SqlQuery)


            Else
                'NON EXIST CASE CITATION

                PerpareQuery = {"Datafilename", FileNameToClass.Trim, "LANGUAGE", JUDGMENT_LANGUAGE, "CITATION", Citation, "COUNTRY", JUDGMENT_COUNTRY,
                           "TITLE", JUDGMENT_NAME, "COURT", COURT_TYPE, "JUDGE", JUDGE_NAME, "CASENUMBER", JUDGMENT_NUMBER,
                           "JUDGEMENTDATE", JUDGMENT_DATE, "HEADNOTES", HEADNOTE, "COUNSEL", COUNSELS, "VERDICT", VERDICT,
                          "BOOLEANTEXT", BooleanText, "CASETYPE", CaseType, "JUDGEMENTYEAR", Year, "SortValue", Volume,
                           "Pageno", Storepage, "FileSize", FnSize, "CATCHWORDS", CATCHWORDS, "UploadedDate", dateNow,
                           "CaseReported", CaseReported, "clj", Str_CLJ_CITATION, "mlj", Str_MLJ_CITATION, "amr", Str_AMR_CITATION, "LNS", Str_LNS_CITATION, "MLJU",
                                Str_MLJU_CITATION, "JUDGEMENTDATESort", jdateVal, "ILR", Str_ILR_CITATION, "ILJ", Str_ILJ_CITATION}

                SqlQuery = PrepareInsert_Statement("CasesIndustrialCourt", PerpareQuery)
                flgInsert = AddRecord(SqlQuery)
            End If

            SqlQuery = ""
            ' UPDATED CODE BY ROZIDEE ------------------------------------>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
            Call Me.UploadCaseProgression()

            SqlQuery = ""
            'Insert Title Inot Search_engine Suggestion 

            Dim flgSearchEngine As Boolean = False
            flgSearchEngine = AddTitleSearchEngine(JUDGMENT_NAME)
            If flgInsert = True Then
                StrError = " <span style='color:Green; font-weight:700;'>File has been uploaded successfully. Please check on eLaw to see real time result </span> "
            End If

        Catch ex As Exception
            Dim trace = New Diagnostics.StackTrace(ex, True)
            Dim lineNumber = Right(trace.ToString, 5)
            StrError = "<span style='color:Red; font-weight:700;'>Error During Uploading Error is : </span>" & ex.Message.ToString() & " at line no : " & lineNumber & " value: " & jdateVal
        End Try

        Return StrError & "<br> Key Passage Section <br>" & strIndexStatus
        'strIndexStatus = ""

    End Function

    Public Function UploadPDFFileInfo(ByVal PDFPath As String) As String
        Try

            Dim fileName As String = GetFileName(PDFPath)
            If fileName.Contains(" .pdf") = True Then
                Return "Not upload. Please check your PDF Filename, remove 'space' before '.pdf'"
            End If
            Dim reader As New PdfReader(PDFPath)

            Dim pgCount As Integer = 0

            pgCount = reader.NumberOfPages()

            Dim status As Boolean = False
            Dim strSQL As String = ""

            Dim dTable1 As New DataTable
            Dim dTable2 As New DataTable

            'DATABASE CASESINDUSTRIALCOURT
            strSQL = "select * from casesindustrialcourt where datafilename='" & fileName & ".xml'"
            dTable1 = EXcuteQuery(strSQL)

            If dTable1.Rows.Count > 0 Then
                strSQL = "update casesindustrialcourt set pageCount='" & pgCount & "' where datafilename = '" & fileName & ".xml'"
                EXcuteQuery(strSQL)
            Else
                '''''' dont upload if there are no data row
            End If
            Return pgCount
        Catch ex As Exception
            Return "Not upload. Please check your PDF File."
        End Try

        ' DATABASE CASES
        'strSQL = "select * from cases where datafilename='" & fileName & ".xml'"
        'dTable2 = EXcuteQuery(strSQL)

        'If dTable2.Rows.Count > 0 Then
        '    strSQL = "update cases set pageCount='" & pgCount & "' where datafilename = '" & fileName & ".xml'"
        '    EXcuteQuery(strSQL)
        'Else
        '    '''''' dont upload if there are no data row
        'End If


        'If dTable1.Rows.Count > 0 Or dTable2.Rows.Count > 0 Then
        '    Return pgCount
        'Else
        '    Return 0
        'End If

    End Function


    'created by Rozidee on 07-10-2016
    Public Function ConvertMonthToNumber(ByVal strMonth As String) As String
        If strMonth = "Januari" Or strMonth = "January" Then
            Return "01"
        ElseIf strMonth = "Februari" Or strMonth = "February" Then
            Return "02"
        ElseIf strMonth = "Mac" Or strMonth = "March" Then
            Return "03"
        ElseIf strMonth = "April" Then
            Return "04"
        ElseIf strMonth = "Mei" Or strMonth = "May" Then
            Return "05"
        ElseIf strMonth = "Jun" Or strMonth = "June" Then
            Return "06"
        ElseIf strMonth = "Julai" Or strMonth = "July" Then
            Return "07"
        ElseIf strMonth = "Ogos" Or strMonth = "August" Then
            Return "08"
        ElseIf strMonth = "September" Then
            Return "09"
        ElseIf strMonth = "Oktober" Or strMonth = "October" Then
            Return "10"
        ElseIf strMonth = "November" Then
            Return "11"
        ElseIf strMonth = "Disember" Or strMonth = "December" Then
            Return "12"
        Else
            Return "00"
        End If
    End Function

    Public Function ConvertStringToDateTimeValue(ByVal strDate As String) As String
        Dim correctDateTime As String = ""
        Dim cday As String = strDate.Split(" ")(0)
        Dim cmonth As String = ConvertMonthToNumber(strDate.Split(" ")(1))
        Dim cyear As String = strDate.Split(" ")(2)
        correctDateTime = cyear & "-" & cmonth & "-" & cday '& " 00:00:00.000"
        'correctDateTime = cyear & "-" & cmonth & "-" & cday
        Return correctDateTime ',"yyyy-mm-dd HH:mm:ss.fff",CultureInfo.InvariantCulture)
    End Function
    Public Function ConvertStringToDateValue(ByVal strDate As String) As Date
        Dim correctDate As Date
        Dim cday As String = ""
        Dim cmonth As String = ""
        Dim cyear As String = ""
        Dim patternJDate As String = "([0-9]{1,2})\s([A-Z|a-z]{3,10})\s([0-9]{4,4})+$" '"([0-9]{1,2}\s[A-Z|a-z]{3,10}\s[0-9]{4,4})"
        Dim r As New Regex(patternJDate)
        Dim mColl As MatchCollection = r.Matches(strDate.Trim)
        Dim arrStrDate As List(Of String) = New List(Of String)
        For Each m As Match In mColl
            arrStrDate.Add(m.Value)
        Next
        Dim inputDate As String = ""
        inputDate = arrStrDate(arrStrDate.Count - 1).ToString
        cday = inputDate.Split(" ")(0)
        cmonth = ConvertMonthToNumber(inputDate.Split(" ")(1))
        cyear = inputDate.Split(" ")(2)
        correctDate = cyear & "-" & cmonth & "-" & cday
        Return correctDate
    End Function

    Public Function ConvertDateToDateTimeValue(ByVal inputDate As Date) As DateTime
        Dim result As DateTime
        Try
            result = DateTime.Parse(inputDate, System.Globalization.CultureInfo.CurrentCulture)
        Catch ex As Exception

        End Try
        Return result
    End Function
    'Created by Rozidee on 18-08-2016

    Public Function LegislationLinkChecker() As String
        Dim strError As String = ""
        Dim xDoc As New XmlDocument
        Dim Nodelst As XmlNodeList

        Dim XmlSub As New XmlDocument
        Dim xmlLink As XmlNodeList

        Dim LegislationReferred As New List(Of String)
        Dim LegislationTitle As String

        xDoc.Load(FileXmlToClass)

        'get REFERRED_CASES 
        Nodelst = xDoc.GetElementsByTagName("REFERRED_LEGISLATIONS")

        For Each xn As XmlNode In Nodelst
            XmlSub.LoadXml(xn.OuterXml())
            xmlLink = XmlSub.GetElementsByTagName("LINK")

            If xmlLink.Count > 0 Then
                For i = 0 To xmlLink.Count - 1
                    LegislationTitle = xmlLink(i).InnerXml
                    Dim j As Integer = 0
                    'Do Until LegislationTitle.Length > 10
                    Do Until Not IsNumeric(LegislationTitle(0))
                        'to detect wether legis to link is contain act name
                        LegislationTitle = xmlLink(i - j).InnerXml
                        j = j + 1
                    Loop
                    'MsgBox(LegislationTitle)
                    LegislationReferred.Add(LegislationTitle & "XXX" & xmlLink(i).Attributes("HREF").Value())
                Next
            End If
        Next

        ''''' connect to db for checking
        Dim dTable As New DataTable
        Dim strSQL As String

        Dim referTitle As String = ""
        Dim referLink As String = ""
        Dim referCategory As String = ""
        Dim referTitleCategory As String

        Dim referAct As String = ""
        Dim referNo As String = ""

        Dim referSection As String = ""
        Dim referRules As String = ""
        Dim referOrder As String = ""
        Dim referSearch As String = ""
        Dim referType As String = ""
        Dim strAll As String = ""
        Dim strLegisTitle As String = ""

        For Each strLegisLink As String In LegislationReferred
            referSearch = ""
            referAct = ""

            referTitleCategory = strLegisLink.Split({"XXX"}, StringSplitOptions.None)(0) ' store legislation title for comparison method
            'MsgBox(referTitleCategory)
            If referTitleCategory.Contains(",") Then
                referTitle = referTitleCategory.Split(",")(0)
                referCategory = referTitleCategory.Split(",")(1)
            Else
                referAct = referTitleCategory
                referCategory = ""
            End If

            If referCategory = "(" Then
                referCategory = referCategory.Remove(referCategory.Length - 3, 3)
            End If

            referLink = strLegisLink.Split({"XXX"}, StringSplitOptions.None)(1)
			referAct = referLink.Split("?")(1).Split(";")(0)
			
           If referLink.ToLower.Contains("legislationSection") Then
                referNo = referLink.Split(";")(1).Split(";;")(0)
                strSQL = "select * from secion_tb1 where legfile like '%" & referAct & "%' and sec_title like '%" & referNo.Replace(".", "") & "%'"
            Else
                referNo = ""
                strSQL = "select * from legislation where datafilename = '" & referAct.Replace(";","") & ".xml'"
            End If
            

			
			
            dTable = EXcuteQuery(strSQL)

            If dTable.Rows.Count > 0 Then
                ' legislation referred found in database
                strError = ""
            Else
                strError = "<span style='color:Red; font-weight:700;'>Please Check Xml File Error is: Couldn't find Referred Legislation:" & referAct & ";" & referNo & " in database.</span>"
                'Exit For
                Return strError
            End If
        Next

        Return strError

    End Function

    ''Public Function isMonthInMalay(ByVal strMonth As String) As Boolean

    ''    If strMonth = "Januari" Or strMonth = "Februari" Or strMonth = "Mac" Or strMonth = "April" _
    ''        Or strMonth = "Mei" Or strMonth = "Jun" Or strMonth = "Julai" Or strMonth = "Ogos" _
    ''        Or strMonth = "September" Or strMonth = "Oktober" Or strMonth = "November" Or strMonth = "Disember" Then
    ''        Return True
    ''    Else
    ''        Return False
    ''    End If

    ''End Function

    ''Public Function isMonthInEnglish(ByVal strMonth As String) As Boolean
    ''    If strMonth = "January" Or strMonth = "February" Or strMonth = "March" Or strMonth = "April" _
    ''        Or strMonth = "May" Or strMonth = "June" Or strMonth = "July" Or strMonth = "August" _
    ''        Or strMonth = "September" Or strMonth = "October" Or strMonth = "November" Or strMonth = "December" Then
    ''        Return True
    ''    Else
    ''        Return False
    ''    End If
    ''End Function

    ''Private Function DateFormatChecker(ByVal JudgmentDate As String, ByVal Language As String) As Boolean
    ''    Dim result As Boolean = False
    ''    Dim strDay As String = ""
    ''    Dim strMonth As String = ""
    ''    Dim strYear As String = ""

    ''    Try
    ''        strDay = JudgmentDate.Split(" ")(0)
    ''        strYear = JudgmentDate.Split(" ")(2)

    ''        strMonth = JudgmentDate.Split(" ")(1).Split(" ")(0)

    ''        If Language = "MALAYSIAN" Then
    ''            result = isMonthInMalay(strMonth)
    ''            Return result

    ''        ElseIf Language = "ENGLISH" Then
    ''            result = isMonthInEnglish(strMonth)
    ''            Return result
    ''        Else

    ''        End If

    ''    Catch ex As Exception
    ''        result = False
    ''    End Try

    ''    Return result

    ''End Function
    Public Function isGotContentCaseReference(ByVal strCaseProgression As String) As Boolean
        If strCaseProgression.Contains("[") And strCaseProgression.Contains("]") Then
            Return True
        Else
            Return False
        End If
    End Function

    Public Function UploadCaseReferred() As String

        Dim StrError As String = ""
        Dim CaseInfo As New caseinfo
        Dim Query As String = ""

        Dim flgInsert As Boolean = False
        Dim DT As New DataTable
        Dim objUser As New clsUsers

        ' First Read Case Referred Tag 
        Dim CasesReferredIDs As String = ExtractCaseReferred()
        If CasesReferredIDs = "" Or String.IsNullOrEmpty(CasesReferredIDs) Then
            'Check if any case refered previously
            Dim StrSQL As String = "select DATAFILENAME from casesindustrialcourt WHERE DATAFILENAME LIKE '" & FileNameToClass & "%'"
            DT = objUser.ExecuteMyQuery(StrSQL)
            If DT.Rows.Count > 0 Then
                Dim SqlQuery As String = "Delete from refcases where RootCitation= '" & FileNameToClass.Replace(".xml", "").Replace(".XML", "") & "' "
                DeleteRecord(SqlQuery)
                SqlQuery = ""
            End If

            StrError = "There is no cases referred for this case  ,Please confirm if true " & vbCrLf
            Return StrError
        ElseIf CasesReferredIDs.Contains("REFERRED_CASES") Then
            StrError = CasesReferredIDs & vbCrLf
            Return StrError
        End If

        Dim ListCaseReferred As New List(Of String)
        Dim listDT As New List(Of String)
        DT = CaseInfo.GetCasesInfo(CasesReferredIDs)
        If DT.Rows.Count = CaseReferred.Count Then
            StrError = "All Referred Cases Found " & vbCrLf
            For i = 0 To DT.Rows.Count - 1
                listDT.Add(DT.Rows(i).Item(0).ToString)
            Next
        Else
            For Each CaseInfo In CaseReferred
                ListCaseReferred.Add(CaseInfo.CaseId)
            Next
            For i = 0 To DT.Rows.Count - 1
                listDT.Add(DT.Rows(i).Item(0).ToString)
            Next

            Dim result As List(Of String) = ListCaseReferred.Except(listDT).ToList()
            StrError = " Please Check Xml File Error is missing Referred case : <br>" & String.Join("<br>", result.ToArray())
            Return StrError
        End If
        Try
            If DT.Rows.Count > 0 Then
                ' Delete main from referred case table before inserting
                Dim SqlQuery As String = "Delete from refcases where RootCitation= '" & FileNameToClass.Replace(".xml", "").Replace(".XML", "") & "' "
                DeleteRecord(SqlQuery)
                SqlQuery = ""
                'Insert Function 
                Dim CaseTitle As String = GetTitle()
                Query = PerpareInsertCaseReferred("refcases", FileNameToClass, DT, CaseTitle)
                If Query.Contains("'s") Then
                    Query = Query.Replace("'s", " ")
                End If
                flgInsert = AddRecord(Query)
            End If
            If flgInsert = True Then
                StrError &= vbCrLf & " <br>Cases Referred Inserted  <br>" & vbCrLf & String.Join("<br>", listDT.ToArray)
            Else
                StrError &= vbCrLf & "<br>This has  Cases Referred, but referred cases could not be found in case table to extract needed information,<br>Please Upload referred cases and then upload this case again "
            End If

        Catch ex As Exception
            StrError &= vbCrLf & " Error Found During Inserting Into Cases Referred" & ex.Message
        End Try
        CaseReferred.Clear()
        DT = Nothing
        CaseInfo = Nothing
        listDT.Clear()
        ListCaseReferred.Clear()


        Return StrError
    End Function

    Public Function UploadLegislationReferred() As String
        Dim StrError As String = ""
        Dim EmptyTitleIDs As New List(Of String)
        Dim FullTitleIDs As New List(Of String)
        Dim flgInsert As Boolean
        Dim DT As New DataTable
        Dim objUser As New clsUsers

        Dim LegisltionReIds As List(Of LegStrcut) = ExtractLegislarionReferred()
        If LegisltionReIds(0).actid = "ErrorInReadingTag" Then

            Dim StrSQL As String = "select DATAFILENAME from casesindustrialcourt WHERE DATAFILENAME LIKE '" & FileNameToClass & "%'"
            DT = objUser.ExecuteMyQuery(StrSQL)
            If DT.Rows.Count > 0 Then
                Dim SqlQuery As String = "Delete from ref_leg_tb where root_citation= '" & FileNameToClass.Replace(".xml", "").Replace(".XML", "").Trim & "' "
                DeleteRecord(SqlQuery)
                SqlQuery = ""
            End If

            StrError = "<br>Please Check Legislation Referred tag.<br>Please Check the following Error : " & LegisltionReIds(0).actTitle
            Return StrError
        ElseIf LegisltionReIds(0).actid = "NoLegislation" Then

            Dim StrSQL As String = "select DATAFILENAME from casesindustrialcourt WHERE DATAFILENAME LIKE '" & FileNameToClass & "%'"
            DT = objUser.ExecuteMyQuery(StrSQL)
            If DT.Rows.Count > 0 Then
                Dim SqlQuery As String = "Delete from ref_leg_tb where root_citation= '" & FileNameToClass.Replace(".xml", "").Replace(".XML", "").Trim & "' "
                DeleteRecord(SqlQuery)
                SqlQuery = ""
            End If
            StrError = "<br>There is no Legislation Referred For This File."
            Return StrError
        End If
        '========================================
        'check legislation title before uploading 
        For i = 0 To LegisltionReIds.Count - 1
            If LegisltionReIds(i).actTitle.Trim = "NOTITLE" Then
                EmptyTitleIDs.Add(LegisltionReIds(i).actid.ToString())
            Else
                FullTitleIDs.Add(LegisltionReIds(i).secid.ToString())
            End If
        Next
        If EmptyTitleIDs.Count > 0 Then
            StrError &= vbCrLf & "<br> The following Legislation Files do not have title or could not found in database <br>"
            StrError &= String.Join("<br>", EmptyTitleIDs.ToArray)
        End If
        If FullTitleIDs.Count > 0 Then
            StrError &= vbCrLf & "<br> The following Legislation Files Successfully Uploaded <br>"
            StrError &= String.Join("<br>", FullTitleIDs.ToArray)
        End If
        ' check ,Insert &  delete case before uploading 
        If LegisltionReIds.Count Then
            ' Delete main from referred case table before inserting
            Dim SqlQuery As String = "Delete from ref_leg_tb where root_citation= '" & FileNameToClass.Replace(".xml", "").Replace(".XML", "").Trim & "' "
            DeleteRecord(SqlQuery)
            SqlQuery = ""

            'Insert Function 
            Dim CaseTitle As String = GetTitle()
            SqlQuery = PerpareInsertLegislationReferred("ref_leg_tb", FileNameToClass, LegisltionReIds, CaseTitle)
            flgInsert = AddRecord(SqlQuery)
        End If
        If flgInsert = True Then
            StrError &= vbCrLf & "<br> Final Result : Legislation Referred Successfully Uploaded"
        End If
        EmptyTitleIDs.Clear()
        FullTitleIDs.Clear()

        LegisltionReIds.Clear()
        Return StrError
    End Function

    Public Function getSubjectIndex(ByVal strXML As String) As ArrayList
        Dim SubArrList As New ArrayList()
        Dim substr As String
        Dim startindex As Integer
        Dim endindex As Integer
        Dim srchtag As String = "SUBJECT_INDEX"
        Dim strlevel1, strlevel2 As String
        Dim dashindex As Integer
        Try

            strXML = strXML.ToUpper()
            'remove html tags

            strXML = strXML.Replace("<SUBJECT_INDEX></SUBJECT_INDEX>", "")
            strXML = strXML.Replace(srchtag, ">" & srchtag & "<")
            strXML = System.Text.RegularExpressions.Regex.Replace(strXML, "<.*?>", String.Empty)
            strXML = strXML.Replace(":", "").Replace("'", "").Replace("""", "")
            startindex = strXML.IndexOf(srchtag)

            While startindex <> -1
                endindex = strXML.IndexOf(srchtag, startindex + 3)
                substr = strXML.Substring(startindex + srchtag.Length, endindex - (startindex + srchtag.Length))

                If substr.Contains(" - ") Then
                    strlevel1 = substr.Substring(0, substr.IndexOf(" - "))
                    strlevel2 = substr.Substring(substr.IndexOf(" - ") + 3)
                    'MsgBox(strlevel1 & " & " & strlevel2)
                    SubArrList.Add(strlevel1 & "#" & strlevel2)
                    startindex = strXML.IndexOf(srchtag, endindex + 3)
                Else
                    strlevel1 = substr
                    dashindex = strXML.IndexOf(" - ", endindex + 3)
                    startindex = strXML.IndexOf(srchtag, endindex + 3)
                    If startindex <> -1 And dashindex < startindex And dashindex < endindex + 100 Then
                        strlevel2 = strXML.Substring(endindex + srchtag.Length, dashindex - (endindex + srchtag.Length))
                        SubArrList.Add(strlevel1 & "#" & strlevel2)
                    ElseIf startindex = -1 And dashindex < endindex + 100 Then
                        strlevel2 = strXML.Substring(endindex + srchtag.Length, dashindex - (endindex + srchtag.Length))
                        SubArrList.Add(strlevel1 & "#" & strlevel2)
                    Else
                        SubArrList.Add(strlevel1)
                    End If

                End If


            End While

        Catch ex As Exception
            SubArrList.Clear()

        End Try

        Return SubArrList
    End Function

    'Public Function UploadSubjectIndex() As Boolean

    '    Dim fnstr, strlevel1, strlevel2 As String
    '    'getSubjectIndexID
    '    Try



    '        Dim strxmlcontent As String
    '        Dim SubArrList As New ArrayList()

    '        strxmlcontent = My.Computer.FileSystem.ReadAllText(FileXmlToClass)


    '        SubArrList = getSubjectIndex(strxmlcontent)
    '        If SubArrList.Count > 0 Then

    '            For Each sbstr As String In SubArrList
    '                fnstr = System.IO.Path.GetFileName(FileXmlToClass)
    '                Dim levels As String() = sbstr.Split(New Char() {"#"c})

    '                If levels.Length > 1 Then
    '                    strlevel1 = levels(0)
    '                    strlevel2 = levels(1)
    '                ElseIf levels.Length = 1 Then
    '                    strlevel1 = levels(0)
    '                    strlevel2 = ""
    '                Else
    '                    Continue For
    '                End If
    '                Dim subjectindexid As Integer = getSubjectIndexID(strlevel1, strlevel2)
    '                If subjectindexid = -1 Then

    '                    ''''''''''''''''''''''''''''''''''Delete SubjectIndex'''''''''''''''''''''''''''''''''''''''''''''''
    '                    'Dim delSqlUni As String = "Delete from subjectindex_unique where LEVEL1 = '" & strlevel1.Trim() & "' AND LEVEL2 ='" & strlevel2.Trim() & "' "
    '                    'AddRecord(delSqlUni)

    '                    Dim delSqlUpload As String = "Delete from upload_subjectindex where mlrcitation = '" & System.IO.Path.GetFileName(FileXmlToClass).ToUpper() & "'  "
    '                    AddRecord(delSqlUpload)

    '                    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''


    '                    Dim insSQL As String
    '                    insSQL = "insert into subjectindex_unique (level1,level2) values ('" & strlevel1 & "','" & strlevel2 & "')"

    '                    If AddRecord(insSQL) = True Then
    '                        subjectindexid = getSubjectIndexID(strlevel1, strlevel2)
    '                        insSQL = "insert into upload_subjectindex (mlrcitation,level1,level2,subjectindexid) values ('" & System.IO.Path.GetFileName(FileXmlToClass).ToUpper().Replace(".XML", "") & "','" & strlevel1 & "','" & strlevel2 & "'," & subjectindexid & ")"
    '                        AddRecord(insSQL)
    '                    End If

    '                    ' My.Computer.FileSystem.WriteAllText("C:\Elaw\abdoadmin\subjectindex.txt", System.IO.Path.GetFileName(FileXmlToClass) & "  =  " & strlevel1 & "#" & strlevel2 & "   " & subjectindexid & vbCrLf, True)
    '                Else
    '                    'Dim insSQL As String
    '                    'insSQL = "insert into upload_subjectindex (mlrcitation,level1,level2,subjectindexid) values ('" & System.IO.Path.GetFileName(FileXmlToClass).ToUpper().Replace(".XML", "") & "','" & strlevel1 & "','" & strlevel2 & "'," & subjectindexid & ")"
    '                    'AddRecord(insSQL)

    '                    Dim mlrcitation As String = System.IO.Path.GetFileName(FileXmlToClass).ToUpper()
    '                    Dim delSqlUpload As String = "Delete from upload_subjectindex where mlrcitation = '" & mlrcitation & "'  "
    '                    AddRecord(delSqlUpload)


    '                    Dim insSQL As String
    '                    insSQL = "insert into upload_subjectindex (mlrcitation,level1,level2,subjectindexid) values ('" & System.IO.Path.GetFileName(FileXmlToClass).ToUpper() & "','" & strlevel1 & "','" & strlevel2 & "'," & subjectindexid & ")"
    '                    AddRecord(insSQL)

    '                End If

    '            Next
    '            Return True
    '        End If

    '    Catch ex As Exception
    '        Return False
    '    End Try
    '    Return False


    'End Function
    'here>>>>
    Public Function UploadSubjectIndex() As Boolean

        Dim fnstr, strlevel1, strlevel2 As String
        'getSubjectIndexID
        Try

            Dim strxmlcontent As String
            Dim SubArrList As New ArrayList()

            strxmlcontent = My.Computer.FileSystem.ReadAllText(FileXmlToClass)


            SubArrList = getSubjectIndex(strxmlcontent)
            If SubArrList.Count > 0 Then

                Dim s_mlrcitation As String = System.IO.Path.GetFileName(FileXmlToClass).ToUpper().Replace(".XML", "").Replace(".xml", "")

                Dim delSubIndex As String = "Delete from upload_subjectindex where mlrcitation = '" & s_mlrcitation & "' or  mlrcitation='" & s_mlrcitation & ".xml' or mlrcitation='" & s_mlrcitation & " .xml"
                AddRecord(delSubIndex)

                For Each sbstr As String In SubArrList
                    fnstr = System.IO.Path.GetFileName(FileXmlToClass)
                    Dim levels As String() = sbstr.Split(New Char() {"#"c})

                    If levels.Length > 1 Then
                        strlevel1 = levels(0)
                        strlevel2 = levels(1)
                    ElseIf levels.Length = 1 Then
                        strlevel1 = levels(0)
                        strlevel2 = ""
                    Else
                        Continue For
                    End If
                    Dim subjectindexid As Integer = getSubjectIndexID(strlevel1, strlevel2)
                    If subjectindexid = -1 Then

                        ''''''''''''''''''''''''''''''''''Delete SubjectIndex'''''''''''''''''''''''''''''''''''''''''''''''
                        'Dim delSqlUni As String = "Delete from subjectindex_unique where LEVEL1 = '" & strlevel1.Trim() & "' AND LEVEL2 ='" & strlevel2.Trim() & "' "
                        'AddRecord(delSqlUni)

                        Dim mlrcitation As String = System.IO.Path.GetFileName(FileXmlToClass).ToUpper().Replace(".XML", "").Replace(".xml", "")
                        Dim delSqlUpload As String = "Delete from upload_subjectindex where mlrcitation = '" & mlrcitation & "'  "
                        AddRecord(delSqlUpload)

                        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                        Dim insSQL As String
                        insSQL = "insert into subjectindex_unique (level1,level2) values ('" & strlevel1 & "','" & strlevel2 & "')"

                        If AddRecord(insSQL) = True Then
                            subjectindexid = getSubjectIndexID(strlevel1, strlevel2)
                            insSQL = "insert into upload_subjectindex (mlrcitation,level1,level2,subjectindexid) values ('" & System.IO.Path.GetFileName(FileXmlToClass).ToUpper().Replace(".XML", "").Replace(".xml", "") & "','" & strlevel1 & "','" & strlevel2 & "'," & subjectindexid & ")"
                            AddRecord(insSQL)
                        End If

                    Else

                        'Dim mlrcitation As String = System.IO.Path.GetFileName(FileXmlToClass).ToUpper()
                        'Dim delSqlUpload As String = "Delete from upload_subjectindex where mlrcitation = '" & mlrcitation & "'  "
                        'AddRecord(delSqlUpload)


                        Dim insSQL As String
                        insSQL = "insert into upload_subjectindex (mlrcitation,level1,level2,subjectindexid) values ('" & System.IO.Path.GetFileName(FileXmlToClass).ToUpper().Replace(".XML", "").Replace(".xml", "") & "','" & strlevel1 & "','" & strlevel2 & "'," & subjectindexid & ")"
                        AddRecord(insSQL)
                        ' My.Computer.FileSystem.WriteAllText("C:\Elaw\abdoadmin\subjectindex.txt", System.IO.Path.GetFileName(FileXmlToClass) & "  =  " & strlevel1 & "#" & strlevel2 & "   " & subjectindexid & vbCrLf, True)
                    End If

                Next
                Return True
            End If

        Catch ex As Exception
            Return False
        End Try
        Return False


    End Function

    'Rozidee added 2016-01-20
    Public Function GetFileName(ByVal fileLocation As String) As String
        Dim arr As String() = fileLocation.Split({"\"}, StringSplitOptions.RemoveEmptyEntries)
        Dim filename As String = ""
        If fileLocation.Contains(".xml") Or fileLocation.Contains(".XML") Then
            filename = arr(arr.Count - 1).Replace(".xml", "").Replace(".XML", "")
        Else
            filename = arr(arr.Count - 1).Replace(".pdf", "").Replace(".PDF", "")
        End If

        Return filename
    End Function

    Public Function AddingBracketToCitation(ByVal strCitation As String) As String
        Dim result As String = ""
        result = strCitation.Insert(0, "[")
        result = result.Insert(5, "]")
        Return result
    End Function


    Public Function CitationFromBracketToNon(ByVal strCitation As String) As String
        Dim returnValue As String = ""
        Dim arr As String()
        arr = strCitation.Split({" "}, StringSplitOptions.RemoveEmptyEntries)
        If arr.Count = 3 Then
            returnValue = arr(1) & "_" & arr(0) & "_" & arr(2)
        Else
            returnValue = arr(2) & "_" & arr(0) & "_" & arr(1) & "_" & arr(3)
        End If
        Return returnValue.Replace("[", "").Replace("]", "")
    End Function

    Public Function CitationFromNonToBracket(ByVal strCitation As String) As String
        Dim returnValue As String = ""
        Dim arr As String()
        arr = strCitation.Split({"_"}, StringSplitOptions.RemoveEmptyEntries)
        If arr.Count = 3 Then
            returnValue = "[" & arr(1) & "] " & arr(0) & " " & arr(2)
        Else
            returnValue = "[" & arr(1) & "] " & arr(2) & " " & arr(0) & " " & arr(3)
        End If
        Return returnValue
    End Function

    Public Function XMLFileChecker(ByVal xmlpath As String) As Boolean
        Error_XMLFile = ""
        Dim xmlDoc As XmlDocument = New XmlDocument()
        Try
            xmlDoc.Load(xmlpath)
            Return True
        Catch ex As Exception
            Error_XMLFile = ex.Message.ToString
            Return False
        End Try
    End Function

    Public Function UploadCaseProgression() As String
		ListOfCaseProgression = ""
        Dim xmlDoc As XmlDocument = New XmlDocument

        If XMLFileChecker(FileXmlToClass) = False Then 'checker fromat
            'Return Error_XMLFile

        Else ' NO ERROR OCCURED

            xmlDoc.Load(FileXmlToClass)

            Dim root As String = xmlDoc.DocumentElement.Name
            Dim Nodelst As XmlNodeList 
			Nodelst = xmlDoc.GetElementsByTagName("CASE_PROGRESSION")

            Dim XmlSub As New XmlDocument
            Dim xmlLink As XmlNodeList

            'Connection For SQL =========================================
            Dim dTable As New DataTable
            Dim strSQL As String = ""
            '============================================================

            'If Nodelst.Count > 0 Then
            '    For Each xn As XmlNode In Nodelst
            '        XmlSub.LoadXml(xn.OuterXml())
            '        xmlLink = XmlSub.GetElementsByTagName("LINK")
            '        If xmlLink.Count > 0 Then
            '            'clear listofcaseprogression
            '            ListOfCaseProgression = ""
            '            For i = 0 To xmlLink.Count - 1
            '                Dim strLink = xmlLink(i).InnerXml
            '                'search wether case progression is existed or not

            '                strSQL = "select * from casehistory where caseid='" & GetFileName( & "' and casehistory='" & strLink & "'"

            '                'strSQL = "select * from casehistory where casehistory='" & CitationFromBracketToNon(strLink) & "' and casehistory='" & CitationFromNonToBracket(GetFileName(FileNameToClass)) & "'"
            '                dTable = EXcuteQuery(strSQL)
            '                If dTable.Rows.Count > 0 Then
            '                    strSQL = "delete from casehistory where caseid='" & CitationFromBracketToNon(strLink) & "' and casehistory='" & CitationFromNonToBracket(GetFileName(FileNameToClass)) & "'"
            '                    dTable = EXcuteQuery(strSQL)
            '                End If

            '                ' add strLInk into case_progression list
            '                ListOfCaseProgression &= CitationFromBracketToNon(strLink) & "<BR/>"

            '                strSQL = "insert into casehistory (caseid, casehistory) values('" & CitationFromBracketToNon(strLink) & "','" & CitationFromNonToBracket(GetFileName(FileNameToClass)) & "')"
            '                dTable = EXcuteQuery(strSQL)
            '            Next

            '            'Return ""
            '        Else
            '            ' NO LINKING INSIDE CASE_PROGRESSION TAG
            '        End If
            '    Next
            'Else
            '    'NO CASE PROGRESSION TAG
            'End If
            If Nodelst.Count > 0 Then
                For Each xn As XmlNode In Nodelst
                    XmlSub.LoadXml(xn.OuterXml())
                    xmlLink = XmlSub.GetElementsByTagName("LINK")
                    If xmlLink.Count > 0 Then
                        strSQL = "select * from casehistory where caseid='" & GetFileName(FileNameToClass) & "'" ' and casehistory='" & strLink & "'"
                        dTable = EXcuteQuery(strSQL)
                        If dTable.Rows.Count > 0 Then
                            strSQL = "delete from casehistory where caseid='" & GetFileName(FileNameToClass) & "'" ' and casehistory='" & CitationFromNonToBracket(GetFileName(fileName)) & "'"
                            dTable = EXcuteQuery(strSQL)
                        End If

                        For i = 0 To xmlLink.Count - 1
                            Dim strLink = xmlLink(i).InnerXml
                            'search wether case progression is existed or not
                            'MsgBox(AddingBracketToCitation(strLink))
                            'MsgBox(GetFileName(fileName))

                            ' add strLInk into case_progression list
                            ListOfCaseProgression &= CitationFromBracketToNon(strLink) & "<br/>"

                            strSQL = "insert into casehistory (caseid, casehistory) values('" & GetFileName(FileNameToClass) & "','" & strLink & "')"
                            dTable = EXcuteQuery(strSQL)
                        Next
                    Else

                    End If
                Next
            Else
                'No case progression
            End If


        End If

        Return Error_XMLFile
    End Function

    Public Overloads Function AddRecord(ByVal Query As String) As Boolean
        'Dim Query As String = "insert into tblUserPrimary "
        AddRecord = False
        Dim Statement As String
        Statement = Query
        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand
        Try
            cmd.Connection = conn
            cmd.CommandType = CommandType.Text
            cmd.CommandText = Query
            conn.Open()
            cmd.ExecuteNonQuery()

            AddRecord = True
        Catch err As Exception
            AddRecord = False
            Throw New Exception("Error in inserting to DB  " & err.Message)


        Finally
            conn.Close()
            cmd = Nothing
        End Try
        Return AddRecord

    End Function

    Public Overloads Function UpdateRecord(ByVal Query As String) As Boolean
        'Dim Query As String = "insert into tblUserPrimary "
        UpdateRecord = False
        Dim Statement As String
        Statement = Query
        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand
        Try
            cmd.Connection = conn
            cmd.CommandType = CommandType.Text
            cmd.CommandText = Query
            conn.Open()
            cmd.ExecuteNonQuery()

            UpdateRecord = True
        Catch err As Exception
            UpdateRecord = False
            Throw New Exception("Error in update record in database.   " & err.Message)

        Finally
            conn.Close()
            cmd = Nothing

        End Try
        Return UpdateRecord

    End Function


    Public Overloads Function DeleteRecord(ByVal Query As String) As Boolean
        DeleteRecord = False
        Dim Statement As String
        Statement = Query
        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand
        Try
            cmd.Connection = conn
            cmd.CommandType = CommandType.Text
            cmd.CommandText = Query
            conn.Open()
            cmd.ExecuteNonQuery()
            conn.Close()
            DeleteRecord = True
        Catch err As Exception
            Throw New Exception("Error in inserting to DB  " & err.Message)
            DeleteRecord = False

        Finally
            conn.Close()
            cmd.Dispose()
        End Try
        Return DeleteRecord

    End Function

    Public Function getSubjectIndexID(ByVal strlevel1 As String, ByVal strlevel2 As String) As Integer

        Dim SUBINDEXID As Integer
        Dim SUBINDEXDT As New DataTable
        Dim con As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand

        Try
            ' Dim strSelect As String = "select DATAFILENAME from " & TableName & " where DATAFILENAME=@CaseId "

            Dim strSelect As String

            If strlevel2.Trim() <> "" Then
                strSelect = "select subjindexid from subjectindex_unique where level1=@level1 and level2=@level2"
            Else
                strSelect = "select subjindexid from subjectindex_unique where level1=@level1"
            End If

            cmd.Connection = con
            cmd.CommandType = CommandType.Text
            cmd.CommandText = strSelect
            Dim Sqllevel1 As New SqlParameter("@level1", SqlDbType.VarChar, 200)
            Dim Sqllevel2 As New SqlParameter("@level2", SqlDbType.VarChar, 250)

            Sqllevel1.Value = strlevel1
            cmd.Parameters.Add(Sqllevel1)

            If strlevel2.Trim() <> "" Then
                Sqllevel2.Value = strlevel2
                cmd.Parameters.Add(Sqllevel2)
            End If

            con.Open()
            SUBINDEXDT.Load(cmd.ExecuteReader())

            If SUBINDEXDT.Rows.Count > 0 Then
                SUBINDEXID = Integer.Parse(SUBINDEXDT.Rows(0)(0).ToString())
            Else
                SUBINDEXID = -1
            End If

        Catch ex As Exception
            SUBINDEXID = -1
        Finally
            con.Close()
        End Try

        Return SUBINDEXID
    End Function

    Public Function IsCaseExist(ByVal TableName As String, ByVal CaseID As String) As Boolean
        Dim isexist As Boolean
        Dim con As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand
        Try
            Dim strSelect As String = "select DATAFILENAME from " & TableName & " where DATAFILENAME=@CaseId "
            cmd.Connection = con
            cmd.CommandType = CommandType.Text
            cmd.CommandText = strSelect

            Dim SqlCaseId As New SqlParameter("@CaseId", SqlDbType.VarChar, 30)
            SqlCaseId.Value = CaseID.Trim().ToString()
            cmd.Parameters.Add(SqlCaseId)
            con.Open()

            Dim result As Object = cmd.ExecuteScalar()
            If result Is Nothing = False Then
                isexist = True
            Else
                isexist = False
            End If

        Catch ex As Exception
            isexist = False
        Finally
            con.Close()
        End Try

        Return isexist
    End Function
    Public Function EXcuteQuery(ByVal Query As String) As DataTable
        Dim CasesInfo As New DataTable
        Dim con As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand()
        Try
            cmd.Connection = con
            cmd.CommandType = CommandType.Text
            cmd.CommandText = Query
            con.Open()
            CasesInfo.Load(cmd.ExecuteReader)
        Catch ex As Exception

        Finally
            con.Close()
        End Try

        Return CasesInfo
    End Function
    Private Function PrepareInsert_Statement(ByRef TableName As String, ByVal ParamArray ParametersNamesAndValues() As Object) As String
        Dim InsertString As String = ""

        If ParametersNamesAndValues.Length > 0 Then
            InsertString = "Insert into " & TableName & " ("

            For i As Integer = 0 To ParametersNamesAndValues.Length - 1 Step 2
                InsertString &= ParametersNamesAndValues(i)

                If i + 1 < ParametersNamesAndValues.Length - 1 Then
                    InsertString &= ","
                End If
            Next

            InsertString &= ") Values ("

            For i As Integer = 1 To ParametersNamesAndValues.Length - 1 Step 2
                If IsNumeric(ParametersNamesAndValues(i)) Then
                    InsertString &= ParametersNamesAndValues(i)
                Else
                    InsertString &= "'" & ParametersNamesAndValues(i) & "'"
                End If

                If i < ParametersNamesAndValues.Length - 1 Then
                    InsertString &= ","
                End If
            Next

            InsertString &= ")"
        End If

        Return InsertString

    End Function

    Private Function PrepareUpdate_Statement(ByRef TableName As String, ByVal SQL As String) As String
        Dim InsertString As String = ""
        If SQL.Length > 10 Then
            InsertString = SQL
        End If
        Return InsertString
    End Function

    Private Function PerpareInsertCaseReferred(ByVal TableName As String, ByVal XmlFile As String, ByVal DT As DataTable, ByVal T As String) As String
        Dim InsertString As String = ""
        Dim TempTitle As String = ""
        Dim GetCaseType As String
        Dim Refcase As String = ""
        InsertString = "Insert into " & TableName & " (RootCitation, RootTitle,ReferredCitation,ReferredTitle,COURT,FileLinkTO,TYPE) VALUES "
        For i = 0 To DT.Rows.Count - 1
            'DATAFILENAME, title,CITATION,COURT
            GetCaseType = ""
            'Refcase = DT.Rows(i).Item(0).ToString()
            Refcase = DT.Rows(i).Item(0).ToString().Replace("'", "")
            Dim SingleCaseItems As List(Of caseinfo) = CaseReferred.Where(Function(x) x.CaseId = Refcase).ToList()
            GetCaseType = SingleCaseItems(0).CaseTitle.ToString()
            Refcase = Refcase.Replace(".xml", "").Replace(".XML", "")
            TempTitle = DT.Rows(i).Item(1).ToString().Replace("'", "").Replace(",", "").Replace("""", "").Replace(";", "")
            InsertString &= "( '" & XmlFile.Replace(".xml", "").Replace(".XML", "") & "','" & T & "','" & DT.Rows(i).Item(2) & "','" & TempTitle & "','" & DT.Rows(i).Item(3) & "','" & Refcase & "','" & GetCaseType & "')"
            If i < DT.Rows.Count - 1 Then
                InsertString &= ", "
            End If
            TempTitle = ""
            GetCaseType = ""
            Refcase = ""
        Next
        Return InsertString
    End Function
    Private Function PerpareInsertLegislationReferred(ByVal TableName As String, ByVal XmlFile As String, ByVal LegReferred As List(Of LegStrcut), ByVal T As String) As String
        Dim InsertString As String = ""
        Dim ReLeg As String = ""
        Dim actTitle As String = ""

        InsertString = "Insert into " & TableName & " (root_citation, root_title,ReferredCitaion,RefferredTitle) VALUES "
        For i = 0 To LegReferred.Count - 1
            If LegReferred(i).actTitle <> "" Then
                If LegReferred(i).actTitle.Contains("'") Then
                    actTitle = LegReferred(i).actTitle.Replace("'", " ")

                Else
                    actTitle = LegReferred(i).actTitle
                End If

                ReLeg = LegReferred(i).secid.ToString()
                ReLeg = ReLeg.Replace(".xml", "").Replace(".XML", "")
                InsertString &= "( '" & XmlFile.Replace(".xml", "").Replace(".XML", "") & "','" & T & "','" & LegReferred(i).secid & "','" & actTitle & "')"
                'InsertString &= "( '" & XmlFile.Replace(".xml", "").Replace(".XML", "") & "','" & T & "','" & LegReferred(i).secid & "','" & LegReferred(i).actTitle & "')"
                If i < LegReferred.Count - 1 Then
                    InsertString &= ", "
                End If
            End If
            ReLeg = ""
        Next

        'InsertString = "Insert into " & TableName & " (root_citation, root_title,ReferredCitaion,RefferredTitle) VALUES "
        'For i = 0 To LegReferred.Count - 1
        '    If LegReferred(i).actTitle <> "" Then
        '        ReLeg = LegReferred(i).secid.ToString()
        '        ReLeg = ReLeg.Replace(".xml", "").Replace(".XML", "")
        '        InsertString &= "( '" & XmlFile.Replace(".xml", "").Replace(".XML", "") & "','" & T & "','" & LegReferred(i).secid & "','" & LegReferred(i).actTitle & "')"
        '        If i < LegReferred.Count - 1 Then
        '            InsertString &= ", "
        '        End If
        '    End If
        '    ReLeg = ""
        'Next
        Return InsertString
    End Function
    Private Function AddTitleSearchEngine(ByVal T As String) As Boolean
        Dim Query As String = ""
        Dim CheckTitle As String
        Dim count As Integer
        Dim conn As New SqlConnection(ConnectionString)
        Dim Flg As Boolean
        Query = "INSERT INTO SearchEngain_FrequencySearches (Qualifier, Phrase, flag) VALUES ('Exact Phrase', '" & T & "', 0)"
        CheckTitle = "Select count(*) from  SearchEngain_FrequencySearches where Phrase = '" & T & "'"
        Dim cmd As New SqlCommand(CheckTitle, conn)
        Try
            conn.Open()
            count = cmd.ExecuteScalar()
        Catch ex As Exception
        Finally
            cmd = Nothing
            Flg = False
            conn.Close()
        End Try
        If count = 0 Then
            Flg = AddRecord(Query)
        Else
            Flg = True
        End If
        Return Flg
    End Function
#End Region
#Region "Clear Tags From html Tags, String Process"
    Function Clear(ByVal Str As String) As String
        Dim Temp As String = Regex.Replace(Str, "<.*?>", " ")
        Temp = Temp.Replace("&amp;", "&")
        Temp = Temp.Replace("'", "''")
        Temp = Temp.Replace("""", " ")
        Temp = Temp.Replace(",", " ")

        Return Temp
    End Function

#End Region
#Region "eLaw New Counsel Strcture"
    Public Function AddingCounselToDB(ByVal FilePath As String) As String
        Dim _objCounsel As New COUNSELS
        _objCounsel = DeSerialXML(FilePath)
        Dim CounselList As New List(Of String)
        Dim FinalMessage As String = ""
        Dim StringToClean As String = ""
        If String.IsNullOrEmpty(_objCounsel.COUNSEL_ERROR) Then

            '=============== PREPARE TO DB SIDE 
            Dim QueryCount As Integer = 0
            Dim QueryList As New List(Of String)
            ''PLAINTIFF
            If _objCounsel.PLAINTIFF IsNot Nothing Then
                If _objCounsel.PLAINTIFF.FIRMS_NAME IsNot Nothing Then
                    QueryList.Add(_objCounsel.PLAINTIFF.FIRMS_NAME.ToString().Replace("'", ""))
                Else
                    QueryList.Add("")
                End If
                If _objCounsel.PLAINTIFF.PLAINTIFF_NAME IsNot Nothing Then

                    StringToClean = String.Join(",", _objCounsel.PLAINTIFF.PLAINTIFF_NAME)
                    StringToClean = StringToClean.ToString().Replace("'", "")
                    QueryList.Add(StringToClean)
                    CounselList.AddRange(_objCounsel.PLAINTIFF.PLAINTIFF_NAME)
                    QueryCount += 1
                Else
                    QueryList.Add("")
                End If
            Else
                QueryList.Add("")
                QueryList.Add("")
            End If
            ''RESPONDENT
            If _objCounsel.RESPONDENT IsNot Nothing Then
                If _objCounsel.RESPONDENT.FIRMS_NAME IsNot Nothing Then
                    QueryList.Add(_objCounsel.RESPONDENT.FIRMS_NAME.ToString().Replace("'", ""))
                Else
                    QueryList.Add("")
                End If
                If _objCounsel.RESPONDENT.RESPONDENT_NAME IsNot Nothing Then
                    StringToClean = ""
                    StringToClean = String.Join(",", _objCounsel.RESPONDENT.RESPONDENT_NAME)
                    StringToClean = StringToClean.ToString().Replace("'", "")
                    QueryList.Add(StringToClean)
                    CounselList.AddRange(_objCounsel.RESPONDENT.RESPONDENT_NAME)
                    QueryCount += 1
                Else
                    QueryList.Add("")
                End If
            Else
                QueryList.Add("")
                QueryList.Add("")
            End If
            ''INTERVENER
            If _objCounsel.INTERVENER IsNot Nothing Then
                If _objCounsel.INTERVENER.INTERVENER_FIRM IsNot Nothing Then
                    QueryList.Add(_objCounsel.INTERVENER.INTERVENER_FIRM.ToString().Replace("'", ""))
                Else
                    QueryList.Add("")
                End If
                If _objCounsel.INTERVENER.INTERVENER_NAME IsNot Nothing Then
                    StringToClean = ""
                    StringToClean = String.Join(",", _objCounsel.INTERVENER.INTERVENER_NAME)
                    StringToClean = StringToClean.ToString().Replace("'", "")
                    QueryList.Add(StringToClean)
                    QueryCount += 1
                Else
                    QueryList.Add("")
                End If
            Else
                QueryList.Add("")
                QueryList.Add("")
            End If
            ''LIQUIDATORS
            If _objCounsel.LIQUIDATORS IsNot Nothing Then
                If _objCounsel.LIQUIDATORS.LIQUIDATORS_FIRM IsNot Nothing Then
                    QueryList.Add(_objCounsel.LIQUIDATORS.LIQUIDATORS_FIRM.ToString().Replace("'", ""))
                Else
                    QueryList.Add("")
                End If
                If _objCounsel.LIQUIDATORS.LIQUIDATORS_NAME IsNot Nothing Then
                    StringToClean = ""
                    StringToClean = String.Join(",", _objCounsel.LIQUIDATORS.LIQUIDATORS_NAME)
                    StringToClean = StringToClean.ToString().Replace("'", "")
                    QueryList.Add(StringToClean)
                    QueryCount += 1
                Else
                    QueryList.Add("")
                End If
            Else
                QueryList.Add("")
                QueryList.Add("")
            End If
            ''WATCHING_BRIEF
            If _objCounsel.WATCHING_BRIEF IsNot Nothing Then
                If _objCounsel.WATCHING_BRIEF.WB_ORGANISATIONS IsNot Nothing Then
                    QueryList.Add(_objCounsel.WATCHING_BRIEF.WB_ORGANISATIONS.ToString().Replace("'", ""))
                Else
                    QueryList.Add("")
                End If
                If _objCounsel.WATCHING_BRIEF.WB_NAME IsNot Nothing Then
                    StringToClean = ""
                    StringToClean = String.Join(",", _objCounsel.WATCHING_BRIEF.WB_NAME)
                    StringToClean = StringToClean.ToString().Replace("'", "")
                    QueryList.Add(StringToClean)
                    QueryCount += 1
                Else
                    QueryList.Add("")
                End If
            Else
                QueryList.Add("")
                QueryList.Add("")
            End If
            ''AMICUS_CURIAE
            If _objCounsel.AMICUS_CURIAE IsNot Nothing Then
                If _objCounsel.AMICUS_CURIAE.A_CURIAE_FIRM IsNot Nothing Then
                    QueryList.Add(_objCounsel.AMICUS_CURIAE.A_CURIAE_FIRM.ToString().Replace("'", ""))
                Else
                    QueryList.Add("")
                End If
                If _objCounsel.AMICUS_CURIAE.A_CURIAE_NAME IsNot Nothing Then
                    StringToClean = ""
                    StringToClean = String.Join(",", _objCounsel.AMICUS_CURIAE.A_CURIAE_NAME)
                    StringToClean = StringToClean.ToString().Replace("'", "")
                    QueryList.Add(StringToClean)
                    QueryCount += 1
                Else
                    QueryList.Add("")
                End If
            Else
                QueryList.Add("")
                QueryList.Add("")
            End If

            ''THIRDPARTY
            If _objCounsel.THIRDPARTY IsNot Nothing Then
                If _objCounsel.THIRDPARTY.FIRMS_NAME IsNot Nothing Then
                    QueryList.Add(_objCounsel.THIRDPARTY.FIRMS_NAME.ToString().Replace("'", ""))
                Else
                    QueryList.Add("")
                End If
                If _objCounsel.THIRDPARTY.THIRDPARTY_NAME IsNot Nothing Then
                    StringToClean = ""
                    StringToClean = String.Join(",", _objCounsel.THIRDPARTY.THIRDPARTY_NAME)
                    StringToClean = StringToClean.ToString().Replace("'", "")
                    QueryList.Add(StringToClean)
                    QueryCount += 1
                Else
                    QueryList.Add("")
                End If
            Else
                QueryList.Add("")
                QueryList.Add("")
            End If
            '' call database Function IF Count Found More Than 0

            If QueryCount > 0 Then
                Dim ExtractFilename = Path.GetFileName(FilePath)
                Dim FinalQuery As String = "'" & ExtractFilename & "','" & String.Join("','", QueryList) & "'"
                '' before adding delete existing recored match file name 
                AddRecord("delete from [dbo].[eLaw_Plantiff_Respondent] where dataFile='" & ExtractFilename & "'")
                Dim IsAdded As Boolean = AddRecord("INSERT INTO [dbo].[eLaw_Plantiff_Respondent] VALUES(" & FinalQuery & ",'Tool_Upload')")
                FinalMessage = " The New Structure of Counsel Tag Added Successfully "

                ' Add Counsel List into Counsel Table 
                ' Remoev old Counsel from the list 
                If CounselList.Count > 0 Then
                    Dim StrCounselList As String = String.Join("','", CounselList).ToString()
                    Dim Isdeleted As Boolean = AddRecord("delete from [dbo].[Counsel_2016] where Counsel in('" & StrCounselList & "')")
                    If Isdeleted Then
                        StrCounselList = String.Join("'),('", CounselList).ToString()
                        AddRecord("INSERT INTO [dbo].[Counsel_2016] (Counsel) Values ('" & StrCounselList & "')")
                    End If

                End If

            Else
                FinalMessage = " Counsel New Structure Not Found In This File"
            End If


        End If
        Return FinalMessage + "<br> Error List " + _objCounsel.COUNSEL_ERROR + " <br>Counsel summary : <br>" + _objCounsel.SUMMARY & "<br> Counsel List : " & String.Join(",", CounselList)
    End Function
    ' here we send Counsel as text
    Private Function DeSerialXML(ByVal FilePath As String) As COUNSELS
        Dim _objCouncel As New COUNSELS
        Dim xDoc As New XmlDocument
        xDoc.Load(FilePath)
        Dim Tag_Text As String = ""

        Try
            If xDoc.GetElementsByTagName("PLAINTIFF").Count > 0 Then
                Tag_Text = xDoc.GetElementsByTagName("PLAINTIFF")(0).OuterXml.Replace("'", "")
                If Tag_Text.Length > 0 Then
                    Dim COUNSELS_Serializer As XmlSerializer = New XmlSerializer(GetType(PLAINTIFF))
                    _objCouncel.PLAINTIFF = CType(COUNSELS_Serializer.Deserialize(New StringReader(Tag_Text)), PLAINTIFF)
                End If
            Else
                _objCouncel.SUMMARY &= " PLAINTIFF NOT FOUND"
            End If
            If xDoc.GetElementsByTagName("RESPONDENT").Count > 0 Then
                Tag_Text = xDoc.GetElementsByTagName("RESPONDENT")(0).OuterXml.Replace("'", "")
                If Tag_Text.Length > 0 Then
                    Dim COUNSELS_Serializer As XmlSerializer = New XmlSerializer(GetType(RESPONDENT))
                    _objCouncel.RESPONDENT = CType(COUNSELS_Serializer.Deserialize(New StringReader(Tag_Text)), RESPONDENT)
                End If
            Else
                _objCouncel.SUMMARY &= " RESPONDENT NOT FOUND ,"
            End If
            '===============================
            If xDoc.GetElementsByTagName("INTERVENER").Count > 0 Then
                Tag_Text = xDoc.GetElementsByTagName("INTERVENER")(0).OuterXml.Replace("'", "")
                If Tag_Text.Length > 0 Then
                    Dim COUNSELS_Serializer As XmlSerializer = New XmlSerializer(GetType(INTERVENER))
                    _objCouncel.INTERVENER = CType(COUNSELS_Serializer.Deserialize(New StringReader(Tag_Text)), INTERVENER)
                End If
            Else
                _objCouncel.SUMMARY &= " INTERVENER NOT FOUND ,"
            End If
            '=========================
            If xDoc.GetElementsByTagName("LIQUIDATORS").Count > 0 Then
                Tag_Text = xDoc.GetElementsByTagName("LIQUIDATORS")(0).OuterXml.Replace("'", "")
                If Tag_Text.Length > 0 Then
                    Dim COUNSELS_Serializer As XmlSerializer = New XmlSerializer(GetType(LIQUIDATORS))
                    _objCouncel.LIQUIDATORS = CType(COUNSELS_Serializer.Deserialize(New StringReader(Tag_Text)), LIQUIDATORS)
                End If
            Else
                _objCouncel.SUMMARY &= " LIQUIDATORS NOT FOUND ,"
            End If
            '=========================
            '=========================
            If xDoc.GetElementsByTagName("WATCHING_BRIEF").Count > 0 Then
                Tag_Text = xDoc.GetElementsByTagName("WATCHING_BRIEF")(0).OuterXml.Replace("'", "")
                If Tag_Text.Length > 0 Then
                    Dim COUNSELS_Serializer As XmlSerializer = New XmlSerializer(GetType(WATCHING_BRIEF))
                    _objCouncel.WATCHING_BRIEF = CType(COUNSELS_Serializer.Deserialize(New StringReader(Tag_Text)), WATCHING_BRIEF)
                End If
            Else
                _objCouncel.SUMMARY &= " WATCHING_BRIEF NOT FOUND ,"
            End If
            '=========================
            If xDoc.GetElementsByTagName("AMICUS_CURIAE").Count > 0 Then
                Tag_Text = xDoc.GetElementsByTagName("AMICUS_CURIAE")(0).OuterXml.Replace("'", "")
                If Tag_Text.Length > 0 Then
                    Dim COUNSELS_Serializer As XmlSerializer = New XmlSerializer(GetType(AMICUS_CURIAE))
                    _objCouncel.AMICUS_CURIAE = CType(COUNSELS_Serializer.Deserialize(New StringReader(Tag_Text)), AMICUS_CURIAE)
                End If
            Else
                _objCouncel.SUMMARY &= " AMICUS_CURIAE NOT FOUND ,"
            End If
            '=========================
            If xDoc.GetElementsByTagName("THIRDPARTY").Count > 0 Then
                Tag_Text = xDoc.GetElementsByTagName("THIRDPARTY")(0).OuterXml.Replace("'", "")
                If Tag_Text.Length > 0 Then
                    Dim COUNSELS_Serializer As XmlSerializer = New XmlSerializer(GetType(THIRDPARTY))
                    _objCouncel.THIRDPARTY = CType(COUNSELS_Serializer.Deserialize(New StringReader(Tag_Text)), THIRDPARTY)
                End If
            Else
                _objCouncel.SUMMARY &= " THIRDPARTY NOT FOUND ,"
            End If
        Catch ex As Exception
            _objCouncel.COUNSEL_ERROR = "Please Check Counsel Tag : " & ex.ToString()
        End Try
        Return _objCouncel
    End Function
#End Region
End Class
<XmlRoot(ElementName:="PLAINTIFF")>
Public Class PLAINTIFF

    <XmlElement(ElementName:="PLAINTIFF_NAME")>
    Public Property PLAINTIFF_NAME As List(Of String)

    <XmlElement(ElementName:="FIRMS_NAME")>
    Public Property FIRMS_NAME As String
End Class
<XmlRoot(ElementName:="RESPONDENT")>
Public Class RESPONDENT
    <XmlElement(ElementName:="RESPONDENT_NAME")>
    Public Property RESPONDENT_NAME As List(Of String)
    <XmlElement(ElementName:="FIRMS_NAME")>
    Public Property FIRMS_NAME As String
End Class
<XmlRoot(ElementName:="INTERVENER")>
Public Class INTERVENER
    <XmlElement(ElementName:="INTERVENER_NAME")>
    Public Property INTERVENER_NAME As List(Of String)
    <XmlElement(ElementName:="INTERVENER_FIRM")>
    Public Property INTERVENER_FIRM As String
End Class
<XmlRoot(ElementName:="LIQUIDATORS")>
Public Class LIQUIDATORS
    <XmlElement(ElementName:="LIQUIDATORS_NAME")>
    Public Property LIQUIDATORS_NAME As List(Of String)
    <XmlElement(ElementName:="LIQUIDATORS_FIRM")>
    Public Property LIQUIDATORS_FIRM As String
End Class
<XmlRoot(ElementName:="WATCHING_BRIEF")>
Public Class WATCHING_BRIEF
    <XmlElement(ElementName:="WB_ORGANISATIONS")>
    Public Property WB_ORGANISATIONS As String
    <XmlElement(ElementName:="WB_NAME")>
    Public Property WB_NAME As List(Of String)
End Class
<XmlRoot(ElementName:="AMICUS_CURIAE")>
Public Class AMICUS_CURIAE
    <XmlElement(ElementName:="A_CURIAE_NAME")>
    Public Property A_CURIAE_NAME As List(Of String)
    <XmlElement(ElementName:="A_CURIAE_FIRM")>
    Public Property A_CURIAE_FIRM As String
End Class
<XmlRoot(ElementName:="THIRDPARTY")>
Public Class THIRDPARTY
    <XmlElement(ElementName:="THIRDPARTY_NAME")>
    Public Property THIRDPARTY_NAME As List(Of String)
    <XmlElement(ElementName:="FIRMS_NAME")>
    Public Property FIRMS_NAME As String
End Class
<XmlRoot(ElementName:="COUNSELS")>
Public Class COUNSELS
    <XmlElement(ElementName:="PLAINTIFF")>
    Public Property PLAINTIFF As PLAINTIFF
    <XmlElement(ElementName:="RESPONDENT")>
    Public Property RESPONDENT As RESPONDENT
    <XmlElement(ElementName:="INTERVENER")>
    Public Property INTERVENER As INTERVENER
    <XmlElement(ElementName:="LIQUIDATORS")>
    Public Property LIQUIDATORS As LIQUIDATORS
    <XmlElement(ElementName:="WATCHING_BRIEF")>
    Public Property WATCHING_BRIEF As WATCHING_BRIEF
    <XmlElement(ElementName:="AMICUS_CURIAE")>
    Public Property AMICUS_CURIAE As AMICUS_CURIAE
    <XmlElement(ElementName:="THIRDPARTY")>
    Public Property THIRDPARTY As THIRDPARTY
    Public Property COUNSEL_ERROR As String
    Public Property SUMMARY As String
End Class

