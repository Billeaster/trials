﻿Imports Microsoft.VisualBasic
Imports System.IO
Imports System.Data
Imports System.Data.SqlClient
Imports System.Xml

Public Class ClsLegislationUpload
    Public XmlFile As String
    Private ConnectionString As String
    Private Shared CnString As String
    Public Shared FileXmlToClass As String
    Public Shared FileNameToClass As String
    Public Sub New(ByVal conn As String)
        ConnectionString = ConfigurationSettings.AppSettings(conn)
        If ConnectionString = "" Then
            Throw New ApplicationException("Missing ConnectionString variable in web.config file.")
        End If
    End Sub
    ' Check If File Already upload before 
    Public Function IsXmlExit(ByVal XmlFile As String) As Boolean
        Dim flg As Boolean
        If File.Exists(XmlFile) = True Then
            flg = True
        End If
        Return flg
    End Function
#Region " Xml  "
    Public Function GetByTagName(ByVal XmlTag As String) As String
        Dim Title As String
        Title = ExtractTagInfo(XmlTag)
        Return Title
    End Function
    Public Function GetBooleanText() As String
        Dim Title As String
        Title = ReadXmlFile(FileXmlToClass)
        Return Title
    End Function
#Region "Get Single Tag Information"

    Public Function GetTitle() As String
        Dim Title As String
        Title = ExtractTagInfo("TITLE")
        Return Title
    End Function
    Public Function GetCountry() As String
        Dim Title As String
        Title = ExtractTagInfo("COUNTRY")
        Return Title
    End Function
    Public Function GetLanguage() As String
        Dim Title As String
        Title = ExtractTagInfo("LANGUAGE")
        Return Title
    End Function
    Public Function GetSubject() As String
        Dim Title As String
        Title = ExtractTagInfo("SUBJECT")
        Return Title
    End Function
    Public Function GetActNumber() As String
        Dim Title As String
        Title = ExtractTagInfo("NUMBER")
        Return Title
    End Function
    Public Function GetRoyalAssent() As String
        Dim Title As String
        Title = ExtractTagInfo("ROYALASSENT")
        Return Title
    End Function
    Public Function GetGazetteDate() As String
        Dim Title As String
        Title = ExtractTagInfo("GAZETTEDATE")
        Return Title
    End Function
    Public Function GetINforceForm() As String
        Dim Title As String
        Title = ExtractTagInfo("INFORCEFROM")
        Return Title
    End Function
    Public Function GetListOfAmendment() As String
        Dim Title As String
        Title = ExtractTagInfo("LISTOFAMENDMENTS")
        Return Title
    End Function
    Public Function GetPreamble() As String
        Dim Title As String
        Title = ExtractTagInfo("PREAMBLE")
        Return Title
    End Function

    Public Function GetPrincipalActNo() As String
        Dim Title As String
        Title = ExtractTagInfo("PRINCIPALACTNO")
        Return Title
    End Function

    Public Function GetPrincipalActTitle() As String
        Dim Title As String
        Title = ExtractTagInfo("PRINCIPALACTTITLE")
        Return Title
    End Function
    Public Function GetTableInParliamnet() As String
        Dim Title As String
        Title = ExtractTagInfo("TABLEINPARLIAMENT")
        Return Title
    End Function
#End Region
    Public Function ReadXmlFile(ByVal DirFilePath As String) As String
        Dim FileContent As New System.Text.StringBuilder()
        Dim Result As String
        Dim R As XmlTextReader = New XmlTextReader(DirFilePath)
        Try

            Do While R.Read
                If R.Value <> "" Then
                    FileContent.Append(R.Value)
                End If
            Loop
        Catch Err As Exception
            Result = Err.Message.ToString
        Finally
            Result = FileContent.ToString
            FileContent = Nothing

        End Try
        R.close()
        ReadXmlFile = Nothing
        Result = Clear(Result)
        Return Result
    End Function
    Private Function ExtractTagInfo(ByVal TagName As String) As String
        Dim TagInfo As String = ""
        Dim Info As New System.Text.StringBuilder()
        Dim Nodelst As XmlNodeList
        Dim XDoc As New XmlDocument()
        Try
            XDoc.Load(FileXmlToClass)
            Dim i As Integer
            Nodelst = XDoc.GetElementsByTagName(TagName)
            For i = 0 To Nodelst.Count - 1
                TagInfo = Trim(Nodelst(i).InnerXml())
                If TagInfo <> "" Then
                    Info.Append(TagInfo & " ")
                End If

            Next i
        Catch Exp As Exception
            TagInfo = Exp.Message.ToString
        End Try
        TagInfo = Info.ToString
        If Len(TagInfo) = 0 Then
            TagInfo = "" ' not to send null
        End If
        TagInfo = Clear(TagInfo)
        Return TagInfo
    End Function
    Public Function GetImgTag() As List(Of String)
        Dim img As New List(Of String)
        Dim XDoc As New XmlDocument()
        Dim Nodelst As XmlNodeList
        XDoc.Load(FileXmlToClass)
        'get REFERRED_CASES 
        Nodelst = XDoc.GetElementsByTagName("img")
        If Nodelst.Count Then
            For i = 0 To Nodelst.Count - 1
                img.Add(Nodelst(i).Attributes("src").Value)
            Next
        End If

        Return img
    End Function
#Region "Definition And Terms Extracting "
    Private Function ExtractTagDefi() As String
        Dim TagInfo As String = ""
        Dim Info As New System.Text.StringBuilder()
        Dim Nodelst As XmlNodeList
        Dim SNO As XmlNodeList
        Dim SNT As XmlNodeList
        Dim SNDefi As XmlNodeList
        Dim SNTerm As XmlNodeList
        Dim XDoc As New XmlDocument()
        Dim XmlSub As New XmlDocument
        '========================================
        Dim ArrSNO As New ArrayList
        Dim ArrST As New ArrayList
        Dim ArrDef As New ArrayList
        Dim ArrTerm As New ArrayList
        Dim StrActTitle As String = GetTitle()
        Dim StrActNO As String = GetActNumber()
        Dim flgDef As Boolean = True
        '========================================
        Dim na As String = ""
        Dim i As Integer
        Dim R As Integer
        Try
            XDoc.Load(FileXmlToClass)

            Nodelst = XDoc.GetElementsByTagName("SECTION")
            For Each xn As XmlNode In Nodelst
                If flgDef = False Then
                    Exit For
                End If
                R = R + 1
                XmlSub.LoadXml(xn.OuterXml())
                SNO = XmlSub.GetElementsByTagName("SNO")
                SNT = XmlSub.GetElementsByTagName("ST")
                SNDefi = XmlSub.GetElementsByTagName("DEFINITION")
                SNTerm = XmlSub.GetElementsByTagName("TERM")
                If SNDefi.Count > 0 Then
                    For i = 0 To SNDefi.Count - 1
                        If SNO.Count > 0 Then
                            ArrSNO.Add(Clear(SNO(0).InnerXml))
                        Else
                            flgDef = False

                        End If
                        If SNT.Count > 0 Then
                            ArrST.Add(Clear(SNT(0).InnerXml))
                        Else
                            flgDef = False
                        End If
                        If SNDefi(i).InnerXml <> "" Then
                            ArrDef.Add(Clear(SNDefi(i).InnerXml))
                        End If
                        If Not SNTerm(i) Is Nothing Then
                            If SNTerm(i).InnerXml <> "" And SNTerm(i).InnerXml <> Nothing Then
                                ArrTerm.Add(Clear(SNTerm(i).InnerXml))
                            End If
                        End If
                    Next
                End If
            Next
           
        Catch Exp As Exception
            TagInfo = Exp.Message.ToString
            Return TagInfo = "Error In Reading Section NO " & R
        End Try
        '==========Now Get Perpae Query 
        If flgDef <> False Then
            If ArrDef.Count > 0 Then
                If ArrTerm.Count = ArrDef.Count Then
                    TagInfo = PerpareInsertDefination("LEGTERMDEF", FileNameToClass, StrActTitle, StrActNO, ArrSNO, ArrST, ArrDef, ArrTerm)
                End If
            End If
        Else
            TagInfo = "Error In Reading Section NO " & R
        End If
        
        
        Return TagInfo
    End Function
#End Region
    
#Region " Extract Section"
    Private Function ExtractSectionsIntoQuery() As String
        Dim TempQuery As String
        Dim SectionTitle As String
        Dim SectionNo As String
        Dim StrQuery As New StringBuilder
        Dim ArrSecTitle As New ArrayList
        Dim ArrSecNo As New ArrayList
        StrQuery.Append("")
        Dim xRead As XmlTextReader = New XmlTextReader(FileXmlToClass)
        Try

            While xRead.Read()
                Select Case xRead.NodeType
                    Case XmlNodeType.Element
                        If xRead.Name = "SNO" Then
                            SectionNo = Trim(xRead.ReadInnerXml)
                            ArrSecNo.Add(SectionNo)
                        End If
                        If xRead.Name = "ST" Then
                            SectionTitle = Trim(xRead.ReadInnerXml)
                            SectionTitle = Clear(SectionTitle)
                            ArrSecTitle.Add(SectionTitle)
                        End If
                        
                End Select
            End While
        Catch ex As Exception
        End Try
        xRead.Close()
        If ArrSecNo.Count > 0 Then
            If CInt(ArrSecNo.Count) = CInt(ArrSecTitle.Count) Then
                TempQuery = PerpareInsertSection("secion_tb1", FileNameToClass.Replace(".xml", ""), ArrSecNo, ArrSecTitle)
            Else
                TempQuery = ""
            End If
        Else
            TempQuery = "NoSection"
        End If
        Return TempQuery
    End Function
#End Region

#End Region
#Region " Database  "

    Public Function UploadxmlFile() As String
        Dim flg As Boolean
        Dim StrError As String = ""
        Dim Query As String
        Dim fSize As Long = (New FileInfo(FileXmlToClass)).Length
        Dim PerpareQuery() As String
        Dim FileName As String = ""
        Dim Title As String = ""
        Dim YEAR As String = ""
        Dim LANGUAGE As String = ""
        Dim COUNTRY As String = ""
        Dim SUBJECT As String = ""
        Dim NUMBER As String = ""
        Dim ROYALASSENT As String = ""
        Dim TABLEINPARLIAMENT As String = ""
        Dim GAZETTEDATE As String = ""
        Dim INFORCEFROM As String = ""
        Dim LISTOFAMENDMENTS As String = ""
        Dim PREAMBLE As String = ""
        Dim PRINCIPALACTNO As String = ""
        Dim PrincipalActTitle As String = ""
        Dim LEGISLATIONTYPE As String = ""
        Dim BOOLEANTEXT As String = ""
        Dim FileSize As String = ""
        Dim State As String = ""
        Dim objDB As New clsDB()
        Dim CountryID As Int32
        Dim objUserCls As New clsUsers

        ' Check IF exist
        flg = isFileExist(FileNameToClass, "LEGISLATION", "datafilename")
        Dim FileSplit() As String = FileNameToClass.Split(New Char() {"_"c})
        ' Delete if exist 
        If flg = True Then
            Query = " Delete from LEGISLATION where datafilename= '" & FileNameToClass & "' "
            flg = DeleteRecord(Query)
        End If
        ' Get Content From All Tags 
        Try
            FileName = FileNameToClass
            Title = GetTitle()
            YEAR = FileSplit(2)
            LANGUAGE = GetLanguage().Trim()

            If LANGUAGE = "ENGLISH" Then
                LANGUAGE = "1"
            End If
            COUNTRY = GetCountry().Trim()

            CountryID = objDB.GetCountry(COUNTRY)

            'If COUNTRY = "MALAYSIA" Then
            '    COUNTRY = "1"
            'End If
            SUBJECT = GetSubject()
            NUMBER = GetActNumber()
            ROYALASSENT = GetRoyalAssent()
            TABLEINPARLIAMENT = GetTableInParliamnet()
            GAZETTEDATE = GetGazetteDate()
            INFORCEFROM = GetINforceForm()
            LISTOFAMENDMENTS = GetListOfAmendment()
            PREAMBLE = GetPreamble()
            ''New addition
            PRINCIPALACTNO = GetPrincipalActNo()
            PrincipalActTitle = GetPrincipalActTitle()
            LEGISLATIONTYPE = FileSplit(1)
            BOOLEANTEXT = GetBooleanText()
            FileSize = CStr(fSize)
            State = GetState(FileName)

            Dim sql As String = "Select * from States where StateName = '" & State.Trim() & "'"
            Dim DT As New DataTable
            DT = objUserCls.FetchDataSet(sql)

            If DT.Rows.Count > 0 Then
                State = DT.Rows(0)("StateID").ToString()
            End If

            If FileName.Contains("MY_ACTS") Or FileName.Contains("MY_PUAS") Or FileName.Contains("MY_AMEN") Then
                'State = "MALAYSIA"
                State = "14"
            End If

        Catch ex As Exception
            StrError = " Uploading was not Done Yet ,Please check xml file before uploading  " & ex.Message
            Return StrError
        End Try
        ' Build Query 
        Try
            'PerpareQuery = {"Datafilename", FileName, "TITLE", Title, "YEAR", YEAR, "LANGUAGE", LANGUAGE, "COUNTRY", COUNTRY, "SUBJECT", SUBJECT, "NUMBER", NUMBER,
            '          "ROYALASSENT", ROYALASSENT, "TABLEINPARLIAMENT", TABLEINPARLIAMENT, "GAZETTEDATE", GAZETTEDATE, "INFORCEFROM", INFORCEFROM,
            '          "LISTOFAMENDMENTS", LISTOFAMENDMENTS, "PREAMBLE", PREAMBLE, "PRINCIPALACTNO", PRINCIPALACTNO, "LEGISLATIONTYPE", LEGISLATIONTYPE,
            '          "BOOLEANTEXT", BOOLEANTEXT, "FileSize", FileSize, "States", State , "UploadedDate", DateTime.Now.Date.ToString("MM/dd/yyyy")}
            PerpareQuery = {"Datafilename", FileName, "TITLE", Title, "YEAR", YEAR, "LANGUAGE", LANGUAGE, "COUNTRY", CountryID, "SUBJECT", SUBJECT, "NUMBER", NUMBER,
                      "ROYALASSENT", ROYALASSENT, "TABLEINPARLIAMENT", TABLEINPARLIAMENT, "GAZETTEDATE", GAZETTEDATE, "INFORCEFROM", INFORCEFROM,
                      "LISTOFAMENDMENTS", LISTOFAMENDMENTS, "PREAMBLE", PREAMBLE, "PRINCIPALACTNO", PRINCIPALACTNO, "PrincipalActTitle", PrincipalActTitle, "LEGISLATIONTYPE", LEGISLATIONTYPE,
                      "BOOLEANTEXT", BOOLEANTEXT, "FileSize", FileSize, "States", State, "UploadedDate", DateTime.Now.Date.ToString("MM/dd/yyyy")}
            Query = PrepareInsert_Statement("LEGISLATION", PerpareQuery)

            flg = AddRecord(Query)
            StrError = "Upload & Insert Done"
        Catch ex As Exception
            flg = False
            StrError = "Uploading was not Done Yet " & ex.Message.ToString
        End Try
        Return StrError
    End Function


    'Public Function UploadxmlFile() As String
    '    Dim flg As Boolean
    '    Dim StrError As String = ""
    '    Dim Query As String
    '    Dim fSize As Long = (New FileInfo(FileXmlToClass)).Length
    '    Dim PerpareQuery() As String
    '    Dim FileName As String = ""
    '    Dim Title As String = ""
    '    Dim YEAR As String = ""
    '    Dim LANGUAGE As String = ""
    '    Dim COUNTRY As String = ""
    '    Dim SUBJECT As String = ""
    '    Dim NUMBER As String = ""
    '    Dim ROYALASSENT As String = ""
    '    Dim TABLEINPARLIAMENT As String = ""
    '    Dim GAZETTEDATE As String = ""
    '    Dim INFORCEFROM As String = ""
    '    Dim LISTOFAMENDMENTS As String = ""
    '    Dim PREAMBLE As String = ""
    '    Dim PRINCIPALACTNO As String = ""
    '    Dim PrincipalActTitle As String = ""
    '    Dim LEGISLATIONTYPE As String = ""
    '    Dim BOOLEANTEXT As String = ""
    '    Dim FileSize As String = ""
    '    Dim State As String = ""

    '    ' Check IF exist
    '    flg = isFileExist(FileNameToClass, "LEGISLATION", "datafilename")
    '    Dim FileSplit() As String = FileNameToClass.Split(New Char() {"_"c})
    '    ' Delete if exist 
    '    If flg = True Then
    '        Query = " Delete from LEGISLATION where datafilename= '" & FileNameToClass & "' "
    '        flg = DeleteRecord(Query)
    '    End If
    '    ' Get Content From All Tags 
    '    Try
    '        FileName = FileNameToClass
    '        Title = GetTitle()
    '        YEAR = FileSplit(2)
    '        LANGUAGE = GetLanguage()
    '        COUNTRY = GetCountry()
    '        SUBJECT = GetSubject()
    '        NUMBER = GetActNumber()
    '        ROYALASSENT = GetRoyalAssent()
    '        TABLEINPARLIAMENT = GetTableInParliamnet()
    '        GAZETTEDATE = GetGazetteDate()
    '        INFORCEFROM = GetINforceForm()
    '        LISTOFAMENDMENTS = GetListOfAmendment()
    '        PREAMBLE = GetPreamble()
    '        ''New addition
    '        PRINCIPALACTNO = GetPrincipalActNo()
    '        PrincipalActTitle = GetPrincipalActTitle()
    '        LEGISLATIONTYPE = FileSplit(1)
    '        BOOLEANTEXT = GetBooleanText()
    '        FileSize = CStr(fSize)
    '        State = GetState(FileName)

    '        If FileName.Contains("MY_ACTS") Or FileName.Contains("MY_PUAS") Or FileName.Contains("MY_AMEN") Then
    '            State = "MALAYSIA"
    '        End If

    '    Catch ex As Exception
    '        StrError = " Uploading was not Done Yet ,Please check xml file before uploading  " & ex.Message
    '        Return StrError
    '    End Try
    '    ' Build Query 
    '    Try
    '        'PerpareQuery = {"Datafilename", FileName, "TITLE", Title, "YEAR", YEAR, "LANGUAGE", LANGUAGE, "COUNTRY", COUNTRY, "SUBJECT", SUBJECT, "NUMBER", NUMBER,
    '        '          "ROYALASSENT", ROYALASSENT, "TABLEINPARLIAMENT", TABLEINPARLIAMENT, "GAZETTEDATE", GAZETTEDATE, "INFORCEFROM", INFORCEFROM,
    '        '          "LISTOFAMENDMENTS", LISTOFAMENDMENTS, "PREAMBLE", PREAMBLE, "PRINCIPALACTNO", PRINCIPALACTNO, "LEGISLATIONTYPE", LEGISLATIONTYPE,
    '        '          "BOOLEANTEXT", BOOLEANTEXT, "FileSize", FileSize, "States", State}
    '        PerpareQuery = {"Datafilename", FileName, "TITLE", Title, "YEAR", YEAR, "LANGUAGE", LANGUAGE, "COUNTRY", COUNTRY, "SUBJECT", SUBJECT, "NUMBER", NUMBER,
    '                  "ROYALASSENT", ROYALASSENT, "TABLEINPARLIAMENT", TABLEINPARLIAMENT, "GAZETTEDATE", GAZETTEDATE, "INFORCEFROM", INFORCEFROM,
    '                  "LISTOFAMENDMENTS", LISTOFAMENDMENTS, "PREAMBLE", PREAMBLE, "PRINCIPALACTNO", PRINCIPALACTNO, "PrincipalActTitle", PrincipalActTitle, "LEGISLATIONTYPE", LEGISLATIONTYPE,
    '                  "BOOLEANTEXT", BOOLEANTEXT, "FileSize", FileSize, "States", State, "UploadedDate", DateTime.Now.ToString()}
    '        Query = PrepareInsert_Statement("LEGISLATION", PerpareQuery)

    '        flg = AddRecord(Query)
    '        StrError = "Upload & Insert Done"
    '    Catch ex As Exception
    '        flg = False
    '        StrError = "Uploading was not Done Yet " & ex.Message.ToString
    '    End Try
    '    Return StrError
    'End Function





    Public Function GetState(ByVal s_FileName As String) As String
        Dim s_State As String = ""
        If s_FileName.Contains("png") Or s_FileName.Contains("pnag") Then
            s_State = "Penang"
        ElseIf s_FileName.Contains("JHOR") Or s_FileName.Contains("JOH") Then
            s_State = "Johor"
        ElseIf s_FileName.Contains("SWK") Or s_FileName.Contains("SRWK") Then
            s_State = "Sarawak"
        ElseIf s_FileName.Contains("SGOR") Or s_FileName.Contains("SEL_") Then
            s_State = "Selangor"



        ElseIf s_FileName.Contains("MLKA") Or s_FileName.Contains("MEL") Then
            s_State = "Melaka"
        ElseIf s_FileName.Contains("NSEM") Or s_FileName.Contains("NSE") Then
            s_State = "N. Sembilan"
        ElseIf s_FileName.Contains("PAHG") Or s_FileName.Contains("PAH") Then
            s_State = "Pahang"

        ElseIf s_FileName.Contains("PRAK") Or s_FileName.Contains("PRK") Then
            s_State = "Perak"
        ElseIf s_FileName.Contains("KEDH") Or s_FileName.Contains("KED") Then
            s_State = "Kedah"
        ElseIf s_FileName.Contains("PLIS") Or s_FileName.Contains("PER") Then
            s_State = "Perlis"
        ElseIf s_FileName.Contains("KLTN") Or s_FileName.Contains("KEL") Then
            s_State = "Kelantan"
        ElseIf s_FileName.Contains("TGNU") Or s_FileName.Contains("TER") Then
            s_State = "Terengganu"

        Else

        End If


        Return s_State
    End Function
    Public Function UploadSection() As String
        Dim SecError As String = ""
        ' Get Section Query to be inserted 
        Dim QueryInsert As String = ExtractSectionsIntoQuery()
        If QueryInsert.Contains("NoSection") = True Or QueryInsert = "" Then
            SecError = "Please  check Sections in this file"
            Return SecError
        End If
        Dim Query As String
        Dim flg As Boolean
        Try
            'Check before upload if file already upload
            flg = isFileExist(FileNameToClass.Replace(".xml", ""), "secion_tb1", "LegFile")
            Dim FileSplit() As String = FileNameToClass.Split(New Char() {"_"c})
            ' Delete if exist 
            If flg = True Then
                Query = " Delete from secion_tb1 where LegFile= '" & FileNameToClass.Replace(".xml", "") & "' "
                flg = DeleteRecord(Query)
            End If
        Catch ex As Exception
            SecError = ex.Message
        End Try
        'Insert Query Here 
        If QueryInsert <> "" Then
            flg = AddRecord(QueryInsert)
            If flg = True Then
                SecError = "All Section Inserted."
            End If
        Else
            SecError = "Please  check Sections in this file "
        End If
        Return SecError
    End Function
    Public Function UploadDefinition() As String
        Dim SecError As String = ""
        ' Get Section Query to be inserted 
        Dim QueryInsert As String = ExtractTagDefi()
        If QueryInsert.Contains("NoDefiniation") = True Then
            SecError = "NoDefiniation"
            Return SecError
        ElseIf QueryInsert.Contains("Error In Reading") Then
            SecError = "Please Check Section And Definitions Tags" & QueryInsert
            Return SecError
        End If
        Dim Query As String
        Dim flg As Boolean
        Try
            'Check before upload if file already upload
            flg = isFileExist(FileNameToClass, "LEGTERMDEF", "DATAFILENAME")
            ' Delete if exist 
            If flg = True Then
                Query = " Delete from LEGTERMDEF where DATAFILENAME= '" & FileNameToClass & "' "
                flg = DeleteRecord(Query)
            End If
        Catch ex As Exception
            SecError = ex.Message
        End Try
        'Insert Query Here 
        If QueryInsert <> "" Then
            flg = AddRecord(QueryInsert)
            If flg = True Then
                SecError = "All Definition Inserted."
            End If
        Else
            SecError = "There is No Definition To Upload"
        End If
        Return SecError
    End Function
    Public Overloads Function isFileExist(ByVal FileName As String, ByVal TableName As String, ByVal ColName As String) As Boolean
        Dim FileCount As Int32 ' Because DataFile will always be 1 if it exist in table
        Dim ErrMsg As String
        Dim DT As New DataTable()
        Dim msg As String
        Dim Query As String = "select count(*) from " & TableName & " where " & ColName & " = '" & FileName & "'"
        Try
            DT = Me.ExecuteMyQuery(Query)
            FileCount = CInt(DT.Rows(0).Item(0))
            If FileCount = 0 Then
                isFileExist = False ' file not Exist
            Else
                isFileExist = True   ' File Exist
            End If
        Catch err As Exception
            msg = err.Message
        Finally
            FileCount = 0
            ErrMsg = ""
            DT = Nothing
            Query = ""
        End Try
        Return isFileExist
    End Function
    Public Function ExecuteMyQuery(ByVal Query As String) As DataTable
        Dim DT As New DataTable()
        Dim conn As New SqlConnection(ConnectionString)
        Dim MSG As String
        Try
            Dim cmd As New SqlCommand(Query, conn)
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)
        Catch err As Exception
            'Throw New ApplicationException("Error in connecting to DB  " & err.Message)
            MSG = err.Message
        Finally
            conn.Close()
        End Try
        Return DT
    End Function
#Region "Some Other Work"
    Private Function CheckConnection() As Boolean
        Dim Ck As Boolean = False
        Dim builder As New System.Data.SqlClient.SqlConnectionStringBuilder()
        builder.ConnectionString = ConnectionString
        Try
            Dim server As String = builder.DataSource
            Dim database As String = builder.InitialCatalog
            Dim password As String = builder.Password
            Dim url As String = HttpContext.Current.Request.Url.AbsoluteUri
            If server <> "" And database <> "" Then
                Ck = True
            End If
        Catch ex As Exception
            Ck = False
        End Try
        Return Ck
    End Function
    Private Sub CheckFilesLocation(strpath As String)
        Dim ori As String = strpath
        Dim position As Integer = strpath.LastIndexOf("\"c)
        strpath = strpath.Substring(0, position + 1)
        For Each file1 As String In Directory.GetFiles(strpath)
            If file1 <> ori Then
                File.Delete(file1)
            End If
        Next
        For Each subfolder As String In Directory.GetDirectories(strpath)
            CheckFilesLocation(subfolder)
        Next
        ' Directory.Delete(strpath, True)
    End Sub
#End Region


    Public Overloads Function DeleteRecord(ByVal Query As String) As Boolean
        DeleteRecord = False
        Dim Statement As String
        Statement = Query
        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand
        Try
            cmd.Connection = conn
            cmd.CommandType = CommandType.Text
            cmd.CommandText = Query
            conn.Open()
            cmd.ExecuteNonQuery()
            conn.Close()
            DeleteRecord = True
        Catch err As Exception
            Throw New Exception("Error in inserting to DB  " & err.Message)
            DeleteRecord = False
        Finally
            conn.Close()
            cmd.Dispose()
        End Try
        Return DeleteRecord
    End Function
    Private Function PrepareInsert_Statement(ByRef TableName As String, ByVal ParamArray ParametersNamesAndValues() As Object) As String
        Dim InsertString As String = ""

        If ParametersNamesAndValues.Length > 0 Then
            InsertString = "Insert into " & TableName & " ("

            For i As Integer = 0 To ParametersNamesAndValues.Length - 1 Step 2
                InsertString &= ParametersNamesAndValues(i)

                If i + 1 < ParametersNamesAndValues.Length - 1 Then
                    InsertString &= ","
                End If
            Next
            InsertString &= ") Values ("
            For i As Integer = 1 To ParametersNamesAndValues.Length - 1 Step 2
                If IsNumeric(ParametersNamesAndValues(i)) Then
                    InsertString &= ParametersNamesAndValues(i)
                Else
                    InsertString &= "'" & ParametersNamesAndValues(i) & "'"
                End If
                If i < ParametersNamesAndValues.Length - 1 Then
                    InsertString &= ","
                End If
            Next
            InsertString &= ")"
        End If

        Return InsertString

    End Function
    Private Function PerpareInsertSection(ByVal TableName As String, ByVal XmlFile As String, ByVal arrNo As ArrayList, ByVal arrTitle As ArrayList) As String
        Dim InsertString As String = ""
        InsertString = "Insert into " & TableName & " (sec_no, sec_title, LegFile) VALUES "
        For i = 0 To arrNo.Count - 1
            InsertString &= "( '" & arrNo.Item(i) & "','" & arrTitle.Item(i) & "','" & XmlFile & "')"
            If i < arrNo.Count - 1 Then
                InsertString &= ", "
            End If
        Next
        Return InsertString
    End Function
    Private Function PerpareInsertDefination(ByVal TableName As String, ByVal XmlFile As String, ByVal XmlTitle As String, ByVal xmlActNo As String, ByVal arrSNo As ArrayList, ByVal arrSTitle As ArrayList, ByVal arrSDefination As ArrayList, ByVal arrSTerm As ArrayList) As String
        Dim InsertString As String = ""
        InsertString = "Insert into " & TableName & " (DATAFILENAME, Terms,Definations,SNo,St,NUMBER,TITLE) VALUES "
        For i = 0 To arrSNo.Count - 1
            InsertString &= "( '" & XmlFile & "','" & arrSTerm.Item(i) & "','" & arrSDefination.Item(i) & "','" & arrSNo.Item(i) & "','" & arrSTitle.Item(i) & "','" & xmlActNo & "','" & XmlTitle & "')"
            If i < arrSNo.Count - 1 Then
                InsertString &= ", "
            End If

        Next
        Return InsertString
    End Function
    Public Overloads Function AddRecord(ByVal Query As String) As Boolean
        'Dim Query As String = "insert into tblUserPrimary "
        AddRecord = False
        Dim Statement As String
        Statement = Query
        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand
        Try
            cmd.Connection = conn
            cmd.CommandType = CommandType.Text
            cmd.CommandText = Query
            conn.Open()
            'If Query.Contains("False") Then

            'Else
            '    cmd.ExecuteNonQuery()
            '    AddRecord = True

            'End If

            'AddRecord = True

            cmd.ExecuteNonQuery()
            AddRecord = True


        Catch err As Exception
            AddRecord = False
            Throw New Exception("Error in inserting to DB  " & err.Message)


        Finally
            conn.Close()
            cmd = Nothing
        End Try
        Return AddRecord

    End Function
#End Region
#Region "Clear Tags From html Tags"
    Function Clear(ByVal Str As String) As String
        Dim Temp As String = Regex.Replace(Str, "<.*?>", " ")
        Temp = Temp.Replace("&amp;", "&")
        Temp = Temp.Replace("'", "''")
        Temp = Temp.Replace("""", " ")
        Temp = Temp.Replace(",", " ")

        Return Temp
    End Function
#End Region
End Class
