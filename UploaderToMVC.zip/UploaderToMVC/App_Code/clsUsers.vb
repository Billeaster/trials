


Imports System.Data.SqlClient
Imports System.Exception





Public Class clsUsers
    Private ConnectionString As String
    Private Shared CnString As String
    Public Sub New()

        ConnectionString = ConfigurationSettings.AppSettings("ConnectionString")

        If ConnectionString = "" Then
            Throw New ApplicationException("Missing ConnectionString variable in web.config file.")
        End If

    End Sub


    Public Function loadCountries1(ByVal drop) As SqlClient.SqlDataReader
        Dim conn As New SqlConnection(ConnectionString)
        Dim Query As String = "select country from country"
        Dim Reader1 As SqlClient.SqlDataReader
        Dim cmd As New SqlCommand(Query, conn)


        Dim DS As DataSet = FetchDataSet(Query, "Country")
        conn.Open()
        Reader1 = cmd.ExecuteReader

        '        Dim adapter As New SqlDataAdapter(cmd)

        '       adapter.Fill(DS, tblName)
        conn.Close()

        Return Reader1


    End Function

    Public Function getMaxUserIdNo() As Long

        'Dim ds As New DataSet()
        'Dim myParameter As SqlParameter
        'Dim conn As New SqlConnection(ConnectionString)
        'Dim cmd As New SqlCommand()

        'Try
        '    cmd.Connection = conn
        '    cmd.CommandText = "sp_getMaxUserIdNo"
        '    cmd.CommandType = CommandType.StoredProcedure

        '    conn.Open()
        '    cmd.ExecuteNonQuery()

        '    Dim adapter As New SqlDataAdapter(cmd)

        '    adapter.Fill(ds)

        'Catch err As DataException
        '    Throw New ApplicationException("Error .." & err.Message)
        'Finally
        '    conn.Close()
        '    'cmd.Dispose()
        '    conn = Nothing
        '    cmd = Nothing
        '    ds = Nothing
        'End Try

        ''    Return ds

        Dim Query As String = "select max(User_NO) from master_users"
        Dim conn As New SqlConnection(ConnectionString)
        Dim Reader As SqlDataReader
        Dim new_user_id_no As Long

        Try
            Dim cmd As New SqlCommand(Query, conn)
            conn.Open()
            Reader = cmd.ExecuteReader

            While Reader.Read()
                new_user_id_no = Reader(0) '("onlineStatus")
            End While
            new_user_id_no = new_user_id_no + 1
            cmd = Nothing
        Catch err As Exception
            Throw New ApplicationException("Error in connecting to DB " & err.Message)
        Finally
            conn.Close()
            Reader.Close()
            Reader = Nothing
            conn = Nothing
            Query = ""
        End Try

        Return new_user_id_no

    End Function

    Public Overloads Function getCusPayNo(ByVal invoiceNum As Integer) As Integer

        Dim CusPayNo As Integer
        Dim DT As New DataTable()
        Dim conn As New SqlConnection(ConnectionString)
        Dim Query As String = "select CusPayNo from Admin_PaymentMaster where InvoiceNo=@invno"
        Try
            Dim cmd As New SqlCommand(Query, conn)
            cmd.Parameters.Add("invno", SqlDbType.Int).Value = invoiceNum

            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)

            cmd = Nothing

            CusPayNo = DT.Rows(0).Item(0)
        Catch
            CusPayNo = 0
        Finally

        End Try

        Return CusPayNo
    End Function

    Public Function isUserNameExist(ByVal UserName As String) As Boolean
        ''/*Note*/
        '' This Function is for getting the result from SPROC for CHECKING if the 
        ''  Users exist or not.
        isUserNameExist = False

        'Dim DS As New DataSet()
        'Dim myParameter As SqlParameter
        'Dim conn As New SqlConnection(ConnectionString)
        'Dim cmd As New SqlCommand()
        Dim TotalResult As Int16
        Dim temp As String

        'Try
        'cmd.Connection = conn
        'cmd.CommandText = "sp_isUserNameExist"
        'cmd.CommandType = CommandType.StoredProcedure
        'cmd.Parameters.Add(New SqlParameter("@USERNAME", SqlDbType.VarChar)).Value = UserName

        ''cmd.Parameters.Add(New SqlParameter("@TotalRecords", SqlDbType.Int)).Direction = ParameterDirection.Output

        'conn.Open()
        'cmd.ExecuteNonQuery()

        'Dim adapter As New SqlDataAdapter(cmd)


        Dim Query As String = "select User_Name from master_users where  USER_NAME ='" & UserName & "'  "
        Dim DS As DataSet = FetchDataSet(Query, "master_users")

        'Return DS



        'adapter.Fill(DS)
        'its giving worng result even if the record is not present in DB its giving 1
        'TotalResult = Convert.ToInt16(DS.Tables.Item("user_name"))   '.Count
        'TotalResult = Convert.ToInt16(.Tables.Item("user_name"))




        'temp = ds.Tables.   ''DS!User_Name



        'conn.Close()



        'Catch err As DataException
        '    Throw New ApplicationException("Error in connecting to DB  " & Err.Message)
        '    Finally
        '       conn.Close()
        '       'conn.Dispose()
        '       'cmd.Dispose()
        '      End Try


        isUserNameExist = True
        Return isUserNameExist

    End Function

    Public Function isWordLawDictionaryExist(ByVal Word As String) As Boolean
        isWordLawDictionaryExist = False

        Dim Result As Byte


        Dim Query As String = "select count(*) from Reference_Dictionary where  Word ='" & Word & "'  "
        Dim dt As DataTable = FetchDataSet(Query)
        Result = Val(dt.Rows(0).Item(0))
        If Result = 0 Then
            ' this means that word doesn't exist

            isWordLawDictionaryExist = False

        Else
            isWordLawDictionaryExist = True
        End If

        Return isWordLawDictionaryExist
    End Function

    Public Function ExecuteMyQuery(ByVal Query As String) As DataTable
        Dim DT As New DataTable
        Dim conn As New SqlConnection(ConnectionString)
        Dim MSG As String

        Try

            Dim cmd As New SqlCommand(Query, conn)
            Dim adapter As New SqlDataAdapter(cmd)

            cmd.CommandTimeout = 5000
            adapter.Fill(DT)
        Catch err As Exception
            'Throw New ApplicationException("Error in connecting to DB  " & err.Message)
            MSG = err.Message
        Finally
            conn.Close()
        End Try
        conn = Nothing
        Return DT
    End Function

    Public Function countConfirmedUsers() As DataTable
        ''/*Note*/
        '' This Function is for getting the result from SPROC for counting the Confirmed
        ''  Users for displaying on the index pages of site like home and user management

        Dim DT As DataTable
        Dim Query As String
        Try
            Query = "select count(user_name) from master_users where Status = 'Confirm'"
            DT = FetchDataSet(Query)

        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally
            Query = ""

        End Try

        Return DT
    End Function

    Public Function countPaymentPendingUsers() As DataTable
        ''/*Note*/
        '' This Function is for getting the result from SPROC for counting the Confirmed
        ''  Users for displaying on the index pages of site like home and user management

        Dim DT As DataTable
        Dim Query As String
        Try
            Query = "select  count(user_name) from master_users where Status = 'Payment Pending'"
            DT = FetchDataSet(Query)

        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally
            Query = ""

        End Try

        Return DT


    End Function

    Public Function countSuspendedUsers() As DataTable
        ''/*Note*/
        '' This Function is for getting the result from SPROC for counting the Confirmed
        ''  Users for displaying on the index pages of site like home and user management

        Dim DT As DataTable
        Dim Query As String
        Try
            Query = "select  count(user_name) from master_users where Status = 'Suspend'"
            DT = FetchDataSet(Query)

        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally
            Query = ""

        End Try

        Return DT

    End Function

    Public Function countTerminatedUsers() As DataTable
        ''/*Note*/
        '' This Function is for getting the result from SPROC for counting the Confirmed
        ''  Users for displaying on the index pages of site like home and user management

        Dim DT As DataTable
        Dim Query As String
        Try
            Query = "select  count(user_name) from master_users where Status = 'Terminated'"
            DT = FetchDataSet(Query)

        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally
            Query = ""

        End Try

        Return DT
    End Function

    Public Function countFreeUsers() As DataTable
        ''/*Note*/
        '' This Function is for getting the result from SPROC for counting the Confirmed
        ''  Users for displaying on the index pages of site like home and user management

        Dim DT As DataTable
        Dim Query As String
        Try
            Query = "select  count(user_name) from master_users where Access_Type = 'Free'"
            DT = FetchDataSet(Query)

        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally
            Query = ""

        End Try

        Return DT

    End Function

    Public Function countOnlineUsers() As DataTable
        ''/*Note*/
        '' This Function is for getting the result from SPROC for counting the Confirmed
        ''  Users for displaying on the index pages of site like home and user management

        Dim DT As New DataTable()
        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand()
        Try

            cmd.Connection = conn
            cmd.CommandText = "sp_CountOnlineUsers"
            cmd.CommandType = CommandType.StoredProcedure
            conn.Open()
            cmd.ExecuteNonQuery()
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)


        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally
            conn.Close()
            cmd.Dispose()
            conn.Dispose()

        End Try

        Return DT

    End Function

    Public Function countTotalUsers() As DataTable
        ''/*Note*/
        '' This Function is for getting the result from SPROC for counting the Confirmed
        ''  Users for displaying on the index pages of site like home and user management

        Dim DT As New DataTable()
        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand()
        Try

            cmd.Connection = conn
            'cmd.CommandText = "sp_CountTotalUsers"
            cmd.CommandText = "sp_getTotalUsers"
            cmd.CommandType = CommandType.StoredProcedure
            conn.Open()
            cmd.ExecuteNonQuery()
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)


        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally
            conn.Close()
            cmd.Dispose()
            conn.Dispose()

        End Try

        Return DT

    End Function

    Public Function countCasesFiles() As DataTable
        ''/*Note*/
        '' This Function is for getting the result from SPROC for counting the Confirmed
        ''  Users for displaying on the index pages of site like home and user management

        Dim DT As New DataTable()
        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand()
        Try

            cmd.Connection = conn
            cmd.CommandText = "sp_CountCasesFiles"
            cmd.CommandType = CommandType.StoredProcedure
            conn.Open()
            cmd.ExecuteNonQuery()
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)


        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally
            conn.Close()
            cmd.Dispose()
            conn.Dispose()

        End Try

        Return DT

    End Function

    Public Function countLegislationFiles() As DataTable
        ''/*Note*/
        '' This Function is for getting the result from SPROC for counting the Confirmed
        ''  Users for displaying on the index pages of site like home and user management

        Dim DT As New DataTable()
        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand()
        Try

            cmd.Connection = conn
            cmd.CommandText = "sp_CountLegislationFiles"
            cmd.CommandType = CommandType.StoredProcedure
            conn.Open()
            cmd.ExecuteNonQuery()
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)


        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally
            conn.Close()
            cmd.Dispose()
            conn.Dispose()

        End Try

        Return DT

    End Function


    Public Function countArticleFiles() As DataTable
        ''/*Note*/
        '' This Function is for getting the result from SPROC for counting the Confirmed
        ''  Users for displaying on the index pages of site like home and user management

        Dim DT As New DataTable()
        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand()
        Try

            cmd.Connection = conn
            cmd.CommandText = "sp_CountArticleFiles"
            cmd.CommandType = CommandType.StoredProcedure
            conn.Open()
            cmd.ExecuteNonQuery()
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)


        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally
            conn.Close()
            cmd.Dispose()
            conn.Dispose()

        End Try

        Return DT

    End Function

    Public Function countLegalForms() As DataTable
        ''/*Note*/
        '' This Function is for getting the result from SPROC for counting the Confirmed
        ''  Users for displaying on the index pages of site like home and user management

        Dim DT As New DataTable()
        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand()
        Try

            cmd.Connection = conn
            cmd.CommandText = "sp_CountLegalForms"
            cmd.CommandType = CommandType.StoredProcedure
            conn.Open()
            cmd.ExecuteNonQuery()
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)


        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally
            conn.Close()
            cmd.Dispose()
            conn.Dispose()

        End Try

        Return DT

    End Function

    Public Function countPracticeNotes() As DataTable
        ''/*Note*/
        '' This Function is for getting the result from SPROC for counting the Confirmed
        ''  Users for displaying on the index pages of site like home and user management

        Dim DT As New DataTable()
        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand()
        Try

            cmd.Connection = conn
            cmd.CommandText = "sp_CountPracticeNotes"
            cmd.CommandType = CommandType.StoredProcedure
            conn.Open()
            cmd.ExecuteNonQuery()
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)


        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally
            conn.Close()
            cmd.Dispose()
            conn.Dispose()

        End Try

        Return DT

    End Function

    Public Function countPrecedentFiles() As DataTable
        ''/*Note*/
        '' This Function is for getting the result from SPROC for counting the Confirmed
        ''  Users for displaying on the index pages of site like home and user management

        Dim DT As New DataTable()
        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand()
        Try

            cmd.Connection = conn
            cmd.CommandText = "sp_CountPrecedentFiles"
            cmd.CommandType = CommandType.StoredProcedure
            conn.Open()
            cmd.ExecuteNonQuery()
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)


        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally
            conn.Close()
            cmd.Dispose()
            conn.Dispose()

        End Try

        Return DT

    End Function




    Public Function loadCountries() As DataSet
        Dim DS As New DataSet()
        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand()
        Try

            cmd.Connection = conn
            cmd.CommandText = "sp_getCountries"
            cmd.CommandType = CommandType.StoredProcedure
            conn.Open()
            cmd.ExecuteNonQuery()
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DS)


        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally
            conn.Close()
            cmd.Dispose()
            conn.Dispose()

        End Try

        Return DS

    End Function


    Public Function chkUserNameExists(ByVal UserName As String) As Boolean
        chkUserNameExists = False

        'Dim ds As New DataSet()
        Dim recCount As String
        Dim myParameter As SqlParameter
        Dim invoice_date As DateTime
        UserName = "'" & UserName & "'"


        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand()
        Try

            cmd.Connection = conn
            cmd.CommandText = "sp_chkusernameexists"
            cmd.CommandType = CommandType.StoredProcedure
            myParameter = cmd.CreateParameter()
            myParameter.ParameterName = "@UserName"
            myParameter.Direction = ParameterDirection.Input
            myParameter.SqlDbType = SqlDbType.VarChar

            myParameter.Value = UserName
            cmd.Parameters.Add(myParameter)


            conn.Open()

            recCount = cmd.ExecuteNonQuery().ToString() '.ExecuteReader() 
            If Val(recCount) >= 1 Then
                chkUserNameExists = True
            Else
                chkUserNameExists = False

            End If

            'Dim adapter As New SqlDataAdapter(cmd)
            'adapter.Fill(ds)

            conn.Close()

        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally
            cmd.Dispose()
            conn.Dispose()

        End Try

        Return chkUserNameExists

    End Function


    Public Overloads Function getUserDetails() As DataTable
        Dim DT As New DataTable()
        Dim Query As String = "select First_Name,Firm_Name,User_Name,Registration_Date,Acct_Expiry, site_name from master_users where Access_Type<>'Free' "
        'Dim DS As DataSet = FetchDataSet(Query, "master_users")
        Query = ""
        Return DT
    End Function

    'Public Overloads Function getUserDetails(ByVal UserName As String, ByVal AcctType As String) As DataTable
    Public Overloads Function getUserDetails(ByVal UserName As String, ByVal AcctType As String) As SqlDataReader
        '/**
        ' This function is for getting user details from table master_users, this can be use for getting info for
        'any type user
        '*/
        Dim conn As New SqlConnection(ConnectionString)
        Dim DT As New DataTable()
        Dim Query As String = "select First_Name,Last_Name,Firm_Name,User_Name,Registration_Date,Acct_Expiry,Address_1,Address_2,city,state,postal_code,Country,Phone_number,Fax_number,Email_ID, site_name from master_users where Access_Type= '" & AcctType & "' and User_Name= '" & UserName & "'  "
        Dim cmd As New SqlCommand(Query, conn)
        'Dim DS As DataSet = FetchDataSet(Query, "master_users")
        conn.Open()
        Dim myReader As SqlDataReader
        myReader = cmd.ExecuteReader
        myReader.Read()
        'DT = Me.FetchDataSet(Query)
        'Query = ""
        'Return DT
        Return myReader
    End Function

    Public Function getSingleUserBasicDetails(ByVal UserIdNo As Long) As DataTable



        'Dim Query As String = "select First_Name, Last_Name, Firm_Name, User_Name, Registration_Date, AllotedSize, Address_1, Address_2, city, state, postal_code, Country, Phone_number, Fax_number, Email_ID, Site_Name from master_users where Access_Type= 'Paid Single' and User_id_no= " & UserIdNo & "  "
        Dim Query As String = "select First_Name, Last_Name, Firm_Name, User_Name, Registration_Date, AllotedSize, Address_1, Address_2, city, state, postal_code, Country, Phone_number, Fax_number, Email_ID, Site_Name, Group_Name from master_users where user_id_no= " & UserIdNo & "  "

        Dim DT As DataTable = FetchDataSet(Query)
        Return DT

    End Function



    Public Function getFreeUserBasicDetails(ByVal UserIdNo As Long) As DataTable


        'Dim Query As String = "select First_Name, Last_Name, Firm_Name, User_Name, Registration_Date, AllotedSize, Address_1, Address_2, city, state, postal_code, Country, Phone_number, Fax_number, Email_ID, Site_Name from master_users where Access_Type= 'Paid Single' and User_id_no= " & UserIdNo & "  "
        Dim Query As String = "select First_Name, Last_Name, Firm_Name, User_Name, Registration_Date, AllotedSize, Address_1, Address_2, city, state, postal_code, Country, Phone_number, Fax_number, Email_ID, Site_Name from master_users where Access_Type= 'Free' and User_id_no= " & UserIdNo & "  "

        Dim DT As DataTable = FetchDataSet(Query)
        Return DT

    End Function

    Public Function getGroupUserBasicDetails(ByVal UserIdNo As Long) As DataTable

        Dim conn As New SqlConnection(ConnectionString)
        Dim Query As String = "select First_Name,Last_Name,Firm_Name,User_Name,Registration_Date, AllotedSize, Address_1,Address_2,city,state,postal_code,Country,Phone_number,Fax_number,Email_ID, Site_Name, group_name from master_users where Access_Type= 'Paid Group' and User_id_no= " & UserIdNo & "  "

        Dim DT As DataTable = FetchDataSet(Query)


        Return DT

    End Function

    Public Function getUserBasicDetails(ByVal UserIdNo As Long) As DataTable

        Dim conn As New SqlConnection(ConnectionString)
        Dim Query As String = "select First_Name,Last_Name,Firm_Name,User_Name,Registration_Date, AllotedSize, Address_1,Address_2,city,state,postal_code,Country,Phone_number,Fax_number,Email_ID, Site_Name, group_name , Access_Type from master_users where User_NO= " & UserIdNo & "  "

        Dim DT As DataTable = FetchDataSet(Query)
        Return DT

    End Function

    Public Function getFeedbackDetail(ByVal FeedbackIdNo As Long) As DataTable

        Dim conn As New SqlConnection(ConnectionString)
        Dim Query As String = "select site_name, name,email,phone,fax,address , feedback ,feedbackdate from feedback1 where id= " & FeedbackIdNo

        Dim DT As DataTable = FetchDataSet(Query)
        Return DT

    End Function

    Public Overloads Function getGroupUserAdvanceDetails(ByVal UserIdNo As Long) As DataTable

        'Dim Query As String = "select Confirmation_Date, Account_Expiry, Mode_Of_Payment,Card_Type,Name_On_Card, Credit_Card_No, CC_Expiry_Date, Credit_Bank_Name, Cheque_Number, Cheque_Bank_Name,Cheque_Holder_Name, Cheque_Date, Total_Ammount,Ammount_Paid, Comments  from Admin_Master where Account_Type='Paid Group' and User_id_no=" & UserIdNo & " "
        Dim Query As String = "select Confirmation_Date, Account_Expiry, Payment_Mode,Card_Type,Name_On_Card, Credit_Card_No, CC_Expiry_Date, Credit_Bank_Name, Cheque_Number, Cheque_Bank_Name,Cheque_Holder_Name, Cheque_Date, Total_Ammount,Ammount_Paid, Comments  from Admin_Master where Account_Type='Paid Group' and User_id_no=" & UserIdNo & " "
        Dim DT As DataTable = FetchDataSet(Query)
        Return DT
    End Function

    Public Overloads Function getUserAdvanceDetails(ByVal UserIdNo As Long) As DataTable

        Dim Query As String = "select Confirmation_Date, Account_Expiry, Mode_Of_Payment,Card_Type,Name_On_Card, Credit_Card_No, CC_Expiry_Date, Credit_Bank_Name, Cheque_Number, Cheque_Bank_Name,Cheque_Holder_Name, Cheque_Date, Total_Ammount,Ammount_Paid, Comments  from Admin_Master where  User_id_no=" & UserIdNo & " "
        Dim DT As DataTable = FetchDataSet(Query)
        Return DT
    End Function

    Public Overloads Function getUserAdvanceDetails(ByVal UserIdNo As Long, ByVal InvoiceNo As Long) As DataTable

        Dim Query As String = "select tbl1.Confirmation_Date, tbl1.Account_Expiry, tbl1.Mode_Of_Payment, tbl1.Card_Type, tbl1.Name_On_Card, tbl1.Credit_Card_No, tbl1.CC_Expiry_Date, tbl1.Credit_Bank_Name, tbl1.Cheque_Number, tbl1.Cheque_Bank_Name, tbl1.Cheque_Holder_Name, tbl1.Cheque_Date, tbl1.Total_Ammount, tbl1.Ammount_Paid, tbl1.Comments, tbl1.Payment_mode  from Admin_Master as tbl1 ,invoicemembers as tbl2  where  (tbl1.User_id_no = tbl2.User_id_no) and tbl1.User_id_no=" & UserIdNo & " and tbl2.invoice_No=" & InvoiceNo
        Dim DT As DataTable = FetchDataSet(Query)
        Return DT
    End Function

    Public Overloads Function getSingleUserAdvanceDetails(ByVal UserIdNo As Long) As DataTable
        'Description: This is for getting single and corporate user details

        Dim Query As String = "select Confirmation_Date, Account_Expiry, Payment_Mode,Card_Type,Name_On_Card, Credit_Card_No, CC_Expiry_Date, Credit_Bank_Name, Cheque_Number, Cheque_Bank_Name,Cheque_Holder_Name, Cheque_Date, Total_Ammount,Ammount_Paid, Comments ,Account_Type , RecNo from Admin_Master where (Account_Type='Paid Single' or  Account_Type='Corporate') and User_id_no=" & UserIdNo & " "
        Dim DT As DataTable = FetchDataSet(Query)
        Return DT
    End Function

    Public Overloads Function getGroupUserAdvanceDetails1(ByVal UserIdNo As Long) As DataTable
        'Description: This is for getting group user details

        Dim Query As String = "select Confirmation_Date, Account_Expiry, Payment_Mode,Card_Type,Name_On_Card, Credit_Card_No, CC_Expiry_Date, Credit_Bank_Name, Cheque_Number, Cheque_Bank_Name,Cheque_Holder_Name, Cheque_Date, Total_Ammount,Ammount_Paid, Comments ,Account_Type , RecNo from Admin_Master where (Account_Type='GROUP') and User_id_no=" & UserIdNo & " "
        Dim DT As DataTable = FetchDataSet(Query)
        Return DT
    End Function

    Public Function getFreeUserAdvanceDetails(ByVal UserIdNo As Long) As DataTable
        'Description: This is for getting free user details

        'Dim Query As String = "select Confirmation_Date, Account_Expiry, Mode_Of_Payment,Card_Type,Name_On_Card, Credit_Card_No, CC_Expiry_Date, Credit_Bank_Name, Cheque_Number, Cheque_Bank_Name,Cheque_Holder_Name, Cheque_Date, Total_Ammount,Ammount_Paid, Comments ,Account_Type from Admin_Master where (Account_Type='Free' ) and User_id_no=" & UserIdNo & " "
        Dim Query As String = "select Confirmation_Date, Account_Expiry, Comments , Account_Type ,RecNo from Admin_Master where (Account_Type='Free' ) and User_id_no=" & UserIdNo & " "
        Dim DT As DataTable = FetchDataSet(Query)
        Return DT
    End Function

    Public Overloads Function getSingleUserAdvanceDetails(ByVal UserIdNo As Long, ByVal CurDate As Date) As DataTable
        'Description: this is for getting single and corporate user details
        Dim Query As String = "select Confirmation_Date, Account_Expiry, Mode_Of_Payment,Card_Type,Name_On_Card, Credit_Card_No, CC_Expiry_Date, Credit_Bank_Name, Cheque_Number, Cheque_Bank_Name,Cheque_Holder_Name, Cheque_Date, Total_Ammount,Ammount_Paid, Comments  from Admin_Master where (Account_Type='Paid Single' or  Account_Type='Corporate')  and User_id_no=" & UserIdNo & " and confirmation_date='" & CurDate & "' "
        Dim DT As DataTable = FetchDataSet(Query)
        Return DT
    End Function

    Public Sub updateOnlineUserStatus(ByVal USERNAME As String, ByVal STATUS As String)

        Dim ds As New DataSet
        Dim myParameter As SqlParameter
        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand

        Try
            cmd.Connection = conn
            cmd.CommandText = "sp_OnlineStatus"
            cmd.CommandType = CommandType.StoredProcedure

            cmd.Parameters.Add(New SqlParameter("@USERNAME", SqlDbType.VarChar)).Value = USERNAME
            cmd.Parameters.Add(New SqlParameter("@STATUS", SqlDbType.VarChar)).Value = STATUS


            conn.Open()
            cmd.ExecuteNonQuery()

            Dim adapter As New SqlDataAdapter(cmd)

            adapter.Fill(ds)

        Catch err As DataException
            Throw New ApplicationException("Error .." & err.Message)
        Finally
            conn.Close()
            'cmd.Dispose()
            conn = Nothing
            cmd = Nothing
            ds = Nothing
        End Try

        '    Return ds
    End Sub

    Public Function CustomerExists() As Boolean
        Dim Query As String = "select CustomerID from Customer"

        Dim conn As New SqlConnection(ConnectionString)
        Dim Reader As SqlDataReader
        Dim Result As String = ""
        Dim Pwd As String
        Dim Found As Boolean
        Found = False
        Try
            Dim cmd As New SqlCommand(Query, conn)
            conn.Open()
            Reader = cmd.ExecuteReader

            While Reader.Read()
                Result = Reader("CustomerID")

            End While


            If Result = "" Then
                Found = False
            End If
            If Result <> "" Then
                Found = True
            End If


        Catch err As Exception
            Throw New ApplicationException("Error in connecting to DB " & err.Message)
        Finally
            conn.Close()
            Reader.Close()
            Reader = Nothing
            conn = Nothing
            Result = ""
            Query = ""

        End Try

        Return Found
    End Function

    Public Function CustomerExists(ByVal CustomerID As String) As Boolean
        Dim Query As String = "select CustomerName from Customer where CustomerID=@CustID "

        Dim conn As New SqlConnection(ConnectionString)
        Dim Reader As SqlDataReader
        Dim Result As String = ""
        Dim Pwd As String
        Dim Found As Boolean
        Found = False
        Try
            Dim cmd As New SqlCommand(Query, conn)
            cmd.Parameters.Add("CustID", SqlDbType.VarChar, 10).Value = CustomerID

            conn.Open()
            Reader = cmd.ExecuteReader

            While Reader.Read()
                Result = Reader("CustomerName")

            End While


            If Result = "" Then
                Found = False
            End If
            If Result <> "" Then
                Found = True
            End If


        Catch err As Exception
            Throw New ApplicationException("Error in connecting to DB " & err.Message)
        Finally
            conn.Close()
            Reader.Close()
            Reader = Nothing
            conn = Nothing
            Result = ""
            Query = ""

        End Try

        Return Found
    End Function

    Public Function EventExists(ByVal SpeakerID As Integer) As Boolean
        Dim Query As String = "select Event_ID from myseminars_EventSpeaker where SpeakerID=@SID"

        Dim conn As New SqlConnection(ConnectionString)
        Dim Reader As SqlDataReader
        Dim Result As String = ""
        Dim Pwd As String
        Dim Found As Boolean
        Found = False
        Try
            Dim cmd As New SqlCommand(Query, conn)
            cmd.Parameters.Add("SID", SqlDbType.Int).Value = SpeakerID
            conn.Open()
            Reader = cmd.ExecuteReader

            While Reader.Read()
                Result = Reader("Event_ID")

            End While


            If Result = "" Then
                Found = False
            End If
            If Result <> "" Then
                Found = True
            End If


        Catch err As Exception
            Throw New ApplicationException("Error in connecting to DB " & err.Message)
        Finally
            conn.Close()
            Reader.Close()
            Reader = Nothing
            conn = Nothing
            Result = ""
            Query = ""

        End Try

        Return Found
    End Function

    Public Function EventSpeakerExists(ByVal EventID As Integer, ByVal SpeakerID As Integer) As Boolean
        Dim Query As String = "select Event_ID from myseminars_EventSpeaker where Event_ID=@EventID and SpeakerID=@SID"

        Dim conn As New SqlConnection(ConnectionString)
        Dim Reader As SqlDataReader
        Dim Result As String = ""
        Dim Pwd As String
        Dim Found As Boolean
        Found = False
        Try
            Dim cmd As New SqlCommand(Query, conn)
            cmd.Parameters.Add("EventID", SqlDbType.Int).Value = EventID
            cmd.Parameters.Add("SID", SqlDbType.Int).Value = SpeakerID
            conn.Open()
            Reader = cmd.ExecuteReader

            While Reader.Read()
                Result = Reader("Event_ID")

            End While


            If Result = "" Then
                Found = False
            End If
            If Result <> "" Then
                Found = True
            End If


        Catch err As Exception
            Throw New ApplicationException("Error in connecting to DB " & err.Message)
        Finally
            conn.Close()
            Reader.Close()
            Reader = Nothing
            conn = Nothing
            Result = ""
            Query = ""

        End Try

        Return Found
    End Function

    Public Function EventParticipantExists(ByVal StaffID As Integer) As Boolean
        Dim Query As String = "select EventID from myseminars_PrintParticipant where StaffID=@SID"

        Dim conn As New SqlConnection(ConnectionString)
        Dim Reader As SqlDataReader
        Dim Result As String = ""
        Dim Pwd As String
        Dim Found As Boolean
        Found = False
        Try
            Dim cmd As New SqlCommand(Query, conn)
            cmd.Parameters.Add("SID", SqlDbType.Int).Value = StaffID
            conn.Open()
            Reader = cmd.ExecuteReader

            While Reader.Read()
                Result = Reader("EventID")

            End While


            If Result = "" Then
                Found = False
            End If
            If Result <> "" Then
                Found = True
            End If


        Catch err As Exception
            Throw New ApplicationException("Error in connecting to DB " & err.Message)
        Finally
            conn.Close()
            Reader.Close()
            Reader = Nothing
            conn = Nothing
            Result = ""
            Query = ""

        End Try

        Return Found
    End Function

    Public Function ParticipantExists(ByVal EventID As Integer, ByVal StaffID As Integer) As Boolean
        Dim Query As String = "select invoice_no from myseminars_PrintParticipant where EventID=@EventID and StaffID=@SID"

        Dim conn As New SqlConnection(ConnectionString)
        Dim Reader As SqlDataReader
        Dim Result As String = ""
        Dim Pwd As String
        Dim Found As Boolean
        Found = False
        Try
            Dim cmd As New SqlCommand(Query, conn)
            cmd.Parameters.Add("EventID", SqlDbType.Int).Value = EventID
            cmd.Parameters.Add("SID", SqlDbType.Int).Value = StaffID

            conn.Open()
            Reader = cmd.ExecuteReader

            While Reader.Read()
                Result = Reader("invoice_no")

            End While


            If Result = "" Then
                Found = False
            End If
            If Result <> "" Then
                Found = True
            End If


        Catch err As Exception
            Throw New ApplicationException("Error in connecting to DB " & err.Message)
        Finally
            conn.Close()
            Reader.Close()
            Reader = Nothing
            conn = Nothing
            Result = ""
            Query = ""

        End Try

        Return Found
    End Function

    Public Function check_Invoice_id(ByVal invoice_id As Integer) As Boolean
        Dim Query As String = "select Invoice_max_id from myseminars_PrintParticipant where Invoice_max_id=@Invoice_max_id"

        Dim conn As New SqlConnection(ConnectionString)
        Dim Reader As SqlDataReader
        Dim Result As String = ""
        Dim count As Integer = 0
        Dim Pwd As String
        Dim Found As Boolean
        Found = False
        Try
            Dim cmd As New SqlCommand(Query, conn)
            cmd.Parameters.Add("@Invoice_max_id", SqlDbType.Int).Value = invoice_id

            conn.Open()
            Reader = cmd.ExecuteReader

            While Reader.Read()
                Result = Reader("Invoice_max_id")

            End While


            If Result = "" Then
                Found = False
            End If
            If Result <> "" Then
                Found = True
            End If


        Catch err As Exception
            Throw New ApplicationException("Error in connecting to DB " & err.Message)
        Finally
            conn.Close()
            Reader.Close()
            Reader = Nothing
            conn = Nothing
            Result = ""
            Query = ""

        End Try

        Return Found
    End Function


    Public Function ProductExists(ByVal ProductGroupID As String) As Boolean
        Dim Query As String = "select ProductID from Admin_Product where ProductGroupID=@PID"

        Dim conn As New SqlConnection(ConnectionString)
        Dim Reader As SqlDataReader
        Dim Result As String = ""
        Dim Pwd As String
        Dim Found As Boolean
        Found = False
        Try
            Dim cmd As New SqlCommand(Query, conn)
            cmd.Parameters.Add("PID", SqlDbType.VarChar, 10).Value = ProductGroupID
            conn.Open()
            Reader = cmd.ExecuteReader

            While Reader.Read()
                Result = Reader("ProductID")

            End While


            If Result = "" Then
                Found = False
            End If
            If Result <> "" Then
                Found = True
            End If


        Catch err As Exception
            Throw New ApplicationException("Error in connecting to DB " & err.Message)
        Finally
            conn.Close()
            Reader.Close()
            Reader = Nothing
            conn = Nothing
            Result = ""
            Query = ""

        End Try

        Return Found
    End Function

    Public Overloads Function getCustomerID(ByVal UserIdNo As String) As String

        Dim CustomerID As String
        Dim DT As New DataTable()
        Dim conn As New SqlConnection(ConnectionString)
        Dim Query As String = "select c.CustomerID from Customer c inner join Account a on a.CustomerID = c.CustomerID  "
        Query &= "inner join Admin_Users nu on nu.AccountID = a.AccountID where nu.UserID =@uid"
        Try
            Dim cmd As New SqlCommand(Query, conn)
            cmd.Parameters.Add("uid", SqlDbType.VarChar, 10).Value = UserIdNo

            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)

            cmd = Nothing

            CustomerID = DT.Rows(0).Item(0)
        Catch
            CustomerID = ""
        Finally

        End Try

        Return CustomerID
    End Function
    Public Overloads Function getCustomerFilter(ByVal Username As String) As String

        Dim CustomerID As String
        Dim DT As New DataTable()
        Dim conn As New SqlConnection(ConnectionString)
        Dim Query As String = "Select CustomerID from Account INNER JOIN Admin_Users ON  Account.AccountID = Admin_Users.AccountID  "
        Query &= "where Admin_Users.UserName  = @UserName"
        Try
            Dim cmd As New SqlCommand(Query, conn)
            cmd.Parameters.Add("@UserName", SqlDbType.VarChar, 50).Value = Username

            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)

            cmd = Nothing

            CustomerID = DT.Rows(0).Item(0)
        Catch
            CustomerID = ""
        Finally

        End Try

        Return CustomerID
    End Function

    Public Overloads Function getDebtAmount(ByVal productGroupID As String) As Decimal

        Dim debts As Decimal
        Dim DT As New DataTable()
        Dim conn As New SqlConnection(ConnectionString)
        Dim Query As String = "select ISNULL(SUM(PM.Balance_Invoice),'0.00') As Debts from [elawdb].[dbo].Invoice I  "
        Query &= "INNER JOIN [elawdb].[dbo].Customer C ON c.CustomerID = i.CustomerID "
        Query &= "INNER JOIN [elawdb].[dbo].Admin_InvoiceProduct ip ON i.InvoiceNo = ip.InvoiceNo "
        Query &= "INNER JOIN [elawdb].[dbo].Admin_PaymentMaster PM ON i.InvoiceNo = PM.InvoiceNo "
        Query &= "INNER JOIN [elawdb].[dbo].Admin_Payment p ON p.CusPayNo = PM.CusPayNo "
        Query &= "INNER JOIN [elawdb].[dbo].Admin_Product pr ON pr.ProductID = ip.ProductNo "
        Query &= "where pr.ProductGroupID =@pgi"
        Try
            Dim cmd As New SqlCommand(Query, conn)
            cmd.Parameters.Add("pgi", SqlDbType.VarChar, 10).Value = productGroupID

            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)

            cmd = Nothing

            debts = DT.Rows(0).Item(0)
        Catch
            debts = 0.0
        Finally

        End Try

        Return debts
    End Function

    Public Function GetUserType(ByVal UserID As String) As String
        Dim Query As String = "select UserType from Admin_Users where UserID =@UserID "

        Dim conn As New SqlConnection(ConnectionString)
        Dim Reader As SqlDataReader
        Dim UserType As String = ""
        Try
            Dim cmd As New SqlCommand(Query, conn)
            cmd.Parameters.Add("UserID", SqlDbType.VarChar, 10).Value = UserID
            conn.Open()
            Reader = cmd.ExecuteReader

            While Reader.Read()
                UserType = Reader("UserType")
            End While





        Catch err As Exception
            Throw New ApplicationException("Error in connecting to DB " & err.Message)
        Finally
            conn.Close()
            Reader.Close()
            Reader = Nothing
            conn = Nothing
            Query = ""

        End Try

        Return UserType
    End Function

    Public Function GetCPID(ByVal CustomerID As String) As String
        Dim Query As String = "select CPID from admin_ContactPerson where CustomerID=@CustID "

        Dim conn As New SqlConnection(ConnectionString)
        Dim Reader As SqlDataReader
        Dim CPID As String = ""
        Try
            Dim cmd As New SqlCommand(Query, conn)
            cmd.Parameters.Add("CustID", SqlDbType.VarChar, 10).Value = CustomerID
            conn.Open()
            Reader = cmd.ExecuteReader

            While Reader.Read()
                CPID = Reader("CPID")
            End While





        Catch err As Exception
            Throw New ApplicationException("Error in connecting to DB " & err.Message)
        Finally
            conn.Close()
            Reader.Close()
            Reader = Nothing
            conn = Nothing
            Query = ""

        End Try

        Return CPID
    End Function

    Public Function GetGroupID(ByVal UserID As String) As String
        Dim Query As String = "select GroupID from Admin_Users where UserID=@UserID "

        Dim conn As New SqlConnection(ConnectionString)
        Dim Reader As SqlDataReader
        Dim GroupID As String = ""
        Try
            Dim cmd As New SqlCommand(Query, conn)
            cmd.Parameters.Add("UserID", SqlDbType.VarChar, 10).Value = UserID
            conn.Open()
            Reader = cmd.ExecuteReader

            While Reader.Read()
                GroupID = Reader("GroupID")
            End While

        Catch err As Exception
            Throw New ApplicationException("Error in connecting to DB " & err.Message)
        Finally
            conn.Close()
            Reader.Close()
            Reader = Nothing
            conn = Nothing
            Query = ""

        End Try

        Return GroupID
    End Function


    Public Overloads Function getGroupIDByCustomerName(ByVal customerName As String) As String

        Dim groupID As String
        Dim DT As New DataTable()
        Dim conn As New SqlConnection(ConnectionString)
        Dim Query As String = "select nu.GroupID from Account a inner join Customer c on c.CustomerID = a.CustomerID inner join Admin_Users nu on nu.AccountID=a.AccountID where c.CustomerName=@CName"
        Try
            Dim cmd As New SqlCommand(Query, conn)
            cmd.Parameters.Add("CName", SqlDbType.VarChar, 35).Value = customerName

            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)

            cmd = Nothing

            groupID = DT.Rows(0).Item(0)
        Catch
            groupID = ""
        Finally

        End Try

        Return groupID
    End Function

    Public Function GetProductPrice(ByVal ProductID As String) As Decimal
        Dim Query As String = "select UnitPrice from Admin_Product where PName=@ProdID "

        Dim conn As New SqlConnection(ConnectionString)
        Dim Reader As SqlDataReader
        Dim Price As Decimal = 0.0
        Try
            Dim cmd As New SqlCommand(Query, conn)
            cmd.Parameters.Add("ProdID", SqlDbType.VarChar, 100).Value = ProductID
            conn.Open()
            Reader = cmd.ExecuteReader

            While Reader.Read()
                Price = Convert.ToDecimal(Reader("UnitPrice"))
            End While





        Catch err As Exception
            Throw New ApplicationException("Error in connecting to DB " & err.Message)
        Finally
            conn.Close()
            Reader.Close()
            Reader = Nothing
            conn = Nothing
            Query = ""

        End Try

        Return Price
    End Function

    Public Function GetProductID(ByVal ProductName As String) As String
        Dim Query As String = "select ProductID from Admin_Product where PName=@PName "

        Dim conn As New SqlConnection(ConnectionString)
        Dim Reader As SqlDataReader
        Dim ID As String = ""
        Try
            Dim cmd As New SqlCommand(Query, conn)
            cmd.Parameters.Add("PName", SqlDbType.VarChar, 100).Value = ProductName
            conn.Open()
            Reader = cmd.ExecuteReader

            While Reader.Read()
                ID = Reader("ProductID")
            End While





        Catch err As Exception
            Throw New ApplicationException("Error in connecting to DB " & err.Message)
        Finally
            conn.Close()
            Reader.Close()
            Reader = Nothing
            conn = Nothing
            Query = ""

        End Try

        Return ID
    End Function

    Public Function ReceiptNoExists(ByVal ReceiptNo As String) As Boolean
        Dim Query As String = "select ReceiptNo from Admin_Payment where ReceiptNo=@ReceiptNum "

        Dim conn As New SqlConnection(ConnectionString)
        Dim Reader As SqlDataReader
        Dim Result As String = ""
        Dim Pwd As String
        Dim Found As Boolean
        Found = False
        Try
            Dim cmd As New SqlCommand(Query, conn)
            cmd.Parameters.Add("ReceiptNum", SqlDbType.VarChar, 10).Value = ReceiptNo

            conn.Open()
            Reader = cmd.ExecuteReader

            While Reader.Read()
                Result = Reader("ReceiptNo")

            End While


            If Result = "" Then
                Found = False
            End If
            If Result <> "" Then
                Found = True
            End If


        Catch err As Exception
            Throw New ApplicationException("Error in connecting to DB " & err.Message)
        Finally
            conn.Close()
            Reader.Close()
            Reader = Nothing
            conn = Nothing
            Result = ""
            Query = ""

        End Try

        Return Found
    End Function

    Public Function CusPayNoExists(ByVal CusPayNo As String) As Boolean
        Dim Query As String = "select CusPayNo from Admin_PaymentMaster where CusPayNo=@CPN "

        Dim conn As New SqlConnection(ConnectionString)
        Dim Reader As SqlDataReader
        Dim Result As String = ""
        Dim Pwd As String
        Dim Found As Boolean
        Found = False
        Try
            Dim cmd As New SqlCommand(Query, conn)
            cmd.Parameters.Add("CPN", SqlDbType.VarChar, 10).Value = CuspayNo

            conn.Open()
            Reader = cmd.ExecuteReader

            While Reader.Read()
                Result = Reader("CusPayNo")

            End While


            If Result = "" Then
                Found = False
            End If
            If Result <> "" Then
                Found = True
            End If


        Catch err As Exception
            Throw New ApplicationException("Error in connecting to DB " & err.Message)
        Finally
            conn.Close()
            Reader.Close()
            Reader = Nothing
            conn = Nothing
            Result = ""
            Query = ""

        End Try

        Return Found
    End Function

    Public Function getLoginAuthenticated(ByVal Username As String, ByVal Password As String) As Boolean

        '       Dim Query As String = "select admin_name, admin_password from admin where admin_name ='" & Username & "' and admin_password ='" & Password & "' "
        Dim Query As String = "select UserName,type from WebAdmin where UserName =@UserName and Password =@Password "

        Dim conn As New SqlConnection(ConnectionString)
        Dim Reader As SqlDataReader
        Dim Result As String
        Dim Pwd As String
        Dim Found As Boolean
        Found = False
        Try
            Dim cmd As New SqlCommand(Query, conn)
            cmd.Parameters.Add("UserName", SqlDbType.VarChar, 15).Value = Username
            cmd.Parameters.Add("Password", SqlDbType.VarChar, 18).Value = Password
            conn.Open()
            Reader = cmd.ExecuteReader

            While Reader.Read()
                Result = Reader("UserName")
                HttpContext.Current.Session("UserType") = Reader("type")
                '                Pwd = Reader("admin_password")
            End While


            If Result = "" Then
                Found = False
            End If
            If Result <> "" Then
                Found = True
            End If

            'If StrComp(Password, Pwd, CompareMethod.Binary) = 0 Then
            '    Found = True
            'Else
            '    Found = False
            'End If

        Catch err As Exception
            Throw New ApplicationException("Error in connecting to DB " & err.Message)
        Finally
            conn.Close()
            Reader.Close()
            Reader = Nothing
            conn = Nothing
            Result = ""
            Query = ""

        End Try

        Return Found
    End Function

    Public Function checkCustomerProduct(ByVal CPID As String, ByVal ProductID As Integer) As Boolean


        Dim Query As String = "select * from admin_CustomerCP_Product where ProductID=@ProductID and CPID=@cpid "

        Dim conn As New SqlConnection(ConnectionString)
        Dim Reader As SqlDataReader
        Dim Result As String
        Dim Pwd As String
        Dim Found As Boolean
        Found = False
        Try
            Dim cmd As New SqlCommand(Query, conn)
            cmd.Parameters.Add("ProductID", SqlDbType.Int).Value = ProductID
            cmd.Parameters.Add("cpid", SqlDbType.VarChar, 10).Value = CPID
            conn.Open()
            Reader = cmd.ExecuteReader

            While Reader.Read()
                Result = Reader("CustomerID")

            End While


            If Result = "" Then
                Found = False
            End If
            If Result <> "" Then
                Found = True
            End If


        Catch err As Exception
            Throw New ApplicationException("Error in connecting to DB " & err.Message)
        Finally
            conn.Close()
            Reader.Close()
            Reader = Nothing
            conn = Nothing
            Result = ""
            Query = ""

        End Try

        Return Found
    End Function

    Public Function getUserLoginVerification(ByVal Username As String, ByVal Password As String) As Boolean

        Dim Query As String = "select UserName from Admin_Users where UserName =@UserName and Password =@Password "

        Dim conn As New SqlConnection(ConnectionString)
        Dim Reader As SqlDataReader
        Dim Result As String
        Dim Pwd As String
        Dim Found As Boolean
        Found = False
        Try
            Dim cmd As New SqlCommand(Query, conn)
            cmd.Parameters.Add("UserName", SqlDbType.VarChar, 20).Value = Username
            cmd.Parameters.Add("Password", SqlDbType.VarChar, 15).Value = Password
            conn.Open()
            Reader = cmd.ExecuteReader

            While Reader.Read()
                Result = Reader("UserName")
                '                Pwd = Reader("admin_password")
            End While


            If Result = "" Then
                Found = False
            End If
            If Result <> "" Then
                Found = True
            End If

            'If StrComp(Password, Pwd, CompareMethod.Binary) = 0 Then
            '    Found = True
            'Else
            '    Found = False
            'End If

        Catch err As Exception
            Throw New ApplicationException("Error in connecting to DB " & err.Message)
        Finally
            conn.Close()
            Reader.Close()
            Reader = Nothing
            conn = Nothing
            Result = ""
            Query = ""

        End Try

        Return Found
    End Function

    Public Function validateID(ByVal CustomerID As String, ByVal parameterName As String, ByVal queryInput As String) As Boolean

        Dim Query As String = queryInput

        Dim conn As New SqlConnection(ConnectionString)
        Dim Reader As SqlDataReader
        Dim Result As String

        Dim Found As Boolean
        Found = False
        Try
            Dim cmd As New SqlCommand(Query, conn)
            cmd.Parameters.Add(parameterName, SqlDbType.VarChar, 100).Value = CustomerID

            conn.Open()
            Reader = cmd.ExecuteReader

            While Reader.Read()
                Result = Reader(parameterName)

            End While


            If Result = "" Then
                Found = False
            ElseIf Result <> "" Then
                Found = True
            End If


        Catch err As Exception
            Throw New ApplicationException("Error in connecting to DB " & err.Message)
        Finally
            conn.Close()
            Reader.Close()
            Reader = Nothing
            conn = Nothing
            Result = ""
            Query = ""

        End Try

        Return Found
    End Function

    Public Function CheckProduct(ByVal ProductID As Integer, ByVal parameterName As String, ByVal queryInput As String, ByVal fieldName As String) As Boolean

        Dim Query As String = queryInput

        Dim conn As New SqlConnection(ConnectionString)
        Dim Reader As SqlDataReader
        Dim Result As String

        Dim Found As Boolean
        Found = False
        Try
            Dim cmd As New SqlCommand(Query, conn)
            cmd.Parameters.Add(parameterName, SqlDbType.Int).Value = ProductID

            conn.Open()
            Reader = cmd.ExecuteReader

            While Reader.Read()
                Result = Reader(fieldName)
                '                
            End While


            If Result = "" Then
                Found = False
            ElseIf Result <> "" Then
                Found = True
            End If


        Catch err As Exception
            Throw New ApplicationException("Error in connecting to DB " & err.Message)
        Finally
            conn.Close()
            Reader.Close()
            Reader = Nothing
            conn = Nothing
            Result = ""
            Query = ""

        End Try

        Return Found
    End Function

    Public Function ValidUsers(ByVal UserName As String) As Boolean
        Dim isValidUser As Boolean = False

        If UserName = "sadmin" Or UserName = "Accounts" Or UserName = "master_users" Then
            isValidUser = True

        End If
        Return isValidUser
    End Function

    'Public Overloads Function getUsersInvoices(ByVal sortByChar As String, ByVal invoiceDate As String) As DataSet
    '    sortByChar = " Group_Name LIKE  '" & sortByChar & "%" & "' "

    '    Dim Query As String = "select Invoice_No,Group_Name,Invoice_Date,InvoiceAmount,InvoiceStatus,DepositDate from Invoice where " & sortByChar & "   "
    '    Dim DS As DataSet = FetchDataSet(Query, "Invoice")
    '    Return DS
    'End Function

    Public Overloads Function getCancelInvoices() As DataSet
        Dim Query As String = "select Invoice_No,Group_Name,Invoice_Date,InvoiceAmount,DepositDate from Invoice   InvoiceStatus='Invoice Cancelled' "
        Dim DS As DataSet = FetchDataSet(Query, "Invoice")
        Return DS
    End Function

    Public Overloads Function getCancelInvoices(ByVal sortByChar As String) As DataSet
        sortByChar = " Group_Name LIKE  '" & sortByChar & "%" & "' "

        Dim Query As String = "select Invoice_No,Group_Name,Invoice_Date,InvoiceAmount,InvoiceStatus,DepositDate from Invoice where InvoiceStatus='Invoice Cancelled' and " & sortByChar & "  "
        Dim DS As DataSet = FetchDataSet(Query, "Invoice")
        Return DS
    End Function

    Public Overloads Function getFreeUsersDetails() As DataTable
        'Dim Query As String = "select tbl1.user_id_no,tbl1.First_Name,tbl1.Last_Name,tbl1.Firm_Name,tbl1.Site_Name,tbl1.User_Name,tbl1.Registration_Date,tbl2.Account_Expiry from master_users as TBL1, Admin_Master as TBL2 where tbl1.Access_Type='Free' and (tbl1.user_id_no = tbl2.user_id_no)"
        Dim Query As String = "select First_Name,Last_Name,user_no,Firm_Name,User_Name,Registration_Date from master_users where Access_Type='Free'"
        Dim DT As DataTable = FetchDataSet(Query)
        Return DT
    End Function

    Public Overloads Function getFreeUsersDetails(ByVal sortByChar As String) As DataTable
        'Dim Query As String = "select tbl1.user_id_no,tbl1.First_Name,tbl1.Last_Name,tbl1.Firm_Name,tbl1.Site_Name,tbl1.User_Name,tbl1.Registration_Date,tbl2.Account_Expiry from master_users as TBL1, Admin_Master as TBL2 where tbl1.Access_Type='Free' and " & sortByChar & " and (tbl1.user_id_no = tbl2.user_id_no)"
        Dim Query As String = "select First_Name,Last_Name,user_no,Firm_Name,User_Name,Registration_Date from master_users where Access_Type='Free' and " & sortByChar & " "
        Dim DT As DataTable = FetchDataSet(Query)
        Return DT
    End Function


    Public Overloads Function getUsersDetails(ByVal AccountType As String) As DataTable
        'Dim Query As String = "select First_Name, Last_Name,user_id_no,Firm_Name,User_Name,Registration_Date ,group_name from master_users where Access_Type='" & AccountType & "' "
        Dim Query As String = "select First_Name,Last_Name,user_no,Firm_Name,User_Name,Registration_Date ,group_name  from master_users where Access_Type='" & AccountType & "' "
        Dim DT As DataTable = FetchDataSet(Query)
        Query = ""
        Return DT
    End Function


    Public Overloads Function getSingleUsersDetails() As DataTable
        Dim Query As String = "select First_Name,Last_Name,User_NO,Firm_Name,User_Name,Registration_Date from master_users where Access_Type='PAID SINGLE'"
        Dim DT As DataTable = FetchDataSet(Query)
        Query = ""
        Return DT
    End Function

    Public Overloads Function getCorporateUsersDetails() As DataTable
        Dim Query As String = "select First_Name,Last_Name,User_NO,Firm_Name,User_Name,Registration_Date from master_users where Access_Type='CORPORATE'"
        Dim DT As DataTable = FetchDataSet(Query)
        Query = ""
        Return DT
    End Function

    Public Overloads Function getUsersDetails(ByVal AccountType As String, ByVal sortByChar As String) As DataTable

        'sortByChar = " First_Name LIKE '" & sortByChar & "%" & "' "
        sortByChar = " User_Name LIKE '" & sortByChar & "%" & "' "
        Dim Query As String = "select First_Name,Last_Name,User_NO,Firm_Name,User_Name,Registration_Date ,group_name  from master_users where Access_Type='" & AccountType & "' and " & sortByChar & " "
        Dim DT As DataTable = FetchDataSet(Query)
        Query = ""
        Return DT
    End Function

    Public Overloads Function getGroupUsersDetails(ByVal AccountType As String, ByVal sortByChar As String) As DataTable


        sortByChar = " group_name LIKE '" & sortByChar & "%" & "' "
        'Dim Query As String = "select distinct First_Name,Last_Name,user_id_no,Firm_Name,User_Name,Registration_Date ,group_name  from master_users where Access_Type='" & AccountType & "' and " & sortByChar & " "
        Dim Query As String = "select distinct group_name, First_Name,Last_Name,Firm_Name, Registration_Date   from master_users where Access_Type='" & AccountType & "' and " & sortByChar & " "
        Dim DT As DataTable = FetchDataSet(Query)
        Query = ""
        Return DT
    End Function

    Public Overloads Function getGroupUsersDetails(ByVal AccountType As String) As DataTable
        Dim Query As String = "select distinct group_name, First_Name,Last_Name,Firm_Name, Registration_Date from master_users where Access_Type='" & AccountType & "'"
        Dim DT As DataTable = FetchDataSet(Query)
        Query = ""
        Return DT
    End Function

    Public Overloads Function getAllUsersDetails(ByVal SiteName As String) As DataTable
        Dim Query As String = "select First_Name,Last_Name,User_NO,Firm_Name,User_Name,Registration_Date,Access_Type , status , Site_Name from master_users where site_name = '" & SiteName & "'"
        Dim DT As DataTable = FetchDataSet(Query)
        Return DT
    End Function

    Public Overloads Function getAllUsersDetails() As DataTable
        Dim Query As String = "select First_Name,Last_Name,User_NO,Firm_Name,User_Name,Registration_Date,Access_Type , status, Site_Name from master_users"
        Dim DT As DataTable = FetchDataSet(Query)
        Return DT
    End Function

    Public Overloads Function getAllUsersDetails(ByVal sortByChar As String, ByVal SiteName As String) As DataTable

        'sortByChar = " First_Name LIKE  '" & sortByChar & "%" & "' "
        sortByChar = " User_Name LIKE  '" & sortByChar & "%" & "' "
        Dim Query As String = "select First_Name,Last_Name,User_NO,Firm_Name,User_Name,Registration_Date,Access_Type, status, Site_Name from master_users where  " & sortByChar & " and site_name = '" & SiteName & "'"
        Dim DT As DataTable = FetchDataSet(Query)
        Return DT
    End Function

    Public Overloads Function getAllUsersDetailsWithoutSitename(ByVal sortByChar As String) As DataTable

        'sortByChar = " First_Name LIKE  '" & sortByChar & "%" & "' "
        sortByChar = " User_Name LIKE  '" & sortByChar & "%" & "' "

        Dim Query As String = "select First_Name,Last_Name,User_NO,Firm_Name,User_Name,Registration_Date,Access_Type, status, Site_Name from master_users where  " & sortByChar & " "
        Dim DT As DataTable = FetchDataSet(Query)
        Return DT
    End Function
    Public Overloads Function getUserName(ByVal UserIdNo As String) As String

        Dim Username As String
        Dim DT As New DataTable()
        Dim conn As New SqlConnection(ConnectionString)
        Dim Query As String = "select UserName from Admin_Users where UserID=@UserID"
        Try
            Dim cmd As New SqlCommand(Query, conn)
            cmd.Parameters.Add("UserID", SqlDbType.VarChar, 10).Value = UserIdNo

            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)

            cmd = Nothing

            Username = DT.Rows(0).Item(0)
        Catch
            Username = ""
        Finally

        End Try

        Return Username
    End Function

    Public Overloads Function getUserNameByGroupID(ByVal groupID As String) As DataTable

        Dim DT As New DataTable()
        Dim conn As New SqlConnection(ConnectionString)
        Dim Query As String = "select nu.UserName from Account a inner join Customer c on c.CustomerID = a.CustomerID inner join Admin_Users nu on nu.AccountID =a.AccountID where nu.GroupID =@GID"
        Dim cmd As New SqlCommand(Query, conn)
        Try

            cmd.Parameters.Add("GID", SqlDbType.VarChar, 10).Value = groupID
            conn.Open()
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)




        Catch err As Exception
            Throw New ApplicationException("Error in connecting to DB " & err.Message)
        Finally
            conn.Close()
            Query = ""
            cmd = Nothing
        End Try

        Return DT
    End Function

    Public Overloads Function getStaffByCustomerID(ByVal customerID As String, ByVal event_id As Integer) As DataTable

        Dim DT As New DataTable()
        Dim conn As New SqlConnection(ConnectionString)
        Dim Query As String = "select CONVERT(varchar,StaffID) + ' - ' + StaffName As Staff from myseminars_Participants where CustomerID =@CID " & _
                                "and " & _
                               "myseminars_Participants.StaffID not in (SELECT myseminars_PrintParticipant.StaffID " & _
                                "FROM myseminars_PrintParticipant " & _
                                "where myseminars_PrintParticipant.EventID=@event_id)"
        Dim cmd As New SqlCommand(Query, conn)
        Try

            cmd.Parameters.Add("CID", SqlDbType.VarChar, 10).Value = customerID
            cmd.Parameters.Add("event_id", SqlDbType.BigInt, 10).Value = event_id
            conn.Open()
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)

        Catch err As Exception
            Throw New ApplicationException("Error in connecting to DB " & err.Message)
        Finally
            conn.Close()
            Query = ""
            cmd = Nothing
        End Try

        Return DT
    End Function
    Public Overloads Function getStaffByCustomerID_exist(ByVal customerID As String, ByVal event_id As Integer) As DataTable

        Dim DT As New DataTable()
        Dim conn As New SqlConnection(ConnectionString)
        Dim Query As String = "select CONVERT(varchar,StaffID) + ' - ' + StaffName As Staff from myseminars_Participants where CustomerID =@CID " & _
                                "and " & _
                               "myseminars_Participants.StaffID  in (SELECT myseminars_PrintParticipant.StaffID " & _
                                "FROM myseminars_PrintParticipant " & _
                                "where myseminars_PrintParticipant.EventID=@event_id)"
        Dim cmd As New SqlCommand(Query, conn)
        Try

            cmd.Parameters.Add("CID", SqlDbType.VarChar, 10).Value = customerID
            cmd.Parameters.Add("event_id", SqlDbType.BigInt, 10).Value = event_id
            conn.Open()
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)

        Catch err As Exception
            Throw New ApplicationException("Error in connecting to DB " & err.Message)
        Finally
            conn.Close()
            Query = ""
            cmd = Nothing
        End Try

        Return DT
    End Function
    Public Overloads Function getStaffByCustomerID_exist_edit_invoice(ByVal customerID As String, ByVal event_id As Integer, ByVal InvoiceNo As Integer) As DataTable

        Dim DT As New DataTable()
        Dim conn As New SqlConnection(ConnectionString)
        Dim Query As String = "select CONVERT(varchar,StaffID) + ' - ' + StaffName As Staff from myseminars_Participants where CustomerID =@CID " & _
                                "and " & _
                               "myseminars_Participants.StaffID  in (SELECT myseminars_PrintParticipant.StaffID " & _
                                "FROM myseminars_PrintParticipant " & _
                                "where myseminars_PrintParticipant.EventID=@event_id and myseminars_PrintParticipant.invoice_no <> @InvoiceNo)"
        Dim cmd As New SqlCommand(Query, conn)
        Try

            cmd.Parameters.Add("CID", SqlDbType.VarChar, 10).Value = customerID
            cmd.Parameters.Add("event_id", SqlDbType.BigInt, 10).Value = event_id
            cmd.Parameters.Add("InvoiceNo", SqlDbType.BigInt, 10).Value = InvoiceNo
            conn.Open()
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)

        Catch err As Exception
            Throw New ApplicationException("Error in connecting to DB " & err.Message)
        Finally
            conn.Close()
            Query = ""
            cmd = Nothing
        End Try

        Return DT
    End Function
    Public Overloads Function getStaffByCustomerID_edit_invoice(ByVal customerID As String, ByVal event_id As Integer, ByVal InvoiceNo As Integer) As DataTable

        Dim DT As New DataTable()
        Dim conn As New SqlConnection(ConnectionString)
        Dim Query As String = "select CONVERT(varchar,StaffID) + ' - ' + StaffName As Staff from myseminars_Participants where CustomerID =@CID "
        '                        "and " & _
        '                       "myseminars_Participants.StaffID  in (SELECT myseminars_PrintParticipant.StaffID " & _
        '                       "FROM myseminars_PrintParticipant where myseminars_PrintParticipant.EventID = @event_id  " & _
        '                        "and myseminars_PrintParticipant.invoice_no=@InvoiceNo) " & _
        '                        "UNION all " & _
        '                        "select CONVERT(varchar,StaffID) + ' - ' + StaffName As Staff from myseminars_Participants where CustomerID =@CID " & _
        '                       " and myseminars_Participants.StaffID not in (SELECT myseminars_PrintParticipant.StaffID " & _
        '                        "FROM myseminars_PrintParticipant " & _
        '                        "where myseminars_PrintParticipant.EventID=@event_id) "
        Dim cmd As New SqlCommand(Query, conn)
        Try

            cmd.Parameters.Add("CID", SqlDbType.VarChar, 10).Value = customerID
            cmd.Parameters.Add("event_id", SqlDbType.BigInt, 10).Value = event_id
            cmd.Parameters.Add("InvoiceNo", SqlDbType.BigInt, 10).Value = InvoiceNo
            conn.Open()
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)

        Catch err As Exception
            Throw New ApplicationException("Error in connecting to DB " & err.Message)
        Finally
            conn.Close()
            Query = ""
            cmd = Nothing
        End Try

        Return DT
    End Function

    Public Overloads Function getAllStaffIDs(ByVal customerID As String) As DataTable

        Dim DT As New DataTable()
        Dim conn As New SqlConnection(ConnectionString)
        Dim Query As String = "select cs.StaffID from myseminars_Participants cs inner join Customer c on c.CustomerID = cs.CustomerID where c.CustomerID=@cid"


        Dim cmd As New SqlCommand(Query, conn)
        Try

            cmd.Parameters.Add("cid", SqlDbType.VarChar, 10).Value = customerID
            conn.Open()
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)

        Catch err As Exception
            Throw New ApplicationException("Error in connecting to DB " & err.Message)
        Finally
            conn.Close()
            Query = ""
            cmd = Nothing
        End Try

        Return DT
    End Function

    Public Overloads Function getEventIDAndStaffID(ByVal customerID As String) As DataTable

        Dim DT As New DataTable()
        Dim conn As New SqlConnection(ConnectionString)
        Dim Query As String = "select p.ProductID,mpp.StaffID from Admin_Product p inner join myseminars_PrintParticipant mpp on p.ProductID = mpp.EventID "
        Query &= "inner join myseminars_Participants cs on cs.StaffID = mpp.StaffID inner join Customer c on c.CustomerID = cs.CustomerID "
        Query &= "where c.CustomerID=@cid"

        Dim cmd As New SqlCommand(Query, conn)
        Try

            cmd.Parameters.Add("cid", SqlDbType.VarChar, 10).Value = customerID
            conn.Open()
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)

        Catch err As Exception
            Throw New ApplicationException("Error in connecting to DB " & err.Message)
        Finally
            conn.Close()
            Query = ""
            cmd = Nothing
        End Try

        Return DT
    End Function

    Public Overloads Function getEventDetails(ByVal invoiceNum As Integer, ByVal customerName As String) As DataTable

        Dim DT As New DataTable()
        Dim conn As New SqlConnection(ConnectionString)
        Dim Query As String = "select p.EventID As ProductID,p.EventName As [Event],p.EventDetails, mpp.StaffID"
        Query &= ", cs.StaffName, p.PDate, p.EventDate, p.EventTime, cs.jobtitle "
        Query &= "from myseminars_Event p "
        Query &= "inner join myseminars_PrintParticipant mpp on p.EventID = mpp.EventID "
        Query &= "inner join myseminars_Participants cs on cs.StaffID = mpp.StaffID "
        Query &= "inner join myseminars_Clients c on c.CustomerID = cs.CustomerID "
        Query &= "inner join myseminars_InvoiceProduct ip on p.EventID =ip.EventID "
        Query &= "where ip.InvoiceNo =@invoicenum and c.CustomerName =@cname and mpp.invoice_no=@invoicenum"
        Dim cmd As New SqlCommand(Query, conn)
        Try

            cmd.Parameters.Add("invoicenum", SqlDbType.BigInt).Value = invoiceNum
            cmd.Parameters.Add("cname", SqlDbType.VarChar, 35).Value = customerName
            conn.Open()
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)

        Catch err As Exception
            Throw New ApplicationException("Error in connecting to DB " & err.Message)
        Finally
            conn.Close()
            Query = ""
            cmd = Nothing
        End Try

        Return DT
    End Function

    Public Overloads Function getEventSpeaker(ByVal eventID As Integer) As DataTable

        Dim DT As New DataTable()
        Dim conn As New SqlConnection(ConnectionString)
        Dim Query As String = "select e.Event_ID, s.Name from myseminars_EventSpeaker e inner join myseminars_Speakers s on s.SpeakerID = e.SpeakerID where e.Event_ID =@eid"

        Dim cmd As New SqlCommand(Query, conn)
        Try

            cmd.Parameters.Add("eid", SqlDbType.Int).Value = eventID
            conn.Open()
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)

        Catch err As Exception
            Throw New ApplicationException("Error in connecting to DB " & err.Message)
        Finally
            conn.Close()
            Query = ""
            cmd = Nothing
        End Try

        Return DT
    End Function

    Public Overloads Function getUserNameByCustomerName(ByVal customerName As String) As String

        Dim userName As String
        Dim DT As New DataTable()
        Dim conn As New SqlConnection(ConnectionString)
        Dim Query As String = "select nu.UserName from Account a inner join Customer c on c.CustomerID = a.CustomerID inner join Admin_Users nu on nu.AccountID =a.AccountID where c.CustomerName=@CName"
        Try
            Dim cmd As New SqlCommand(Query, conn)
            cmd.Parameters.Add("CName", SqlDbType.VarChar, 35).Value = customerName

            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)

            cmd = Nothing

            userName = DT.Rows(0).Item(0)
        Catch
            userName = ""
        Finally

        End Try

        Return userName
    End Function

    Public Overloads Function getReason(ByVal UserIdNo As String) As String

        Dim reason As String
        Dim DT As New DataTable()
        Dim conn As New SqlConnection(ConnectionString)
        Dim Query As String = "select Remarks from Admin_Users where UserID=@UserID"
        Try
            Dim cmd As New SqlCommand(Query, conn)
            cmd.Parameters.Add("UserID", SqlDbType.VarChar, 10).Value = UserIdNo

            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)

            cmd = Nothing

            reason = DT.Rows(0).Item(0)
        Catch
            reason = ""
        Finally

        End Try

        Return reason
    End Function

    Public Overloads Function getSiteName(ByVal SiteId As Short) As String
        Dim SiteName As String
        Dim Query As String
        Query = "select SiteName from tblSites where siteId=" & SiteId
        Dim DT As DataTable = FetchDataSet(Query)
        SiteName = DT.Rows(0).Item(0)
        Return SiteName
    End Function

    Public Function getUserID(ByVal GroupName As Long) As Long
        Dim UserId As Long
        Dim Query As String = "select user_no from master_users where Group_Name= '" & GroupName & "'"
        Dim DT As DataTable = FetchDataSet(Query)
        UserId = CLng(DT.Rows(0).Item(0))
        Return UserId
    End Function

    Public Function getUserAllID(ByVal GroupName As String) As DataTable

        Dim Query As String = "select user_no from master_users where Group_Name= '" & GroupName & "'"
        Dim DT As DataTable = FetchDataSet(Query)

        Return DT
    End Function
    Public Function getUserNameFromGroupName(ByVal GroupName As String) As DataTable

        Dim Query As String = "select user_name from master_users where Group_Name= '" & GroupName & "'"
        Dim DT As DataTable = FetchDataSet(Query)

        Return DT
    End Function

    Public Function getGroupNameFromId(ByVal UserId As Long) As String
        Dim GroupName As String
        Dim Query As String = "select group_name from master_users where user_id_no= " & UserId
        Dim DT As DataTable = FetchDataSet(Query)
        GroupName = CStr(DT.Rows(0).Item(0))
        Return GroupName
    End Function

    Public Overloads Function getUserIdFromInvoiceTBL(ByVal InvoiceNo As Long) As Long
        Dim UserIdNo As Long
        Dim Query As String = "select user_id_no from InvoiceMembers where Invoice_no= " & InvoiceNo
        Dim DT As DataTable = FetchDataSet(Query)
        UserIdNo = DT.Rows(0).Item(0)
        Return UserIdNo
    End Function
    Public Function getUserNoAccount(ByVal CustomerID As String) As Integer
        Dim UserIdNo As Integer
        Dim Query As String = "select No_Of_Users from account where CustomerID='" & CustomerID & "'"
        Dim DT As DataTable = FetchDataSet(Query)
        UserIdNo = DT.Rows(0).Item(0)
        Return UserIdNo
    End Function
    Public Function getCustomerQuantity(ByVal CustomerID As String) As Integer
        Dim Qty As Integer
        Dim Query As String = "Select Quantity , AP.InvoiceNo  from Invoice INNER JOIN Admin_InvoiceProduct AP on Invoice.InvoiceNo = AP.InvoiceNo  where CustomerID='" & CustomerID & "'"

        Dim DT As DataTable = FetchDataSet(Query)
        If Not DT.Rows.Count = 0 Then
            Qty = DT.Rows(0).Item(0)
        End If

        Return Qty
    End Function
    Public Overloads Function getMembersDetails() As DataSet
        Dim Query As String = "select First_Name,Firm_Name,User_Name,Registration_Date,Acct_Expiry from master_users where Access_Type<>'Free' "
        Dim DS As DataSet = FetchDataSet(Query, "master_users")
        Return DS
    End Function

    Public Overloads Function getMembersDetails(ByVal sortByChar As String) As DataSet
        sortByChar = " First_Name LIKE  '" & sortByChar & "%" & "' "
        Dim Query As String = "select First_Name,Firm_Name,User_Name,Registration_Date,Acct_Expiry from master_users where Access_Type<>'Free' and " & sortByChar & " "
        Dim DS As DataSet = FetchDataSet(Query, "master_users")
        Return DS
    End Function

    Public Overloads Function getMembersMoreDetails() As DataSet
        Dim Query As String = "select First_Name,Firm_Name,User_Name,Registration_Date,Acct_Expiry,Email_ID,Phone_Number,Ip_Address,Bandwith from master_users where Access_Type<>'Free' "
        Dim DS As DataSet = FetchDataSet(Query, "master_users")
        Return DS
    End Function

    Public Overloads Function getMembersMoreDetails(ByVal sortByChar As String) As DataSet
        sortByChar = " First_Name LIKE  '" & sortByChar & "%" & "' "
        Dim Query As String = "select First_Name,Firm_Name,User_Name,Registration_Date,Acct_Expiry,Email_ID,Phone_Number from master_users where Access_Type<>'Free' and " & sortByChar & " "
        Dim DS As DataSet = FetchDataSet(Query, "master_users")
        Return DS
    End Function

    Public Overloads Function getConfirmedMembers() As DataSet
        Dim Query As String = "select First_Name,Firm_Name,User_Name,Registration_Date,Acct_Expiry from master_users where Access_Type<>'Free' and Status='Confirmed' "
        Dim DS As DataSet = FetchDataSet(Query, "master_users")
        Return DS
    End Function

    Public Overloads Function getConfirmedMembers(ByVal sortByChar As String) As DataSet
        sortByChar = " First_Name LIKE  '" & sortByChar & "%" & "' "
        Dim Query As String = "select First_Name,Firm_Name,User_Name,Registration_Date,Acct_Expiry from master_users where Access_Type<>'Free' and Status='Confirmed' and " & sortByChar & " "
        Dim DS As DataSet = FetchDataSet(Query, "master_users")
        Return DS
    End Function

    Public Overloads Function getPaymentPending() As DataSet
        Dim Query As String = "select First_Name,Firm_Name,User_Name,Registration_Date,Acct_Expiry from master_users where Access_Type<>'Free' and Status='Payment Pending' "
        Dim DS As DataSet = FetchDataSet(Query, "master_users")
        Return DS
    End Function

    Public Overloads Function getPaymentPending(ByVal sortByChar As String) As DataSet
        sortByChar = " First_Name LIKE  '" & sortByChar & "%" & "' "
        Dim Query As String = "select First_Name,Firm_Name,User_Name,Registration_Date,Acct_Expiry from master_users where Access_Type<>'Free' and Status='Confirmed' and " & sortByChar & " "
        Dim DS As DataSet = FetchDataSet(Query, "master_users")
        Return DS
    End Function

    Public Overloads Function getCreditCardPayments() As DataSet
        Dim Query As String = "select First_Name,Firm_Name,User_Name,Registration_Date,Acct_Expiry from master_users where Access_Type<>'Free' and Mode_of_payment='Credit Card' "
        Dim DS As DataSet = FetchDataSet(Query, "master_users")
        Return DS
    End Function

    Public Overloads Function getCreditCardPayments(ByVal sortByChar As String) As DataSet
        sortByChar = " First_Name LIKE  '" & sortByChar & "%" & "' "
        Dim Query As String = "select First_Name,Firm_Name,User_Name,Registration_Date,Acct_Expiry from master_users where Access_Type<>'Free' and Mode_of_payment='Credit Card' and " & sortByChar & " "
        Dim DS As DataSet = FetchDataSet(Query, "master_users")
        Return DS
    End Function

    Public Overloads Function getChecquePayments() As DataSet
        Dim Query As String = "select First_Name,Firm_Name,User_Name,Registration_Date,Acct_Expiry from master_users where Access_Type<>'Free' and Mode_of_payment='Cheque' "
        Dim DS As DataSet = FetchDataSet(Query, "master_users")
        Return DS
    End Function

    Public Overloads Function getChecquePayments(ByVal sortByChar As String) As DataSet
        sortByChar = " First_Name LIKE  '" & sortByChar & "%" & "' "
        Dim Query As String = "select First_Name,Firm_Name,User_Name,Registration_Date,Acct_Expiry from master_users where Access_Type<>'Free' and Mode_of_payment='Cheque' and " & sortByChar & " "
        Dim DS As DataSet = FetchDataSet(Query, "master_users")
        Return DS
    End Function

    Public Overloads Function getExpiredUsers() As DataSet
        Dim currentDateTime As String = System.DateTime.Now
        Dim Query As String = "select First_Name,Firm_Name,User_Name,Registration_Date,Acct_Expiry from master_users where Access_Type<>'Free' and Acct_Expiry<'" & currentDateTime & "' "
        Dim DS As DataSet = FetchDataSet(Query, "master_users")
        Return DS
    End Function

    Public Overloads Function getExpiredUsers(ByVal sortByChar As String) As DataSet
        Dim currentDateTime As String = System.DateTime.Now
        sortByChar = " First_Name LIKE  '" & sortByChar & "%" & "' "
        Dim Query As String = "select First_Name,Firm_Name,User_Name,Registration_Date,Acct_Expiry from master_users where Access_Type<>'Free' and Acct_Expiry<'" & currentDateTime & "' and " & sortByChar & " "
        Dim DS As DataSet = FetchDataSet(Query, "master_users")
        Return DS
    End Function

    Public Overloads Function getMonthlyReport(ByVal selDate1 As String, ByVal selDate2 As String) As DataSet
        Dim currentDateTime1 As Date  ' String = selDate
        Dim currentDateTime2 As Date
        currentDateTime1 = System.Convert.ToDateTime(selDate1)
        currentDateTime2 = System.Convert.ToDateTime(selDate2)
        Dim Query As String = "select First_Name,Firm_Name,User_Name,Registration_Date,Acct_Expiry from master_users where Access_Type<>'Free' and (Acct_Expiry>'" & currentDateTime1 & "' and Acct_Expiry<'" & currentDateTime1 & "') "
        Dim DS As DataSet = FetchDataSet(Query, "master_users")
        Return DS
    End Function

    Public Overloads Function getMonthlyReport(ByVal selDate1 As String, ByVal selDate2 As String, ByVal sortByChar As String) As DataSet
        Dim currentDateTime1 As Date  ' String = selDate
        Dim currentDateTime2 As Date
        currentDateTime1 = System.Convert.ToDateTime(selDate1)
        currentDateTime2 = System.Convert.ToDateTime(selDate2)

        sortByChar = " First_Name LIKE  '" & sortByChar & "%" & "' "
        Dim Query As String = "select First_Name,Firm_Name,User_Name,Registration_Date,Acct_Expiry from master_users where Access_Type<>'Free' and " & sortByChar & "  and (Acct_Expiry>'" & currentDateTime1 & "' and Acct_Expiry<'" & currentDateTime1 & "') "
        Dim DS As DataSet = FetchDataSet(Query, "master_users")
        Return DS
    End Function

    Public Function getLastBillNo() As DataSet
        ' buggy
        Dim Query As String = "select Bil from master_users where Bil=max(Bil) "
        Dim DS As DataSet = FetchDataSet(Query, "master_users")
        Return DS
    End Function

    Public Function getProduct(ByVal productGroup As String) As DataSet

        'Dim Query As String = "select PName As [ProductName] From Admin_Product"
        'Dim DS As DataSet = FetchDataSet(Query, "Admin_Product")
        'Return DS
        Dim conn As New SqlConnection(ConnectionString)
        Dim ds As New DataSet
        'Dim Reader1 As SqlClient.SqlDataReader
        Try

            Dim cmd As New SqlCommand("SELECT PName As [ProductName],ProductID as [product_id] From Admin_Product where PName Not IN ('ElawV1' ,'IT BOOK' , 'MLRH'  , 'book', 'law management' , 'legacy test bread' , 'Single user', 'Single User01', 'ELAW DL', 'reading books', 'EJ01', 'EJ02', 'EJ03', 'EJ04', 'EJ05', 'EJ06' ,  'EJ07' , 'EJ08' , 'EJ09' , 'EJ10' , 'EL11' , 'EJ12' , 'EJ13' , 'EJ14' , 'EJ15' ) AND ProductGroupID=@pgi and Status='Active'")
            'Dim cmd As New SqlCommand("select PName As [ProductName],ProductID as [product_id] From Admin_Product where ProductGroupID=@pgi and Status='Active'")
            cmd.Connection = conn
            cmd.Parameters.Add("@pgi", SqlDbType.VarChar, 10).Value = productGroup
            Dim adapter As New SqlDataAdapter(cmd)

            adapter.Fill(ds, "Admin_Product")

        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally
            conn.Close()
        End Try

        Return ds
    End Function

    Public Function getListOfSpeakers() As DataSet
        Dim Query As String = "select SpeakerID, Name, Email,Tel from myseminars_Speakers"
        Dim DS As DataSet = FetchDataSet(Query, "myseminars_Speakers")
        Return DS
    End Function

    Public Function getCustomer() As DataSet
        Dim Query As String = "select c.CustomerID + ' - ' + c.CustomerName + ' - ' + a.AName As [Customer] from Customer c inner join Account a on a.CustomerID =c.CustomerID where   a.Acct_Type <> 'Legal_revi' order by a.Reg_Date desc"
        Dim DS As DataSet = FetchDataSet(Query, "Customer")
        Return DS
    End Function
    Public Function getCustomertoaAddInvoice(ByVal CustomerID As String) As DataSet
        'Change by shhanila  >  to get the exact customer instead of complete list of customer
        Dim Query As String = "select c.CustomerID + ' - ' + c.CustomerName + ' - ' + a.AName As [Customer] from Customer c inner join Account a on a.CustomerID =c.CustomerID where   a.Acct_Type <> 'Legal_revi'  and c.CustomerID ='" & CustomerID & "' order by a.Reg_Date desc"

        Dim DS As DataSet = FetchDataSet(Query, "Customer")
        Return DS
    End Function
    Public Function getCustomer_legalReview() As DataSet
        Dim Query As String = "select c.CustomerID + ' - ' + c.CustomerName As [Customer] from Customer c inner join Account a on a.CustomerID =c.CustomerID where a.Acct_Type like 'Legal_revi'"
        Dim DS As DataSet = FetchDataSet(Query, "Customer")
        Return DS
    End Function

    Public Function getListOfStaff() As DataSet
        Dim Query As String = " select distinct cs.StaffID,c.CustomerName,cs.StaffName,cs.JobTitle,cs.Telno,cs.Faxno, e.EventName,MA.Reg_Date from myseminars_Participants cs "
        Query &= " inner join myseminars_Clients c on c.CustomerID = cs.CustomerID "
        Query &= " inner join myseminars_Invoice i on i.CustomerID = c.CustomerID "
        Query &= " inner join myseminars_InvoiceProduct ip on ip.InvoiceNo = i.InvoiceNo "
        Query &= " inner join myseminars_Event e on e.EventID = ip.EventID "
        Query &= " inner join myseminars_Account MA on c.CustomerID=MA.CustomerID"
        Query &= " order by MA.Reg_Date desc"
        Dim DS As DataSet = FetchDataSet(Query, "myseminars_Participants")
        Return DS
    End Function

    Public Function getSpeaker() As DataSet
        Dim Query As String = "select CONVERT(varchar,SpeakerID) + ' - ' + Name As Speaker from myseminars_Speakers"
        Dim DS As DataSet = FetchDataSet(Query, "myseminars_Speakers")
        Return DS
    End Function

    Public Function getEventType() As DataSet
        ' buggy
        Dim Query As String = "select Code from myseminars_EventType"
        Dim DS As DataSet = FetchDataSet(Query, "myseminars_EventType")
        Return DS
    End Function

    Public Function getListOfStaffByCustomer(ByVal order As String) As DataSet
        Dim Query As String = ""

        If order = "ASC" Then
            Query = " select distinct cs.StaffID,c.CustomerName,cs.StaffName,cs.JobTitle,cs.Telno,cs.Faxno, e.EventName,MA.Reg_Date from myseminars_Participants cs "
            Query &= " inner join myseminars_Clients c on c.CustomerID = cs.CustomerID "
            Query &= " inner join myseminars_Invoice i on i.CustomerID = c.CustomerID "
            Query &= " inner join myseminars_InvoiceProduct ip on ip.InvoiceNo = i.InvoiceNo "
            Query &= " inner join myseminars_Event e on e.EventID = ip.EventID "
            Query &= " inner join myseminars_Account MA on c.CustomerID=MA.CustomerID"
            Query &= " ORDER BY c.CustomerName"
            'Query = "select distinct cs.StaffID,c.CustomerName,cs.StaffName,cs.JobTitle,cs.Telno,cs.Faxno, e.EventName from myseminars_Participants cs inner join myseminars_Clients c on c.CustomerID = cs.CustomerID inner join myseminars_Invoice i on i.CustomerID = c.CustomerID inner join myseminars_InvoiceProduct ip on ip.InvoiceNo = i.InvoiceNo inner join myseminars_Event e on e.EventID = ip.EventID ORDER BY c.CustomerName"
        ElseIf order = "DESC" Then
            Query = " select distinct cs.StaffID,c.CustomerName,cs.StaffName,cs.JobTitle,cs.Telno,cs.Faxno, e.EventName,MA.Reg_Date from myseminars_Participants cs "
            Query &= " inner join myseminars_Clients c on c.CustomerID = cs.CustomerID "
            Query &= " inner join myseminars_Invoice i on i.CustomerID = c.CustomerID "
            Query &= " inner join myseminars_InvoiceProduct ip on ip.InvoiceNo = i.InvoiceNo "
            Query &= " inner join myseminars_Event e on e.EventID = ip.EventID "
            Query &= " inner join myseminars_Account MA on c.CustomerID=MA.CustomerID"
            Query &= " ORDER BY c.CustomerName DESC"
            'Query = "select distinct cs.StaffID,c.CustomerName,cs.StaffName,cs.JobTitle,cs.Telno,cs.Faxno, e.EventName from myseminars_Participants cs inner join myseminars_Clients c on c.CustomerID = cs.CustomerID inner join myseminars_Invoice i on i.CustomerID = c.CustomerID inner join myseminars_InvoiceProduct ip on ip.InvoiceNo = i.InvoiceNo inner join myseminars_Event e on e.EventID = ip.EventID ORDER BY c.CustomerName DESC"
        End If
        Dim DS As DataSet = FetchDataSet(Query, "myseminars_Participants")
        Return DS
    End Function

    Public Function getListOfStaffByStaff(ByVal order As String) As DataSet
        Dim Query As String = ""

        If order = "ASC" Then
            Query = " select distinct cs.StaffID,c.CustomerName,cs.StaffName,cs.JobTitle,cs.Telno,cs.Faxno, e.EventName,MA.Reg_Date from myseminars_Participants cs "
            Query &= " inner join myseminars_Clients c on c.CustomerID = cs.CustomerID "
            Query &= " inner join myseminars_Invoice i on i.CustomerID = c.CustomerID "
            Query &= " inner join myseminars_InvoiceProduct ip on ip.InvoiceNo = i.InvoiceNo "
            Query &= " inner join myseminars_Event e on e.EventID = ip.EventID "
            Query &= " inner join myseminars_Account MA on c.CustomerID=MA.CustomerID"
            Query &= " ORDER BY cs.StaffName"
            'Query = "select distinct cs.StaffID,c.CustomerName,cs.StaffName,cs.JobTitle,cs.Telno,cs.Faxno, e.EventName from myseminars_Participants cs inner join myseminars_Clients c on c.CustomerID = cs.CustomerID inner join myseminars_Invoice i on i.CustomerID = c.CustomerID inner join myseminars_InvoiceProduct ip on ip.InvoiceNo = i.InvoiceNo inner join myseminars_Event e on e.EventID = ip.EventID ORDER BY cs.StaffName"
        ElseIf order = "DESC" Then
            Query = " select distinct cs.StaffID,c.CustomerName,cs.StaffName,cs.JobTitle,cs.Telno,cs.Faxno, e.EventName,MA.Reg_Date from myseminars_Participants cs "
            Query &= " inner join myseminars_Clients c on c.CustomerID = cs.CustomerID "
            Query &= " inner join myseminars_Invoice i on i.CustomerID = c.CustomerID "
            Query &= " inner join myseminars_InvoiceProduct ip on ip.InvoiceNo = i.InvoiceNo "
            Query &= " inner join myseminars_Event e on e.EventID = ip.EventID "
            Query &= " inner join myseminars_Account MA on c.CustomerID=MA.CustomerID"
            Query &= " ORDER BY cs.StaffName DESC"
            'Query = "select distinct cs.StaffID,c.CustomerName,cs.StaffName,cs.JobTitle,cs.Telno,cs.Faxno, e.EventName from myseminars_Participants cs inner join myseminars_Clients c on c.CustomerID = cs.CustomerID inner join myseminars_Invoice i on i.CustomerID = c.CustomerID inner join myseminars_InvoiceProduct ip on ip.InvoiceNo = i.InvoiceNo inner join myseminars_Event e on e.EventID = ip.EventID ORDER BY cs.StaffName DESC"
        End If

        Dim DS As DataSet = FetchDataSet(Query, "myseminars_Participants")
        Return DS
    End Function
    Public Function getListOfStaffByRegdate(ByVal order As String) As DataSet
        Dim Query As String = ""

        If order = "ASC" Then
            Query = " select distinct cs.StaffID,c.CustomerName,cs.StaffName,cs.JobTitle,cs.Telno,cs.Faxno, e.EventName,MA.Reg_Date from myseminars_Participants cs "
            Query &= " inner join myseminars_Clients c on c.CustomerID = cs.CustomerID "
            Query &= " inner join myseminars_Invoice i on i.CustomerID = c.CustomerID "
            Query &= " inner join myseminars_InvoiceProduct ip on ip.InvoiceNo = i.InvoiceNo "
            Query &= " inner join myseminars_Event e on e.EventID = ip.EventID "
            Query &= " inner join myseminars_Account MA on c.CustomerID=MA.CustomerID"
            Query &= " order by MA.Reg_Date"
            'Query = "select distinct cs.StaffID,c.CustomerName,cs.StaffName,cs.JobTitle,cs.Telno,cs.Faxno, e.EventName from myseminars_Participants cs inner join myseminars_Clients c on c.CustomerID = cs.CustomerID inner join myseminars_Invoice i on i.CustomerID = c.CustomerID inner join myseminars_InvoiceProduct ip on ip.InvoiceNo = i.InvoiceNo inner join myseminars_Event e on e.EventID = ip.EventID ORDER BY cs.StaffName"
        ElseIf order = "DESC" Then
            Query = " select distinct cs.StaffID,c.CustomerName,cs.StaffName,cs.JobTitle,cs.Telno,cs.Faxno, e.EventName,MA.Reg_Date from myseminars_Participants cs "
            Query &= " inner join myseminars_Clients c on c.CustomerID = cs.CustomerID "
            Query &= " inner join myseminars_Invoice i on i.CustomerID = c.CustomerID "
            Query &= " inner join myseminars_InvoiceProduct ip on ip.InvoiceNo = i.InvoiceNo "
            Query &= " inner join myseminars_Event e on e.EventID = ip.EventID "
            Query &= " inner join myseminars_Account MA on c.CustomerID=MA.CustomerID"
            Query &= " order by MA.Reg_Date desc"
            'Query = "select distinct cs.StaffID,c.CustomerName,cs.StaffName,cs.JobTitle,cs.Telno,cs.Faxno, e.EventName from myseminars_Participants cs inner join myseminars_Clients c on c.CustomerID = cs.CustomerID inner join myseminars_Invoice i on i.CustomerID = c.CustomerID inner join myseminars_InvoiceProduct ip on ip.InvoiceNo = i.InvoiceNo inner join myseminars_Event e on e.EventID = ip.EventID ORDER BY cs.StaffName DESC"
        End If

        Dim DS As DataSet = FetchDataSet(Query, "myseminars_Participants")
        Return DS
    End Function
    'Public Function isFileExist1(ByVal FileName As String) As Boolean
    '    '' Function Details:
    '    '' This is for checking if the file is already uploaded or not. if CheckingFileExist is
    '    '' false this means it is not uploaded and not existed in the system and vice versa

    '    Dim conn As New SqlConnection(ConnectionString)

    '    Dim RecFileName As String
    '    Dim FileCount As Int32 ' Because DataFile will always be 1 if it exist in table
    '    Dim SqlQuery As String = "select count(*) from cases where datafilename = '" & FileName & "'"
    '    Dim ErrMsg As String
    '    Dim cmd = New SqlCommand(SqlQuery, conn)
    '    Dim Reader As SqlDataReader()
    '    Try
    '        conn.Open()
    '        Reader = cmd.ExecuteReader()

    '        'While Reader.Read()
    '        '    FileCount = Reader
    '        'End While


    '        If FileCount = 0 Then
    '            isFileExist = False ' file not Exist
    '        Else
    '            isFileExist = True  ' File Exist
    '        End If

    '    Catch err As Exception
    '        ErrMsg = err.Message

    '    Finally
    '        conn.Close()
    '        conn = Nothing
    '        cmd = Nothing
    '        Reader = Nothing

    '        RecFileName = ""
    '        FileCount = 0
    '        SqlQuery = ""
    '        ErrMsg = ""

    '    End Try

    '    Return isFileExist
    'End Function

    Public Function RecordFound(ByVal Query As String) As Boolean
        '/* Note
        ' This function is for searching record in table. specially if there 
        'is some repeatetion in the table so we can eliminate redundancy while
        'inserting record in table 
        ' */
        Dim Reader1 As Data.SqlClient.SqlDataReader
        Dim Conn As New SqlClient.SqlConnection(ConnectionString)
        Dim Cmd As New SqlClient.SqlCommand(Query, Conn)


        'Dim Adapter As New SqlDataAdapter(Cmd)
        'Dim DS As New Data.DataSet()

        Dim RecordFoundCount As Int16
        RecordFoundCount = 0
        Try
            Conn.Open()
            Reader1 = Cmd.ExecuteReader '.ExecuteScalar '.ExecuteReader
            '   Adapter.Fill(DS)
            Do While Reader1.Read
                RecordFoundCount = RecordFoundCount + 1

            Loop
            Reader1.Close()
            If RecordFoundCount >= 1 Then
                RecordFound = True
            Else
                RecordFound = False

            End If
        Catch Err As Exception
            Dim lblErr As New Label
            lblErr.Text = "This is the Err Raised.." & Err.Message
            Throw New Exception("Err on searching..")

        Finally

            Conn.Close()

            'Conn.Dispose()
            'Cmd.Dispose()
            RecordFoundCount = 0
        End Try

        Return RecordFound
    End Function

    Public Function getNextInvoiceNo() As Long
        '/* Note
        ' This function is for searching record in table. specially if there 
        'is some repeatetion in the table so we can eliminate redundancy while
        'inserting record in table 
        ' */
        Dim Query As String = "select max(Invoice_No) from InvoiceMembers"
        Dim conn As New SqlConnection(ConnectionString)
        Dim Reader As SqlDataReader
        Dim InvoiceNo As Long
        Dim cmd As New SqlCommand(Query, conn)
        Try

            conn.Open()
            Reader = cmd.ExecuteReader

            While Reader.Read()
                InvoiceNo = Reader(0) '("onlineStatus")
            End While
            'If InvoiceNo = 0 Then
            '    InvoiceNo = 1
            'End If
            InvoiceNo = InvoiceNo + 1


        Catch err As Exception
            Throw New ApplicationException("Error in connecting to DB " & err.Message)
        Finally
            conn.Close()
            cmd = Nothing
            Reader.Close()
            Reader = Nothing
            conn = Nothing
            Query = ""
        End Try

        Return InvoiceNo
    End Function

    Public Function getLastProductID() As Integer

        Dim Query As String = "select max(ProductID) from Admin_Product"
        Dim conn As New SqlConnection(ConnectionString)
        Dim Reader As SqlDataReader
        Dim ProductID As Integer
        Dim cmd As New SqlCommand(Query, conn)
        Try

            conn.Open()
            Reader = cmd.ExecuteReader

            While Reader.Read()
                ProductID = Reader(0) '("onlineStatus")
            End While


        Catch err As Exception
            Throw New ApplicationException("Error in connecting to DB " & err.Message)
        Finally
            conn.Close()
            cmd = Nothing
            Reader = Nothing
            conn = Nothing
            Query = ""
        End Try

        Return ProductID
    End Function

    Public Function GetUserDetailsForAdmin() As DataTable
        Dim DT As DataTable = FetchDataTable("sp_getUserDetailsAdminVersion")

        Return DT
    End Function

    Public Function GetMYSUserDetailsForAdmin() As DataTable
        Dim DT As DataTable = FetchDataTable("sp_getMYSUserDetailsAdminVersion")

        Return DT
    End Function

    Public Function GetUserDetailsForAdminBasedOnUserOrProduct(ByVal storedProcedure As String, ByVal parameterName1 As String, ByVal parameterName2 As String, ByVal criteria As String, ByVal criteria2 As String, ByVal type As String) As DataTable
        Dim DT As DataTable = FetchDataTable2(criteria, parameterName1, criteria2, parameterName2, storedProcedure, type)

        Return DT
    End Function

    Public Function GetUnpaidInvoice(ByVal productGroup As String) As DataSet
        Dim DS As DataSet = FetchDataSet2(productGroup, "@pgi", "sp_getUnpaidInvoice")

        Return DS
    End Function

    Public Function GetPaidInvoice(ByVal productGroup As String) As DataSet
        Dim DS As DataSet = FetchDataSet2(productGroup, "@pgi", "sp_getPaidInvoice")

        Return DS
    End Function

    Public Function GetCancelledInvoice(ByVal productGroup As String) As DataSet
        Dim DS As DataSet = FetchDataSet2(productGroup, "@pgi", "sp_getCancelledInvoice")

        Return DS
    End Function

    Public Function GetStandardInvoice(ByVal productGroup As String) As DataSet
        Dim DS As DataSet = FetchDataSet2(productGroup, "@pgi", "sp_getStandardInvoice")

        Return DS
    End Function

    Public Function GetStandardProduct(ByVal productGroup As String) As DataSet
        Dim DS As DataSet = FetchDataSet2(productGroup, "@pgi", "sp_getStandardProduct")

        Return DS
    End Function

    Public Function GetStandardAccount() As DataSet
        Dim DS As DataSet = FetchDataSet3("sp_getStandardAccount")

        Return DS
    End Function
    Public Function GetStandardAccount_legal_reivew() As DataSet
        Dim DS As New DataSet
        Dim Query As String = "SELECT A.[AccountID],c.CustomerName,A.[Confirm_Date],A.[Acct_Type]," & _
      " CASE " & _
    "WHEN Acct_Type='Single' THEN 1 " & _
    "WHEN Acct_Type='Free' THEN 1 " & _
   " WHEN Acct_Type='Group' THEN g.No_Of_Members " & _
        "END As [No_Of_Users]," & _
    " [AllocatedSize],A.[Acct_Expiry],A.[CreatedStaff]," & _
     "CASE " & _
  "WHEN DATEDIFF(dd,A.Confirm_Date,GETDATE()) <= 30 THEN '30' " & _
  "WHEN DATEDIFF(dd,A.Confirm_Date,GETDATE()) <= 60 THEN '60' " & _
  "WHEN DATEDIFF(dd,A.Acct_Expiry,GETDATE())<=0 THEN CONVERT(VARCHAR,DATEDIFF(dd,A.Confirm_Date,GETDATE())) " & _
  "WHEN DATEDIFF(dd,A.Acct_Expiry,GETDATE())>0 THEN 'Expired' " & _
  "END As [Duration] " & _
   "FROM [elawdb].[dbo].[Account] A " & _
   "INNER JOIN [elawdb].[dbo].Customer C on c.CustomerID = a.CustomerID " & _
   "LEFT OUTER JOIN [Admin_Group] g on g.AccountID = a.AccountID" & _
  " where A.Acct_Type = 'Legal_revi'"
        Try

            Dim conn As New SqlConnection(ConnectionString)

            Dim cmd As New SqlCommand()
            cmd.Connection = conn
            cmd.CommandText = Query
            cmd.CommandType = CommandType.Text

            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            Dim adapter As New SqlDataAdapter(cmd)

            adapter.Fill(DS)
            conn.Close()

        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally

        End Try




        Return DS
    End Function

    Public Function GetStandardUser() As DataSet
        Dim DS As DataSet = FetchDataSet3("sp_getStandardUser")

        Return DS
    End Function
    Public Function GetUserbyCreatedBy(ByVal UserCreatedBy As String) As DataSet
        Dim DS As DataSet = FetchDataSet2(UserCreatedBy.Trim(), "@StaffName", "sp_getStandardUserbyCreatedBy")

        Return DS
    End Function

    Public Function GetStandardUser_legaa_review() As DataSet
        Dim DS As New DataSet
        Dim Query As String = "SELECT U.[UserID],A.AName,U.[UserType],U.[GroupID]" & _
                                " ,U.[Status],A.Acct_Expiry,U.[StaffCreated]" & _
                                "FROM [elawdb].[dbo].[Admin_Users] U, [elawdb].[dbo].Account A " & _
                                "where u.AccountID = a.AccountID and U.[UserType] = 'Legal_revi'"
        Try
            Dim conn As New SqlConnection(ConnectionString)

            Dim cmd As New SqlCommand()
            cmd.Connection = conn
            cmd.CommandText = Query
            cmd.CommandType = CommandType.Text

            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            Dim adapter As New SqlDataAdapter(cmd)

            adapter.Fill(DS)
            conn.Close()

        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally

        End Try




        Return DS
    End Function

    Public Function GetStandardSalesReport(ByVal productGroup As String) As DataSet
        Dim DS As DataSet = FetchDataSet2(productGroup, "@pgi", "sp_getStandardSalesReport")

        Return DS
    End Function

    Public Function GetStandardSalesReportAmountDue(ByVal productGroup As String) As DataSet
        Dim DS As DataSet = FetchDataSet2(productGroup, "@pgi", "sp_getStandardSalesReportAmountDue")

        Return DS
    End Function

    Public Function GetUnpaidInvoiceTotalAmount(ByVal productGroup As String) As DataSet
        Dim DS As DataSet = FetchDataSet2(productGroup, "@pgi", "sp_getUnpaidInvoiceTotalAmount")

        Return DS
    End Function

    Public Function GetPaidInvoiceTotalAmount(ByVal productGroup As String) As DataSet
        Dim DS As DataSet = FetchDataSet2(productGroup, "@pgi", "sp_getPaidInvoiceTotalAmount")

        Return DS
    End Function

    Public Function GetCancelledInvoiceTotalAmount(ByVal productGroup As String) As DataSet
        Dim DS As DataSet = FetchDataSet2(productGroup, "@pgi", "sp_getCancelledInvoiceTotalAmount")
        Return DS
    End Function

    Public Function GetStandardInvoiceByType(ByVal procedureName As String, ByVal parameterName As String, ByVal criteria As String) As DataSet
        Dim DS As DataSet = FetchDataSet2(criteria, parameterName, procedureName)

        Return DS
    End Function

    Public Function TwoParametersOneType(ByVal procedureName As String, ByVal parameterName As String, ByVal criteria As String, ByVal parameterName2 As String, ByVal criteria2 As String, ByVal type As String) As DataSet
        Dim DS As DataSet = FetchDataSet4(criteria, parameterName, criteria2, parameterName2, procedureName, type)

        Return DS
    End Function
    Public Function Order3ParametersOneType(ByVal procedureName As String, ByVal parameterName As String, ByVal criteria As String, ByVal parameterName2 As String, ByVal criteria2 As String, ByVal type As String, ByVal productGroup As String) As DataSet
        Dim DS As DataSet = FetchDataSet5(criteria, parameterName, criteria2, parameterName2, procedureName, type, productGroup)

        Return DS
    End Function
    Public Function ThreeParametersOneTypebyDate(ByVal procedureName As String, ByVal parameterName As Date, ByVal parameterName2 As Date, ByVal type As String) As DataSet
        Dim DS1 As New DataSet

        Try
            Dim conn As New SqlConnection(ConnectionString)

            Dim cmd As New SqlCommand()
            cmd.Connection = conn
            cmd.CommandText = procedureName
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.Add("@date1", SqlDbType.Date).Value = parameterName
            cmd.Parameters.Add("@date2", SqlDbType.Date).Value = parameterName2
            cmd.Parameters.Add("@acctype", SqlDbType.VarChar, 10).Value = type
            conn.Open()
            cmd.ExecuteNonQuery() '.ExecuteReader() 
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DS1)
            conn.Close()
        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally

        End Try

        Return DS1
    End Function
    Public Function ThreeParametersOneTypebymy(ByVal procedureName As String, ByVal parameterName As Integer, ByVal parameterName2 As Integer, ByVal type As String) As DataSet
        Dim DS1 As New DataSet
      
        Try
            Dim conn As New SqlConnection(ConnectionString)

            Dim cmd As New SqlCommand()
            cmd.Connection = conn
            cmd.CommandText = procedureName
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.Add("@month", SqlDbType.Int).Value = parameterName
            cmd.Parameters.Add("@year", SqlDbType.Int).Value = parameterName2
            cmd.Parameters.Add("@acctype", SqlDbType.VarChar, 10).Value = type
            conn.Open()
            cmd.ExecuteNonQuery() '.ExecuteReader() 
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DS1)
            conn.Close()
        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally

        End Try

        Return DS1
    End Function
    Public Function ThreeParametersOneType(ByVal procedureName As String, ByVal parameterName As String, ByVal criteria As String, ByVal parameterName2 As String, ByVal criteria2 As String, ByVal type As String, ByVal productGroup As String) As DataSet
        ' Dim DS As DataSet = FetchDataSet5(criteria, parameterName, criteria2, parameterName2, procedureName, type, productGroup)
        Dim DS As New DataSet

        Dim conn As New SqlConnection(ConnectionString)
        Dim Query As String = "select pm.Status, i.InvoiceNo, pa.ReceiptNo, p.PName, c.CustomerName, pa.AmountPaid, pa.PDate, pa.CreatedStaff from Invoice i "
        Query &= " inner join Admin_InvoiceProduct ip ON ip.InvoiceNo = i.InvoiceNo"
        Query &= " inner join Admin_Product p on p.ProductID = ip.ProductNo "
        Query &= " inner join Customer c on c.CustomerID = i.CustomerID "
        Query &= " inner join Admin_PaymentMaster pm on pm.InvoiceNo = i.InvoiceNo "
        Query &= " inner join Admin_Payment pa on pa.CusPayNo = pm.CusPayNo "
        Query &= " where pm.Status = 'Paid' and p.ProductGroupID=@pgi"
        Query &= " order by  " & criteria & "  " & criteria2 & ""
        Dim cmd As New SqlCommand(Query, conn)
        Try
            cmd.Parameters.Add("@pgi", SqlDbType.VarChar, 10).Value = productGroup
            conn.Open()
            cmd.ExecuteNonQuery()
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DS)

        Catch err As Exception
            Throw New ApplicationException("Error in connecting to DB " & err.Message)
        Finally
            conn.Close()
            Query = ""
            cmd = Nothing
        End Try

        Return DS
    End Function
    Public Function SortInvoiceReport(ByVal criteria As String, ByVal order As String, ByVal ProductGroup As String, ByVal inStatus As String, ByVal inStatus1 As String) As DataSet
        Dim _criteria As String = criteria
        Dim _order As String = order
        Dim InvoiceStatus As String
        InvoiceStatus = "pm.Status = '" & inStatus & "'"
        Dim invoiceStatus1 As String
        If inStatus1 <> "" Then
        invoiceStatus1 = " and i.Status <>'" & inStatus1 & "'"
        Else
            invoiceStatus1 = " "
        End If

        Dim DS As New DataSet
        Dim Query As String = "select i.InvoiceNo, p.PName, c.CustomerName, i.TotalAmount, i.IDate, i.CreatedStaff from Invoice i "
        Query &= " inner join Admin_InvoiceProduct ip ON ip.InvoiceNo = i.InvoiceNo "
        Query &= " inner join Admin_Product p on p.ProductID = ip.ProductNo "
        Query &= " inner join Customer c on c.CustomerID = i.CustomerID "
        Query &= " inner join Admin_PaymentMaster pm on pm.InvoiceNo = i.InvoiceNo "
        Query &= " inner join Admin_Payment pa on pa.CusPayNo = pm.CusPayNo "
        Query &= " where " & InvoiceStatus & " " & invoiceStatus1 & " and p.ProductGroupID='" & ProductGroup & "' "
        Query &= " order by " & criteria & " " & order & ""
        Try
            Dim conn As New SqlConnection(ConnectionString)

            Dim cmd As New SqlCommand()
            'cmd.Parameters.AddWithValue("@criteria", criteria)
            'cmd.Parameters.AddWithValue("@order", order)
            cmd.Connection = conn
            cmd.CommandText = Query
            cmd.CommandType = CommandType.Text

            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            Dim adapter As New SqlDataAdapter(cmd)

            adapter.Fill(DS)
            conn.Close()

        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally

        End Try




        Return DS
    End Function
    Public Function TwoParametersOneType_elaw(ByVal criteria As String, ByVal order As String) As DataSet
        Dim _criteria As String = criteria
        Dim _order As String = order

        Dim DS As New DataSet
        Dim Query As String = "SELECT U.[UserID],A.AName,U.[UserType],U.[GroupID]" & _
                                " ,U.[Status],A.Acct_Expiry,U.[StaffCreated]" & _
                                "FROM [elawdb].[dbo].[Admin_Users] U, [elawdb].[dbo].Account A " & _
                                "where u.AccountID = a.AccountID and U.[UserType] <> 'Legal_revi' Order By " & _criteria & " " & _order
        Try
            Dim conn As New SqlConnection(ConnectionString)

            Dim cmd As New SqlCommand()
            'cmd.Parameters.AddWithValue("@criteria", criteria)
            'cmd.Parameters.AddWithValue("@order", order)
            cmd.Connection = conn
            cmd.CommandText = Query
            cmd.CommandType = CommandType.Text

            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            Dim adapter As New SqlDataAdapter(cmd)

            adapter.Fill(DS)
            conn.Close()

        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally

        End Try




        Return DS
    End Function
    Public Function OneParametersListInactiveUser_elaw() As DataSet

        Dim DS As New DataSet
        Dim Query As String = "SELECT U.[UserID],A.AName,U.[UserType],U.[GroupID]" & _
                                " ,U.[Status],A.Acct_Expiry,U.[StaffCreated]" & _
                                "FROM [elawdb].[dbo].[Admin_Users] U, [elawdb].[dbo].Account A " & _
                                "where u.AccountID = a.AccountID and( U.[UserType] <> 'Legal_revi'  and u.Status='inactive') order by u.UserID desc"
        Try
            Dim conn As New SqlConnection(ConnectionString)
            Dim cmd As New SqlCommand()
            cmd.Connection = conn
            cmd.CommandText = Query
            cmd.CommandType = CommandType.Text

            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            Dim adapter As New SqlDataAdapter(cmd)

            adapter.Fill(DS)
            conn.Close()

        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally

        End Try




        Return DS
    End Function
    Public Function TwoParametersOneType_legalreivew(ByVal criteria As String, ByVal order As String) As DataSet
        Dim _criteria As String = criteria
        Dim _order As String = order

        Dim DS As New DataSet
        Dim Query As String = "SELECT U.[UserID],A.AName,U.[UserType],U.[GroupID]" & _
                                " ,U.[Status],A.Acct_Expiry,U.[StaffCreated]" & _
                                "FROM [elawdb].[dbo].[Admin_Users] U, [elawdb].[dbo].Account A " & _
                                "where u.AccountID = a.AccountID and U.[UserType] = 'Legal_revi' Order By " & _criteria & " " & _order
        Try
            Dim conn As New SqlConnection(ConnectionString)

            Dim cmd As New SqlCommand()
            'cmd.Parameters.AddWithValue("@criteria", criteria)
            'cmd.Parameters.AddWithValue("@order", order)
            cmd.Connection = conn
            cmd.CommandText = Query
            cmd.CommandType = CommandType.Text

            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            Dim adapter As New SqlDataAdapter(cmd)

            adapter.Fill(DS)
            conn.Close()

        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally

        End Try




        Return DS
    End Function


    'Public Function InsertFreeUser(ByVal customerName As String, ByVal address As String, ByVal address2 As String, ByVal city As String, ByVal state As String, ByVal postalcode As String, ByVal country As String, ByVal phone_num As String, ByVal fax_num As String, ByVal status As String, ByVal first_name As String, ByVal last_name As String, ByVal position As String, ByVal tel_num As String, ByVal email As String, ByVal account As String, ByVal asize As String, ByVal account_type As String, ByVal user_name As String, ByVal password As String, ByVal customerID As String, ByVal CPID As String, ByVal accountID As String, ByVal userID As String, ByVal AccountExpiry As Date, ByVal adminName As String, ByVal comments As String, ByVal sitename As String) As Boolean
    '    Dim InsertRecord As Boolean
    '    Dim conn As New SqlConnection(ConnectionString)

    '    Dim cmd As New SqlCommand()
    '    Try

    '        cmd.Connection = conn
    '        cmd.CommandText = "sp_insertFreeUser"
    '        cmd.CommandType = CommandType.StoredProcedure
    '        cmd.Parameters.Add("@customerName", SqlDbType.VarChar, 35).Value = customerName
    '        cmd.Parameters.Add("@address1", SqlDbType.VarChar, 35).Value = address
    '        cmd.Parameters.Add("@address2", SqlDbType.VarChar, 35).Value = address2
    '        cmd.Parameters.Add("@city", SqlDbType.VarChar, 35).Value = city
    '        cmd.Parameters.Add("@state", SqlDbType.VarChar, 35).Value = state
    '        cmd.Parameters.Add("@postalcode", SqlDbType.VarChar, 35).Value = postalcode
    '        cmd.Parameters.Add("@country", SqlDbType.VarChar, 35).Value = country
    '        cmd.Parameters.Add("@phonenum", SqlDbType.VarChar, 18).Value = phone_num
    '        cmd.Parameters.Add("@faxnum", SqlDbType.VarChar, 18).Value = fax_num
    '        cmd.Parameters.Add("@status", SqlDbType.VarChar, 10).Value = status
    '        cmd.Parameters.Add("@firstname", SqlDbType.VarChar, 35).Value = first_name
    '        cmd.Parameters.Add("@lastname", SqlDbType.VarChar, 35).Value = last_name
    '        cmd.Parameters.Add("@position", SqlDbType.VarChar, 35).Value = position
    '        cmd.Parameters.Add("@telnum", SqlDbType.VarChar, 18).Value = tel_num
    '        cmd.Parameters.Add("@email", SqlDbType.VarChar, 35).Value = email
    '        cmd.Parameters.Add("@account", SqlDbType.VarChar, 25).Value = account
    '        cmd.Parameters.Add("@asize", SqlDbType.VarChar, 25).Value = asize
    '        cmd.Parameters.Add("@accttype", SqlDbType.VarChar, 10).Value = account_type
    '        cmd.Parameters.Add("@username", SqlDbType.VarChar, 20).Value = user_name
    '        cmd.Parameters.Add("@password", SqlDbType.VarChar, 15).Value = password
    '        cmd.Parameters.Add("@customerID", SqlDbType.VarChar, 10).Value = customerID
    '        cmd.Parameters.Add("@CPID", SqlDbType.VarChar, 10).Value = CPID
    '        cmd.Parameters.Add("@accountID", SqlDbType.VarChar, 10).Value = accountID
    '        cmd.Parameters.Add("@userID", SqlDbType.VarChar, 10).Value = userID
    '        cmd.Parameters.Add("@expiry_date", SqlDbType.DateTime).Value = AccountExpiry
    '        cmd.Parameters.Add("@admin", SqlDbType.VarChar, 10).Value = adminName
    '        cmd.Parameters.Add("@comments", SqlDbType.VarChar, 50).Value = comments
    '        cmd.Parameters.Add("@SiteName", SqlDbType.VarChar, 50).Value = sitename
    '        conn.Open()

    '        cmd.ExecuteNonQuery() '.ExecuteReader() 

    '        conn.Close()
    '        InsertRecord = True
    '    Catch err As DataException
    '        Throw New ApplicationException("Error in inserting to DB  " & err.Message)
    '        InsertRecord = False
    '    Finally
    '        conn.Close()
    '        cmd.Dispose()
    '    End Try

    '    Return InsertRecord
    'End Function

    'Public Function InsertFreeUser(ByVal customerName As String, ByVal address As String, ByVal address2 As String, ByVal city As String, ByVal state As String, ByVal postalcode As String, ByVal country As String, ByVal phone_num As String, ByVal fax_num As String, ByVal status As String, ByVal first_name As String, ByVal last_name As String, ByVal position As String, ByVal tel_num As String, ByVal email As String, ByVal account As String, ByVal asize As String, ByVal account_type As String, ByVal user_name As String, ByVal password As String, ByVal customerID As String, ByVal CPID As String, ByVal accountID As String, ByVal userID As String, ByVal AccountExpiry As Date, ByVal adminName As String, ByVal comments As String, ByVal sitename As String) As Boolean
    '    Dim InsertRecord As Boolean
    '    Dim conn As New SqlConnection(ConnectionString)

    '    Dim cmd As New SqlCommand()
    '    Try

    '        cmd.Connection = conn
    '        cmd.CommandText = "sp_insertFreeUser"
    '        cmd.CommandType = CommandType.StoredProcedure
    '        cmd.Parameters.Add("@customerName", SqlDbType.VarChar, 35).Value = customerName
    '        cmd.Parameters.Add("@FirmName", SqlDbType.VarChar, 35).Value = customerName
    '        cmd.Parameters.Add("@address1", SqlDbType.VarChar, 35).Value = address
    '        cmd.Parameters.Add("@address2", SqlDbType.VarChar, 35).Value = address2
    '        cmd.Parameters.Add("@city", SqlDbType.VarChar, 35).Value = city
    '        cmd.Parameters.Add("@state", SqlDbType.VarChar, 35).Value = state
    '        cmd.Parameters.Add("@postalcode", SqlDbType.VarChar, 35).Value = postalcode
    '        cmd.Parameters.Add("@country", SqlDbType.VarChar, 35).Value = country
    '        cmd.Parameters.Add("@phonenum", SqlDbType.VarChar, 18).Value = phone_num
    '        cmd.Parameters.Add("@faxnum", SqlDbType.VarChar, 18).Value = fax_num
    '        cmd.Parameters.Add("@status", SqlDbType.VarChar, 10).Value = status
    '        cmd.Parameters.Add("@firstname", SqlDbType.VarChar, 35).Value = first_name
    '        cmd.Parameters.Add("@lastname", SqlDbType.VarChar, 35).Value = last_name
    '        cmd.Parameters.Add("@position", SqlDbType.VarChar, 35).Value = position
    '        cmd.Parameters.Add("@telnum", SqlDbType.VarChar, 18).Value = tel_num
    '        cmd.Parameters.Add("@email", SqlDbType.VarChar, 35).Value = email
    '        cmd.Parameters.Add("@account", SqlDbType.VarChar, 25).Value = account
    '        cmd.Parameters.Add("@asize", SqlDbType.VarChar, 25).Value = asize
    '        cmd.Parameters.Add("@accttype", SqlDbType.VarChar, 10).Value = account_type
    '        cmd.Parameters.Add("@username", SqlDbType.VarChar, 20).Value = user_name
    '        cmd.Parameters.Add("@password", SqlDbType.VarChar, 15).Value = password
    '        cmd.Parameters.Add("@customerID", SqlDbType.VarChar, 10).Value = customerID
    '        cmd.Parameters.Add("@CPID", SqlDbType.VarChar, 10).Value = CPID
    '        cmd.Parameters.Add("@accountID", SqlDbType.VarChar, 10).Value = accountID
    '        cmd.Parameters.Add("@userID", SqlDbType.VarChar, 10).Value = userID
    '        cmd.Parameters.Add("@expiry_date", SqlDbType.DateTime).Value = AccountExpiry
    '        cmd.Parameters.Add("@admin", SqlDbType.VarChar, 10).Value = adminName
    '        cmd.Parameters.Add("@comments", SqlDbType.VarChar, 50).Value = comments
    '        cmd.Parameters.Add("@SiteName", SqlDbType.VarChar, 50).Value = sitename
    '        conn.Open()

    '        cmd.ExecuteNonQuery() '.ExecuteReader() 

    '        conn.Close()
    '        InsertRecord = True
    '    Catch err As DataException
    '        Throw New ApplicationException("Error in inserting to DB  " & err.Message)
    '        InsertRecord = False
    '    Finally
    '        conn.Close()
    '        cmd.Dispose()
    '    End Try

    '    Return InsertRecord
    'End Function


    Public Function InsertFreeUser(ByVal customerName As String, ByVal address As String, ByVal address2 As String, ByVal city As String, ByVal state As String, ByVal postalcode As String, ByVal country As String, ByVal phone_num As String, ByVal fax_num As String, ByVal status As String, ByVal first_name As String, ByVal last_name As String, ByVal position As String, ByVal tel_num As String, ByVal email As String, ByVal account As String, ByVal asize As String, ByVal account_type As String, ByVal user_name As String, ByVal password As String, ByVal customerID As String, ByVal CPID As String, ByVal accountID As String, ByVal userID As String, ByVal AccountExpiry As Date, ByVal adminName As String, ByVal comments As String, ByVal sitename As String, ByVal s_Module As String) As Boolean
        Dim InsertRecord As Boolean
        Dim conn As New SqlConnection(ConnectionString)

        Dim cmd As New SqlCommand()
        Try

            cmd.Connection = conn
            cmd.CommandText = "sp_insertFreeUser"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.Add("@customerName", SqlDbType.VarChar, 35).Value = customerName
            cmd.Parameters.Add("@FirmName", SqlDbType.VarChar, 35).Value = customerName
            cmd.Parameters.Add("@address1", SqlDbType.VarChar, 35).Value = address
            cmd.Parameters.Add("@address2", SqlDbType.VarChar, 35).Value = address2
            cmd.Parameters.Add("@city", SqlDbType.VarChar, 35).Value = city
            cmd.Parameters.Add("@state", SqlDbType.VarChar, 35).Value = state
            cmd.Parameters.Add("@postalcode", SqlDbType.VarChar, 35).Value = postalcode
            cmd.Parameters.Add("@country", SqlDbType.VarChar, 35).Value = country
            cmd.Parameters.Add("@phonenum", SqlDbType.VarChar, 18).Value = phone_num
            cmd.Parameters.Add("@faxnum", SqlDbType.VarChar, 18).Value = fax_num
            cmd.Parameters.Add("@status", SqlDbType.VarChar, 10).Value = status
            cmd.Parameters.Add("@firstname", SqlDbType.VarChar, 35).Value = first_name
            cmd.Parameters.Add("@lastname", SqlDbType.VarChar, 35).Value = last_name
            cmd.Parameters.Add("@position", SqlDbType.VarChar, 35).Value = position
            cmd.Parameters.Add("@telnum", SqlDbType.VarChar, 18).Value = tel_num
            cmd.Parameters.Add("@email", SqlDbType.VarChar, 35).Value = email
            cmd.Parameters.Add("@account", SqlDbType.VarChar, 25).Value = account
            cmd.Parameters.Add("@asize", SqlDbType.VarChar, 25).Value = asize
            cmd.Parameters.Add("@accttype", SqlDbType.VarChar, 10).Value = account_type
            cmd.Parameters.Add("@username", SqlDbType.VarChar, 20).Value = user_name
            cmd.Parameters.Add("@password", SqlDbType.VarChar, 15).Value = password
            cmd.Parameters.Add("@customerID", SqlDbType.VarChar, 10).Value = customerID
            cmd.Parameters.Add("@CPID", SqlDbType.VarChar, 10).Value = CPID
            cmd.Parameters.Add("@accountID", SqlDbType.VarChar, 10).Value = accountID
            cmd.Parameters.Add("@userID", SqlDbType.VarChar, 10).Value = userID
            cmd.Parameters.Add("@expiry_date", SqlDbType.DateTime).Value = AccountExpiry
            cmd.Parameters.Add("@admin", SqlDbType.VarChar, 10).Value = adminName
            cmd.Parameters.Add("@comments", SqlDbType.VarChar, 50).Value = comments
            cmd.Parameters.Add("@SiteName", SqlDbType.VarChar, 50).Value = sitename
            cmd.Parameters.Add("@Module", SqlDbType.VarChar, 50).Value = s_Module


            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            conn.Close()
            InsertRecord = True
        Catch err As DataException
            Throw New ApplicationException("Error in inserting to DB  " & err.Message)
            InsertRecord = False
        Finally
            conn.Close()
            cmd.Dispose()
        End Try

        Return InsertRecord
    End Function



    Public Function InsertGroupUser(ByVal userID As String, ByVal accountID As String, ByVal userName As String, ByVal password As String, ByVal groupID As String, ByVal adminName As String) As Boolean
        Dim InsertRecord As Boolean
        Dim conn As New SqlConnection(ConnectionString)

        Dim cmd As New SqlCommand()
        Try

            cmd.Connection = conn
            cmd.CommandText = "sp_addBasicGroupUserDetails"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.Add("@userid", SqlDbType.VarChar, 10).Value = userID
            cmd.Parameters.Add("@accountID", SqlDbType.VarChar, 10).Value = accountID
            cmd.Parameters.Add("@username", SqlDbType.VarChar, 20).Value = userName
            cmd.Parameters.Add("@password", SqlDbType.VarChar, 15).Value = password
            cmd.Parameters.Add("@groupid", SqlDbType.VarChar, 10).Value = groupID
            cmd.Parameters.Add("@admin", SqlDbType.VarChar, 10).Value = adminName
            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            conn.Close()
            InsertRecord = True
        Catch err As DataException
            Throw New ApplicationException("Error in inserting to DB  " & err.Message)
            InsertRecord = False
        Finally
            conn.Close()
            cmd.Dispose()
        End Try

        Return InsertRecord
    End Function

    Public Function InsertGroupUserDetails(ByVal customerName As String, ByVal address As String, ByVal address2 As String, ByVal city As String, ByVal state As String, ByVal postalcode As String, ByVal country As String, ByVal phone_num As String, ByVal fax_num As String, ByVal status As String, ByVal first_name As String, ByVal last_name As String, ByVal position As String, ByVal tel_num As String, ByVal email As String, ByVal account As String, ByVal asize As String, ByVal account_type As String, ByVal customerID As String, ByVal CPID As String, ByVal accountID As String, ByVal AccountExpiry As Date, ByVal adminName As String, ByVal comments As String, ByVal NoOfUser As Integer) As Boolean
        Dim InsertRecord As Boolean
        Dim conn As New SqlConnection(ConnectionString)

        Dim cmd As New SqlCommand()
        Try

            cmd.Connection = conn
            cmd.CommandText = "sp_addAdvancedDetailsOfGroupUser"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.Add("@customerName", SqlDbType.VarChar, 35).Value = customerName
            cmd.Parameters.Add("@address1", SqlDbType.VarChar, 35).Value = address
            cmd.Parameters.Add("@address2", SqlDbType.VarChar, 35).Value = address2
            cmd.Parameters.Add("@city", SqlDbType.VarChar, 35).Value = city
            cmd.Parameters.Add("@state", SqlDbType.VarChar, 35).Value = state
            cmd.Parameters.Add("@postalcode", SqlDbType.VarChar, 35).Value = postalcode
            cmd.Parameters.Add("@country", SqlDbType.VarChar, 35).Value = country
            cmd.Parameters.Add("@phonenum", SqlDbType.VarChar, 18).Value = phone_num
            cmd.Parameters.Add("@faxnum", SqlDbType.VarChar, 18).Value = fax_num
            cmd.Parameters.Add("@status", SqlDbType.VarChar, 10).Value = status
            cmd.Parameters.Add("@firstname", SqlDbType.VarChar, 35).Value = first_name
            cmd.Parameters.Add("@lastname", SqlDbType.VarChar, 35).Value = last_name
            cmd.Parameters.Add("@position", SqlDbType.VarChar, 35).Value = position
            cmd.Parameters.Add("@telnum", SqlDbType.VarChar, 18).Value = tel_num
            cmd.Parameters.Add("@email", SqlDbType.VarChar, 35).Value = email
            cmd.Parameters.Add("@account", SqlDbType.VarChar, 25).Value = account
            cmd.Parameters.Add("@asize", SqlDbType.VarChar, 25).Value = asize
            cmd.Parameters.Add("@accttype", SqlDbType.VarChar, 10).Value = account_type
            cmd.Parameters.Add("@customerID", SqlDbType.VarChar, 10).Value = customerID
            cmd.Parameters.Add("@CPID", SqlDbType.VarChar, 10).Value = CPID
            cmd.Parameters.Add("@accountID", SqlDbType.VarChar, 10).Value = accountID
            cmd.Parameters.Add("@expiry_date", SqlDbType.DateTime).Value = AccountExpiry
            cmd.Parameters.Add("@admin", SqlDbType.VarChar, 10).Value = adminName
            cmd.Parameters.Add("@comments", SqlDbType.VarChar, 50).Value = comments
            cmd.Parameters.Add("@NoOfUser", SqlDbType.Int).Value = NoOfUser
            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            conn.Close()
            InsertRecord = True
        Catch err As DataException
            Throw New ApplicationException("Error in inserting to DB  " & err.Message)
            InsertRecord = False
        Finally
            conn.Close()
            cmd.Dispose()
        End Try

        Return InsertRecord
    End Function

    Public Function InsertGroup(ByVal GroupID As String, ByVal AccountID As String, ByVal GroupName As String, ByVal eMail As String, ByVal numberOfUsers As Integer, ByVal status As String, ByVal adminName As String, ByVal comments As String) As Boolean
        Dim InsertRecord As Boolean
        Dim conn As New SqlConnection(ConnectionString)

        Dim cmd As New SqlCommand()
        Try

            cmd.Connection = conn
            cmd.CommandText = "sp_AddNewGroup"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.Add("@GroupID", SqlDbType.VarChar, 10).Value = GroupID
            cmd.Parameters.Add("@accountID", SqlDbType.VarChar, 10).Value = AccountID
            cmd.Parameters.Add("@gname", SqlDbType.VarChar, 100).Value = GroupName
            cmd.Parameters.Add("@emailid", SqlDbType.VarChar, 100).Value = eMail
            cmd.Parameters.Add("@no_of_users", SqlDbType.Int).Value = numberOfUsers
            cmd.Parameters.Add("@status", SqlDbType.VarChar, 10).Value = status
            cmd.Parameters.Add("@admin", SqlDbType.VarChar, 10).Value = adminName
            cmd.Parameters.Add("@comments", SqlDbType.VarChar, 50).Value = comments
            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            conn.Close()
            InsertRecord = True
        Catch err As DataException
            Throw New ApplicationException("Error in inserting to DB  " & err.Message)
            InsertRecord = False
        Finally
            conn.Close()
            cmd.Dispose()
        End Try

        Return InsertRecord
    End Function

    Public Function InsertNewInvoice(ByVal customerID As String, ByVal Factor As Decimal, ByVal totalAmount As Decimal, ByVal status As String, ByVal product_num As String, ByVal quantity As Integer, ByVal PayType As String, ByVal PayStatus As String, ByVal PaymentMode As String, ByVal expiryDate As String, ByVal CPID As String, ByVal adminName As String, ByVal reason_dis As String, ByVal AllIds As String, ByVal AllIdsQuanatity As String, ByVal discountAmount As String) As Boolean
        Dim InsertRecord As Boolean
        Dim conn As New SqlConnection(ConnectionString)

        Dim cmd As New SqlCommand()
        Try

            cmd.Connection = conn
            cmd.CommandText = "sp_InsertNewInvoice"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.Add("@customerID", SqlDbType.VarChar, 10).Value = customerID
            Dim spm As SqlParameter = cmd.Parameters.Add("@dfactor", SqlDbType.Float)
            spm.Value = Factor
            'spm.Precision = 8
            'spm.Scale = 8
            cmd.Parameters.Add("@price", SqlDbType.Money).Value = totalAmount
            cmd.Parameters.Add("@status", SqlDbType.VarChar, 10).Value = status
            cmd.Parameters.Add("@productno", SqlDbType.VarChar, 10).Value = product_num
            cmd.Parameters.Add("@quantity", SqlDbType.Int).Value = quantity
            cmd.Parameters.Add("@paytype", SqlDbType.VarChar, 10).Value = PayType
            cmd.Parameters.Add("@paystatus", SqlDbType.VarChar, 10).Value = PayStatus
            cmd.Parameters.Add("@paymentmode", SqlDbType.VarChar, 11).Value = PaymentMode
            cmd.Parameters.Add("@ccexpirydate", SqlDbType.Date).Value = expiryDate
            cmd.Parameters.Add("@CPID", SqlDbType.VarChar, 10).Value = CPID
            cmd.Parameters.Add("@admin", SqlDbType.VarChar, 10).Value = adminName
            cmd.Parameters.Add("@reason_dis", SqlDbType.VarChar, 100).Value = reason_dis
            cmd.Parameters.Add("@allIds", SqlDbType.VarChar, 100).Value = AllIds
            cmd.Parameters.Add("@allIdsQ", SqlDbType.VarChar, 100).Value = AllIdsQuanatity
            cmd.Parameters.Add("@DiscountAmount", SqlDbType.Money, 100).Value = Convert.ToDecimal(discountAmount)

            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            conn.Close()
            InsertRecord = True
        Catch err As DataException
            Throw New ApplicationException("Error in inserting to DB  " & err.Message)
            InsertRecord = False
        Finally
            conn.Close()
            cmd.Dispose()
        End Try

        Return InsertRecord
    End Function

    Public Function InsertNewProduct(ByVal pGroupID As String, ByVal product As String, ByVal price As Decimal, ByVal status As String, ByVal comments As String, ByVal adminName As String, ByVal productCode As String, ByVal expiryDate As Date) As Boolean
        Dim InsertRecord As Boolean
        Dim conn As New SqlConnection(ConnectionString)

        Dim cmd As New SqlCommand()
        Try

            cmd.Connection = conn
            cmd.CommandText = "sp_InsertNewProduct"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.Add("@pgroupid", SqlDbType.VarChar, 10).Value = pGroupID
            cmd.Parameters.Add("@product", SqlDbType.VarChar, 100).Value = product
            cmd.Parameters.Add("@price", SqlDbType.Money).Value = price
            cmd.Parameters.Add("@status", SqlDbType.VarChar, 10).Value = status

            cmd.Parameters.Add("@comments", SqlDbType.VarChar, 50).Value = comments
            cmd.Parameters.Add("@staff", SqlDbType.VarChar, 10).Value = adminName
            cmd.Parameters.Add("@pcode", SqlDbType.VarChar, 10).Value = productCode
            cmd.Parameters.Add("@ped", SqlDbType.Date).Value = expiryDate

            'cmd.Parameters.Add("@cpid", SqlDbType.VarChar, 10).Value = CPID
            'cmd.Parameters.Add("@customerid", SqlDbType.VarChar, 10).Value = customerID
            'cmd.Parameters.Add("@invoiceno", SqlDbType.VarChar, 10).Value = invoiceNo
            'Dim spm As SqlParameter = cmd.Parameters.Add("@discount", SqlDbType.Decimal)
            'spm.Value = Discount
            'spm.Precision = 4
            'spm.Scale = 2
            'cmd.Parameters.Add("@quantity", SqlDbType.Int).Value = quantity
            'cmd.Parameters.Add("@cuspayno", SqlDbType.VarChar, 10).Value = cusPayNo
            'cmd.Parameters.Add("@paytype", SqlDbType.VarChar, 10).Value = payType
            'cmd.Parameters.Add("@receiptno", SqlDbType.VarChar, 10).Value = receiptNo
            'cmd.Parameters.Add("@paymode", SqlDbType.VarChar, 11).Value = payMode

            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            conn.Close()
            InsertRecord = True
        Catch err As DataException
            Throw New ApplicationException("Error in inserting to DB  " & err.Message)
            InsertRecord = False
        Finally
            conn.Close()
            cmd.Dispose()
        End Try

        Return InsertRecord
    End Function

    Public Overloads Function AddRecord(ByVal UserID As Long, ByVal Username As String) As Boolean
        'Dim Query As String = "insert into tblUserPrimary "
        AddRecord = False
        Dim Query As String
        Dim pwd As String = "test"
        Query = "insert into  tblUserPrimary (UserNameID,UserName,Password) values ( " & UserID & " , '" & Username & "','" & pwd & "' )"
        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand
        Try
            cmd.Connection = conn
            cmd.CommandType = CommandType.Text
            cmd.CommandText = Query
            conn.Open()
            cmd.ExecuteNonQuery()
            conn.Close()
            AddRecord = True
        Catch err As Exception
            Throw New Exception("Error in inserting to DB  " & err.Message)
            AddRecord = False

        Finally
            conn.Close()
            cmd.Dispose()
        End Try
        Return AddRecord

    End Function

    Public Overloads Function AddRecord(ByVal Query As String) As Boolean
        'Dim Query As String = "insert into tblUserPrimary "
        AddRecord = False
        Dim Statement As String
        Statement = Query
        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand
        Try
            cmd.Connection = conn
            cmd.CommandType = CommandType.Text
            cmd.CommandText = Query
            conn.Open()
            cmd.ExecuteNonQuery()

            AddRecord = True
        Catch err As Exception
            AddRecord = False
            Throw New Exception("Error in inserting to DB  " & err.Message)


        Finally
            conn.Close()
            cmd = Nothing
        End Try
        Return AddRecord

    End Function

    Public Function InsertCusCPProduct(ByVal CPID As String, ByVal productNum As Integer, ByVal customerID As String, ByVal adminName As String) As Boolean
        Dim InsertRecord As Boolean
        Dim conn As New SqlConnection(ConnectionString)

        Dim Query As String = "insert into admin_CustomerCP_Product values(@CPID,@productno,@customerID,'Active','',@admin)"
        Dim cmd As New SqlCommand(Query, conn)
        Try


            cmd.Parameters.Add("@CPID", SqlDbType.VarChar, 10).Value = CPID
            cmd.Parameters.Add("@productno", SqlDbType.Int).Value = productNum
            cmd.Parameters.Add("@customerID", SqlDbType.VarChar, 10).Value = customerID

            cmd.Parameters.Add("@admin", SqlDbType.VarChar, 10).Value = adminName

            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            conn.Close()
            InsertRecord = True
        Catch err As DataException
            Throw New ApplicationException("Error in inserting to DB  " & err.Message)
            InsertRecord = False
        Finally
            conn.Close()
            cmd.Dispose()
        End Try

        Return InsertRecord
    End Function

    Public Function InsertStaff(ByVal customerID As String, ByVal staffName As String, ByVal jobTitle As String, ByVal emailAddress As String, ByVal phoneNum As String, ByVal FaxNum As String) As Boolean
        Dim InsertRecord As Boolean
        Dim conn As New SqlConnection(ConnectionString)

        Dim Query As String = "insert into myseminars_Participants(CustomerID,StaffName,JobTitle,Email,Telno,Faxno) values(@cid,@name,@title,@email,@tel,@fax)"
        Dim cmd As New SqlCommand(Query, conn)
        Try

            cmd.Parameters.Add("@cid", SqlDbType.VarChar, 10).Value = customerID
            cmd.Parameters.Add("@name", SqlDbType.VarChar, 35).Value = staffName
            cmd.Parameters.Add("@title", SqlDbType.VarChar, 35).Value = jobTitle
            cmd.Parameters.Add("@email", SqlDbType.VarChar, 35).Value = emailAddress
            cmd.Parameters.Add("@tel", SqlDbType.VarChar, 18).Value = phoneNum
            cmd.Parameters.Add("@fax", SqlDbType.VarChar, 18).Value = FaxNum

            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            'conn.Close()
            InsertRecord = True
        Catch err As DataException
            Throw New ApplicationException("Error in inserting to DB  " & err.Message)
            InsertRecord = False
        Finally
            conn.Close()
            cmd.Dispose()
        End Try

        Return InsertRecord
    End Function

    Public Function InsertSpeaker(ByVal speakerName As String, ByVal emailAddress As String, ByVal phoneNum As String, ByVal address1 As String, ByVal address2 As String, ByVal city As String, ByVal postcode As String, ByVal state As String, ByVal country As String, ByVal remarks As String) As Boolean
        Dim InsertRecord As Boolean
        Dim conn As New SqlConnection(ConnectionString)

        Dim Query As String = "insert into myseminars_Speakers(Name, Email, Tel, [Address], Address2, City, PostCode, [State], Country, Remarks) values(@name,@email,@tel,@add,@add2,@city,@postcode,@state,@country,@remarks)"
        Dim cmd As New SqlCommand(Query, conn)
        Try


            cmd.Parameters.Add("@name", SqlDbType.VarChar, 35).Value = speakerName
            cmd.Parameters.Add("@email", SqlDbType.VarChar, 35).Value = emailAddress
            cmd.Parameters.Add("@tel", SqlDbType.VarChar, 18).Value = phoneNum

            cmd.Parameters.Add("@add", SqlDbType.VarChar, 35).Value = address1
            cmd.Parameters.Add("@add2", SqlDbType.VarChar, 35).Value = address2
            cmd.Parameters.Add("@city", SqlDbType.VarChar, 35).Value = city
            cmd.Parameters.Add("@postcode", SqlDbType.VarChar, 5).Value = postcode
            cmd.Parameters.Add("@state", SqlDbType.VarChar, 35).Value = state
            cmd.Parameters.Add("@country", SqlDbType.VarChar, 35).Value = country
            cmd.Parameters.Add("@remarks", SqlDbType.VarChar, 50).Value = remarks
            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            conn.Close()
            InsertRecord = True
        Catch err As DataException
            Throw New ApplicationException("Error in inserting to DB  " & err.Message)
            InsertRecord = False
        Finally
            conn.Close()
            cmd.Dispose()
        End Try

        Return InsertRecord
    End Function

    Public Function InsertEventSpeaker(ByVal eventID As Integer, ByVal speakerID As Integer) As Boolean
        Dim InsertRecord As Boolean
        Dim conn As New SqlConnection(ConnectionString)

        Dim Query As String = "insert into myseminars_EventSpeaker values(@event_id,@speaker_id)"
        Dim cmd As New SqlCommand(Query, conn)
        Try

            cmd.Parameters.Add("@event_id", SqlDbType.Int).Value = eventID
            cmd.Parameters.Add("@speaker_id", SqlDbType.Int).Value = speakerID


            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            conn.Close()
            InsertRecord = True
        Catch err As DataException
            Throw New ApplicationException("Error in inserting to DB  " & err.Message)
            InsertRecord = False
        Finally
            conn.Close()
            cmd.Dispose()
        End Try

        Return InsertRecord
    End Function

    Public Function InsertParticipant(ByVal eventID As Integer, ByVal staffID As Integer, ByVal Invoice_no As Integer) As Boolean
        Dim InsertRecord As Boolean
        Dim conn As New SqlConnection(ConnectionString)

        Dim Query As String = "insert into myseminars_PrintParticipant values(@event_id,@staff_id,@invoice_no)"
        Dim cmd As New SqlCommand(Query, conn)
        Try

            cmd.Parameters.Add("@event_id", SqlDbType.Int).Value = eventID
            cmd.Parameters.Add("@staff_id", SqlDbType.Int).Value = staffID
            cmd.Parameters.Add("@invoice_no", SqlDbType.Int).Value = Invoice_no



            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            conn.Close()
            InsertRecord = True
        Catch err As DataException
            Throw New ApplicationException("Error in inserting to DB  " & err.Message)
            InsertRecord = False
        Finally
            conn.Close()
            cmd.Dispose()
        End Try

        Return InsertRecord
    End Function

    Public Function UpdateMYSProduct(ByVal productDate As Date, ByVal eventType As String, ByVal eventDate As Date, ByVal eventTime As String, ByVal details As String, ByVal productID As Integer) As Boolean
        Dim UpdateRecord As Boolean
        Dim conn As New SqlConnection(ConnectionString)

        Dim Query As String = "update Admin_Product set PDate=@pdate, EventType=@type, EventDate = @edate, EventTime = @etime, EventDetails = @details where ProductID=@pid"
        Dim cmd As New SqlCommand(Query, conn)
        Try

            cmd.Parameters.Add("@pdate", SqlDbType.Date).Value = productDate
            cmd.Parameters.Add("@type", SqlDbType.VarChar, 10).Value = eventType
            cmd.Parameters.Add("@edate", SqlDbType.Date).Value = eventDate
            cmd.Parameters.Add("@etime", SqlDbType.VarChar, 20).Value = eventTime

            cmd.Parameters.Add("@details", SqlDbType.VarChar, 50).Value = details
            cmd.Parameters.Add("@pid", SqlDbType.Int).Value = productID


            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            conn.Close()
            UpdateRecord = True
        Catch err As DataException
            Throw New ApplicationException("Error in inserting to DB  " & err.Message)
            UpdateRecord = False
        Finally
            conn.Close()
            cmd.Dispose()
        End Try

        Return UpdateRecord
    End Function

    Public Function DeleteCusCP(ByVal CPID As String, ByVal productID As Integer, ByVal customerID As String) As Boolean
        Dim DeleteRecord As Boolean
        Dim conn As New SqlConnection(ConnectionString)

        Dim Query As String = "delete from admin_CustomerCP_Product where CPID=@cpid and ProductID=@pid and CustomerID=@cid"
        Dim cmd As New SqlCommand(Query, conn)
        Try

            cmd.Parameters.Add("@cpid", SqlDbType.VarChar, 10).Value = CPID
            cmd.Parameters.Add("@pid", SqlDbType.Int).Value = productID
            cmd.Parameters.Add("@cid", SqlDbType.VarChar, 10).Value = customerID
            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            conn.Close()
            DeleteRecord = True
        Catch err As DataException
            Throw New ApplicationException("Error in inserting to DB  " & err.Message)
            DeleteRecord = False
        Finally
            conn.Close()
            cmd.Dispose()
        End Try

        Return DeleteRecord
    End Function

    Public Function DeleteEventSpeaker(ByVal productID As Integer) As Boolean
        Dim DeleteRecord As Boolean
        Dim conn As New SqlConnection(ConnectionString)

        Dim Query As String = "delete from myseminars_EventSpeaker where Event_ID=@event_id"
        Dim cmd As New SqlCommand(Query, conn)
        Try

            cmd.Parameters.Add("@event_id", SqlDbType.Int).Value = productID


            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            conn.Close()
            DeleteRecord = True
        Catch err As DataException
            Throw New ApplicationException("Error in inserting to DB  " & err.Message)
            DeleteRecord = False
        Finally
            conn.Close()
            cmd.Dispose()
        End Try

        Return DeleteRecord
    End Function

    Public Function DeleteParticipant(ByVal speakerID As Integer, ByVal eventID As Integer) As Boolean
        Dim DeleteRecord As Boolean
        Dim conn As New SqlConnection(ConnectionString)

        Dim Query As String = "delete from myseminars_PrintParticipant where StaffID=@speaker_id and EventID=@eventid"
        Dim cmd As New SqlCommand(Query, conn)
        Try

            cmd.Parameters.Add("@speaker_id", SqlDbType.Int).Value = speakerID
            cmd.Parameters.Add("@eventid", SqlDbType.Int).Value = eventID

            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            conn.Close()
            DeleteRecord = True
        Catch err As DataException
            Throw New ApplicationException("Error in inserting to DB  " & err.Message)
            DeleteRecord = False
        Finally
            conn.Close()
            cmd.Dispose()
        End Try

        Return DeleteRecord
    End Function

    Public Function DeleteSpeaker(ByVal speakerID As Integer) As Boolean
        Dim DeleteRecord As Boolean
        Dim conn As New SqlConnection(ConnectionString)

        Dim Query As String = "delete from myseminars_Speakers where SpeakerID=@speaker_id"
        Dim cmd As New SqlCommand(Query, conn)
        Try

            cmd.Parameters.Add("@speaker_id", SqlDbType.Int).Value = speakerID


            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            conn.Close()
            DeleteRecord = True
        Catch err As DataException
            Throw New ApplicationException("Error in inserting to DB  " & err.Message)
            DeleteRecord = False
        Finally
            conn.Close()
            cmd.Dispose()
        End Try

        Return DeleteRecord
    End Function

    Public Function DeleteStaff(ByVal staffID As Integer) As Boolean
        Dim DeleteRecord As Boolean
        Dim conn As New SqlConnection(ConnectionString)

        Dim Query As String = "delete from myseminars_PrintParticipant where StaffID=@staff_id"
        Dim cmd As New SqlCommand(Query, conn)
        Try

            cmd.Parameters.Add("@staff_id", SqlDbType.Int).Value = staffID


            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            conn.Close()
            DeleteRecord = True
        Catch err As DataException
            Throw New ApplicationException("Error in inserting to DB  " & err.Message)
            DeleteRecord = False
        Finally
            conn.Close()
            cmd.Dispose()
        End Try

        Return DeleteRecord
    End Function

    Public Overloads Function UpdateRecord(ByVal UserID As Long, ByVal Username As String) As Boolean

        UpdateRecord = False
        Dim Query As String
        Dim pwd As String = "test"
        'Query = "insert into  tblUserPrimary (UserNameID,UserName,Password) values ( " & UserID & " , '" & Username & "','" & pwd & "' )"
        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand
        Try
            cmd.Connection = conn
            cmd.CommandType = CommandType.Text
            cmd.CommandText = Query
            conn.Open()
            cmd.ExecuteNonQuery()
            conn.Close()
            UpdateRecord = True
        Catch err As Exception
            Throw New Exception("Error in inserting to DB  " & err.Message)
            UpdateRecord = False

        Finally
            conn.Close()
            cmd.Dispose()
        End Try
        Return UpdateRecord

    End Function

    Public Overloads Function UpdateRecord(ByVal Query As String) As Boolean

        UpdateRecord = False
        Dim Statement As String
        Statement = Query
        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand
        Try
            cmd.Connection = conn
            cmd.CommandType = CommandType.Text
            cmd.CommandText = Query
            conn.Open()
            cmd.ExecuteNonQuery()
            conn.Close()
            UpdateRecord = True
        Catch err As Exception
            Throw New Exception("Error in inserting to DB  " & err.Message)
            UpdateRecord = False

        Finally
            conn.Close()
            cmd.Dispose()
        End Try
        Return UpdateRecord

    End Function

    Public Function DeleteCusCP(ByVal customerID As String) As Boolean
        Dim DeleteRecord As Boolean
        Dim conn As New SqlConnection(ConnectionString)

        Dim Query As String = "delete from admin_CustomerCP_Product where CustomerID=@customer_id"
        Dim cmd As New SqlCommand(Query, conn)
        Try

            cmd.Parameters.Add("@customer_id", SqlDbType.VarChar, 10).Value = customerID


            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            conn.Close()
            DeleteRecord = True
        Catch err As DataException
            Throw New ApplicationException("Error in inserting to DB  " & err.Message)
            DeleteRecord = False
        Finally
            conn.Close()
            cmd.Dispose()
        End Try

        Return DeleteRecord
    End Function

    Public Overloads Function DeleteRecord(ByVal Acct As String, ByVal Username As String) As Boolean

        DeleteRecord = False
        Dim Query As String
        Dim pwd As String = "test"
        'Query = "insert into  tblUserPrimary (UserNameID,UserName,Password) values ( " & UserID & " , '" & Username & "','" & pwd & "' )"
        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand
        Try
            cmd.Connection = conn
            cmd.CommandType = CommandType.Text
            cmd.CommandText = Query
            conn.Open()
            cmd.ExecuteNonQuery()
            conn.Close()
            DeleteRecord = True
        Catch err As Exception
            Throw New Exception("Error in inserting to DB  " & err.Message)
            DeleteRecord = False

        Finally
            conn.Close()
            cmd.Dispose()
        End Try
        Return DeleteRecord

    End Function

    Public Overloads Function DeleteRecord(ByVal Query As String) As Boolean

        DeleteRecord = False
        Dim Statement As String
        Statement = Query
        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand
        Try
            cmd.Connection = conn
            cmd.CommandType = CommandType.Text
            cmd.CommandText = Query
            conn.Open()
            cmd.ExecuteNonQuery()
            conn.Close()
            DeleteRecord = True
        Catch err As Exception
            Throw New Exception("Error in inserting to DB  " & err.Message)
            DeleteRecord = False

        Finally
            conn.Close()
            cmd.Dispose()
        End Try
        Return DeleteRecord

    End Function

    Public Function DeleteProduct(ByVal productName As String) As Boolean

        Dim DeleteRecord As Boolean = False

        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand
        Try
            cmd.Connection = conn
            cmd.CommandText = "sp_deleteStandardProduct"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.Add("@productid", SqlDbType.VarChar, 10).Value = productName
            conn.Open()
            cmd.ExecuteNonQuery()
            conn.Close()
            DeleteRecord = True
        Catch err As Exception
            Throw New Exception("Error in inserting to DB  " & err.Message)
            DeleteRecord = False

        Finally
            conn.Close()
            cmd.Dispose()
        End Try
        Return DeleteRecord

    End Function

    Public Function DeleteUser(ByVal userID As String) As Boolean

        Dim DeleteRecord As Boolean = False

        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand
        Try
            cmd.Connection = conn
            cmd.CommandText = "sp_deleteStandardUser"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.Add("@userid", SqlDbType.VarChar, 10).Value = userID
            conn.Open()
            cmd.ExecuteNonQuery()
            conn.Close()
            DeleteRecord = True
        Catch err As Exception
            Throw New Exception("Error in inserting to DB  " & err.Message)
            DeleteRecord = False

        Finally
            conn.Close()
            cmd.Dispose()
        End Try
        Return DeleteRecord

    End Function

    Public Function DeleteSubscriptionPayment(ByVal receiptNum As String) As Boolean

        Dim DeleteRecord As Boolean = False

        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand
        Try
            cmd.Connection = conn
            cmd.CommandText = "sp_deleteStandardPayment"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.Add("@receiptnum", SqlDbType.VarChar, 10).Value = receiptNum
            conn.Open()
            cmd.ExecuteNonQuery()
            conn.Close()
            DeleteRecord = True
        Catch err As Exception
            Throw New Exception("Error in inserting to DB  " & err.Message)
            DeleteRecord = False

        Finally
            conn.Close()
            cmd.Dispose()
        End Try
        Return DeleteRecord

    End Function

    Public Overloads Function DisplayReceiptNo(ByVal InvoiceNo As String) As DataTable
        Dim DT As New DataTable
        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand()
        'Dim Reader1 As SqlClient.SqlDataReader
        Try
            cmd.CommandText = "sp_getReceiptNo"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Connection = conn
            cmd.Parameters.Add("@invoice_no", SqlDbType.VarChar, 10).Value = InvoiceNo
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)


        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally
            conn.Close()
        End Try

        Return DT
    End Function

    Public Function GetUserIDsByGroupID(ByVal GroupID As String, ByVal parameterName As String, ByVal queryInput As String) As DataTable

        Dim Query As String = queryInput
        Dim DT As New DataTable
        Dim conn As New SqlConnection(ConnectionString)

        Try
            Dim cmd As New SqlCommand(Query, conn)
            cmd.Parameters.Add(parameterName, SqlDbType.VarChar, 10).Value = GroupID

            conn.Open()
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)

        Catch err As Exception
            Throw New ApplicationException("Error in connecting to DB " & err.Message)
        Finally
            conn.Close()
            Query = ""

        End Try

        Return DT
    End Function

    Public Function GetUserIDsByAccountID(ByVal AccountID As String, ByVal parameterName As String, ByVal queryInput As String) As DataTable

        Dim Query As String = queryInput
        Dim DT As New DataTable
        Dim conn As New SqlConnection(ConnectionString)

        Try
            Dim cmd As New SqlCommand(Query, conn)
            cmd.Parameters.Add(parameterName, SqlDbType.VarChar, 10).Value = AccountID

            conn.Open()
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)

        Catch err As Exception
            Throw New ApplicationException("Error in connecting to DB " & err.Message)
        Finally
            conn.Close()
            Query = ""

        End Try

        Return DT
    End Function
    Public Overloads Function DisplayReceiptDetails(ByVal InvoiceNo As String) As DataTable
        Dim DT As New DataTable
        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand()
        'Dim Reader1 As SqlClient.SqlDataReader
        Try
            cmd.CommandText = "sp_getReceipt"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Connection = conn
            cmd.Parameters.Add("@invoice_no", SqlDbType.VarChar, 10).Value = InvoiceNo
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)


        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally
            conn.Close()
        End Try

        Return DT
    End Function

    Public Overloads Function DisplayAdvancedDetails(ByVal UserID As String, ByVal InvoiceNo As String) As DataTable
        Dim DT As New DataTable
        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand()
        'Dim Reader1 As SqlClient.SqlDataReader
        Try
            cmd.CommandText = "sp_getAdvancedDetailsofInvoice"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Connection = conn
            cmd.Parameters.Add("@UserID", SqlDbType.VarChar, 10).Value = UserID
            cmd.Parameters.Add("@InvoiceNo", SqlDbType.VarChar, 10).Value = InvoiceNo
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)


        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally
            conn.Close()
        End Try

        Return DT
    End Function

    Public Overloads Function DisplayAdvancedUserDetails(ByVal UserID As String) As DataTable
        Dim DT As New DataTable
        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand()
        'Dim Reader1 As SqlClient.SqlDataReader
        Try
            cmd.CommandText = "sp_getAdvancedDetailsofUser"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Connection = conn
            cmd.Parameters.Add("@UserID", SqlDbType.VarChar, 10).Value = UserID
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)


        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally
            conn.Close()
        End Try

        Return DT
    End Function

    Public Overloads Function DisplayAllDetailsOfUser(ByVal UserID As String) As DataTable
        Dim DT As New DataTable
        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand()
        'Dim Reader1 As SqlClient.SqlDataReader
        Try
            cmd.CommandText = "sp_getAllDetailsOfUser"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Connection = conn
            cmd.Parameters.Add("@userid", SqlDbType.VarChar, 10).Value = UserID
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)


        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally
            conn.Close()
        End Try

        Return DT
    End Function

    Public Overloads Function getFreeUserDetails(ByVal userID As String) As DataTable

        Dim DT As New DataTable()
        Dim conn As New SqlConnection(ConnectionString)
        Dim Query As String = "select c.CustomerName,cp.CPFName,cp.CPLName,nu.UserName"
        Query &= ",a.Reg_Date, a.AllocatedSize, c.Address1,c.Address2"
        Query &= ",c.city,c.State,c.postalcode,c.Country,c.PhoneNo"
        Query &= ",c.FaxNo,cp.CPEmail, nu.UserType from Customer c "
        Query &= "INNER JOIN admin_ContactPerson cp on cp.CustomerID =c.CustomerID "
        Query &= "INNER JOIN Account a ON a.CustomerID = c.CustomerID "
        Query &= "INNER JOIN Admin_Users nu ON nu.AccountID = a.AccountID  "
        Query &= "where nu.UserID=@UserID"
        Dim cmd As New SqlCommand(Query, conn)
        Try

            cmd.Parameters.Add("UserID", SqlDbType.VarChar, 10).Value = userID
            conn.Open()
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)

        Catch err As Exception
            Throw New ApplicationException("Error in connecting to DB " & err.Message)
        Finally
            conn.Close()
            Query = ""
            cmd = Nothing
        End Try

        Return DT
    End Function

    Public Overloads Function getLastInvoiceNo() As Integer

        Dim invoiceNo As Integer
        Dim DT As New DataTable()
        Dim conn As New SqlConnection(ConnectionString)
        Dim Query As String = "select MAX(InvoiceNo) from myseminars_Invoice"

        Try
            Dim cmd As New SqlCommand(Query, conn)


            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)

            cmd = Nothing

            invoiceNo = DT.Rows(0).Item(0)
        Catch
            invoiceNo = 0
        Finally

        End Try

        Return invoiceNo
    End Function

    Public Overloads Function DisplayBasicDetails(ByVal UserID As String, ByVal invoiceNo As Integer) As DataTable
        Dim DT As New DataTable
        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand()
        'Dim Reader1 As SqlClient.SqlDataReader
        Try
            cmd.CommandText = "sp_getBasicDetailsofInvoice"

            cmd.CommandType = CommandType.StoredProcedure
            cmd.Connection = conn
            cmd.Parameters.Add("@UserID", SqlDbType.VarChar, 10).Value = UserID
            cmd.Parameters.Add("@invoiceno", SqlDbType.Int).Value = invoiceNo

            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)


        Catch err As DataException

            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally
            conn.Close()
        End Try

        Return DT
    End Function

    Public Overloads Function DisplayBasicDetailsByUserName(ByVal UserName As String) As DataTable
        Dim DT As New DataTable
        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand()
        'Dim Reader1 As SqlClient.SqlDataReader
        Try
            cmd.CommandText = "sp_getBasicDetailsofInvoiceBasedOnUserName"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Connection = conn
            cmd.Parameters.Add("@UserName", SqlDbType.VarChar, 20).Value = UserName
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)


        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally
            conn.Close()
        End Try

        Return DT
    End Function

    Public Overloads Function DisplayCompanyDetails(ByVal CustomerName As String) As DataTable
        Dim DT As New DataTable
        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand()
        'Dim Reader1 As SqlClient.SqlDataReader
        Try
            cmd.CommandText = "sp_getCompanyDetails"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Connection = conn
            cmd.Parameters.Add("@customer", SqlDbType.VarChar, 35).Value = CustomerName
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)


        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally
            conn.Close()
        End Try

        Return DT
    End Function

    Public Function GetSubscription(ByVal UserID As String) As DataTable
        Dim DT As New DataTable
        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand()
        'Dim Reader1 As SqlClient.SqlDataReader
        Try
            cmd.CommandText = "sp_getSubscriptions"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Connection = conn
            cmd.Parameters.Add("@userid", SqlDbType.VarChar, 10).Value = UserID
            conn.Open()
            cmd.ExecuteNonQuery()
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)


        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally
            conn.Close()
            cmd.Dispose()
            conn.Dispose()
        End Try

        Return DT
    End Function

    Public Overloads Function DisplayUserLoginDetails(ByVal product As String, ByVal Day As String, ByVal Month As String, ByVal Year As Integer) As DataTable
        Dim DT As New DataTable
        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand()
        'Dim Reader1 As SqlClient.SqlDataReader
        Try
            cmd.CommandText = "sp_getUserDetailsAdminVersionByDateAndProduct"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Connection = conn
            cmd.Parameters.Add("@product", SqlDbType.VarChar, 30).Value = product
            cmd.Parameters.Add("@day", SqlDbType.VarChar, 2).Value = Day
            cmd.Parameters.Add("@month", SqlDbType.VarChar, 2).Value = Month
            cmd.Parameters.Add("@year", SqlDbType.Int).Value = Year
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)


        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally
            conn.Close()
        End Try

        Return DT
    End Function

    Public Overloads Function DisplayUserID(ByVal InvoiceNo As String) As String
        Dim DT As New DataTable
        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand()
        Dim userID As String = ""
        'Dim Reader1 As SqlClient.SqlDataReader
        Try
            cmd.CommandText = "sp_getUserIDBasedOnInvoiceNo"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Connection = conn
            cmd.Parameters.Add("@InvoiceNo", SqlDbType.VarChar, 10).Value = InvoiceNo
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)

            If DT.Rows.Count > 0 Then
                userID = DT.Rows(0).Item(0)
            Else
                userID = ""
            End If


        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally
            conn.Close()
        End Try

        Return userID
    End Function

    Private Overloads Function FetchDataSet(ByVal Query As String, ByVal tblName As String) As DataSet
        Dim ds As New DataSet
        'Dim Reader1 As SqlClient.SqlDataReader
        Try
            Dim conn As New SqlConnection(ConnectionString)
            Dim cmd As New SqlCommand(Query, conn)

            Dim adapter As New SqlDataAdapter(cmd)

            adapter.Fill(ds, tblName)
            conn.Close()

        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally

        End Try

        Return ds
    End Function


    Public Overloads Function FetchDataSet(ByVal Query As String) As DataTable
        Dim DT As New DataTable
        Dim conn As New SqlConnection(ConnectionString)

        Try
            Dim cmd As New SqlCommand(Query, conn)
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)

            cmd = Nothing

        Catch err As Exception
            Throw New Exception("Error in DB:= " & err.Message)
        Finally
            conn.Close()
        End Try

        Return DT
    End Function

    Private Function FetchDataTable(ByVal procedureName As String) As DataTable
        Dim dt As New DataTable()

        Try
            Dim conn As New SqlConnection(ConnectionString)

            Dim cmd As New SqlCommand()
            cmd.Connection = conn
            cmd.CommandText = procedureName
            cmd.CommandType = CommandType.StoredProcedure

            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            Dim adapter As New SqlDataAdapter(cmd)

            adapter.Fill(dt)
            conn.Close()

        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally

        End Try

        Return dt
    End Function

    Private Function FetchDataTable2(ByVal criteria As String, ByVal parameterName As String, ByVal criteria2 As String, ByVal parameterName2 As String, ByVal procedureName As String, ByVal type As String) As DataTable
        Dim dt As New DataTable
        Dim myParameter1 As SqlParameter
        Dim myParameter2 As SqlParameter

        Try
            Dim conn As New SqlConnection(ConnectionString)

            Dim cmd As New SqlCommand()
            cmd.Connection = conn
            cmd.CommandText = procedureName
            cmd.CommandType = CommandType.StoredProcedure
            myParameter1 = cmd.CreateParameter()
            myParameter1.ParameterName = parameterName
            myParameter1.Direction = ParameterDirection.Input
            If (type = "Date") Then
                myParameter1.SqlDbType = SqlDbType.DateTime
            ElseIf (type = "Int") Then
                myParameter1.SqlDbType = SqlDbType.Int
            ElseIf (type = "String") Then
                myParameter1.SqlDbType = SqlDbType.VarChar
            End If
            myParameter1.Value = criteria.ToString()
            cmd.Parameters.Add(myParameter1)
            myParameter2 = cmd.CreateParameter()
            myParameter2.ParameterName = parameterName2
            myParameter2.Direction = ParameterDirection.Input
            If (type = "Date") Then
                myParameter2.SqlDbType = SqlDbType.DateTime
            ElseIf (type = "Int") Then
                myParameter2.SqlDbType = SqlDbType.Int
            ElseIf (type = "String") Then
                myParameter2.SqlDbType = SqlDbType.VarChar
            End If
            myParameter2.Value = criteria2.ToString()
            cmd.Parameters.Add(myParameter2)

            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            Dim adapter As New SqlDataAdapter(cmd)

            adapter.Fill(dt)
            conn.Close()

        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally

        End Try

        Return dt
    End Function

    'for different types and two parameters
    Private Function FetchDataSet4(ByVal criteria As String, ByVal parameterName As String, ByVal criteria2 As String, ByVal parameterName2 As String, ByVal procedureName As String, ByVal type As String) As DataSet
        Dim ds As New DataSet()
        Dim myParameter1 As SqlParameter
        Dim myParameter2 As SqlParameter

        Try
            Dim conn As New SqlConnection(ConnectionString)

            Dim cmd As New SqlCommand()
            cmd.Connection = conn
            cmd.CommandText = procedureName
            cmd.CommandType = CommandType.StoredProcedure
            myParameter1 = cmd.CreateParameter()
            myParameter1.ParameterName = parameterName
            myParameter1.Direction = ParameterDirection.Input
            If (type = "Date") Then
                myParameter1.SqlDbType = SqlDbType.DateTime
            ElseIf (type = "Int") Then
                myParameter1.SqlDbType = SqlDbType.Int
            ElseIf (type = "String") Then
                myParameter1.SqlDbType = SqlDbType.VarChar
            End If
            myParameter1.Value = criteria.ToString()
            cmd.Parameters.Add(myParameter1)
            myParameter2 = cmd.CreateParameter()
            myParameter2.ParameterName = parameterName2
            myParameter2.Direction = ParameterDirection.Input
            If (type = "Date") Then
                myParameter2.SqlDbType = SqlDbType.DateTime
            ElseIf (type = "Int") Then
                myParameter2.SqlDbType = SqlDbType.Int
            ElseIf (type = "String") Then
                myParameter2.SqlDbType = SqlDbType.VarChar
            End If
            myParameter2.Value = criteria2.ToString()
            cmd.Parameters.Add(myParameter2)

            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            Dim adapter As New SqlDataAdapter(cmd)

            adapter.Fill(ds)
            conn.Close()

        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally

        End Try

        Return ds
    End Function
    Private Function FetchDataSet5(ByVal criteria As String, ByVal parameterName As String, ByVal criteria2 As String, ByVal parameterName2 As String, ByVal procedureName As String, ByVal type As String, ByVal productGroup As String) As DataSet
        Dim ds As New DataSet()
        Dim myParameter1 As SqlParameter
        Dim myParameter2 As SqlParameter

        Try
            Dim conn As New SqlConnection(ConnectionString)

            Dim cmd As New SqlCommand()
            cmd.Connection = conn
            cmd.CommandText = procedureName
            cmd.CommandType = CommandType.StoredProcedure
            myParameter1 = cmd.CreateParameter()
            myParameter1.ParameterName = parameterName
            myParameter1.Direction = ParameterDirection.Input
            If (type = "Date") Then
                myParameter1.SqlDbType = SqlDbType.DateTime
            ElseIf (type = "Int") Then
                myParameter1.SqlDbType = SqlDbType.Int
            ElseIf (type = "String") Then
                myParameter1.SqlDbType = SqlDbType.VarChar
            End If
            myParameter1.Value = criteria.ToString()
            cmd.Parameters.Add(myParameter1)
            myParameter2 = cmd.CreateParameter()
            myParameter2.ParameterName = parameterName2
            myParameter2.Direction = ParameterDirection.Input
            If (type = "Date") Then
                myParameter2.SqlDbType = SqlDbType.DateTime
            ElseIf (type = "Int") Then
                myParameter2.SqlDbType = SqlDbType.Int
            ElseIf (type = "String") Then
                myParameter2.SqlDbType = SqlDbType.VarChar
            End If
            myParameter2.Value = criteria2.ToString()
            cmd.Parameters.Add(myParameter2)
            cmd.Parameters.Add("@pgi", SqlDbType.VarChar, 10).Value = productGroup
            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            Dim adapter As New SqlDataAdapter(cmd)

            adapter.Fill(ds)
            conn.Close()

        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally

        End Try

        Return ds
    End Function
    'without a parameter
    Private Function FetchDataSet3(ByVal procedureName As String) As DataSet
        Dim ds As New DataSet()

        Try
            Dim conn As New SqlConnection(ConnectionString)

            Dim cmd As New SqlCommand()
            cmd.Connection = conn
            cmd.CommandText = procedureName
            cmd.CommandType = CommandType.StoredProcedure

            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            Dim adapter As New SqlDataAdapter(cmd)

            adapter.Fill(ds)
            conn.Close()

        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally

        End Try

        Return ds
    End Function

    'For reports with different criteria
    Private Function FetchDataSet2(ByVal criteria As String, ByVal parameterName As String, ByVal procedureName As String) As DataSet
        Dim ds As New DataSet()
        Dim myParameter2 As SqlParameter

        Try
            Dim conn As New SqlConnection(ConnectionString)

            Dim cmd As New SqlCommand()
            cmd.Connection = conn
            cmd.CommandText = procedureName
            cmd.CommandType = CommandType.StoredProcedure
            myParameter2 = cmd.CreateParameter()
            myParameter2.ParameterName = parameterName
            myParameter2.Direction = ParameterDirection.Input
            myParameter2.SqlDbType = SqlDbType.VarChar
            myParameter2.Value = criteria.ToString()
            cmd.Parameters.Add(myParameter2)

            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            Dim adapter As New SqlDataAdapter(cmd)

            adapter.Fill(ds)
            conn.Close()

        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally

        End Try

        Return ds
    End Function

    Public Function GetStandardInvoiceByCountry(ByVal country As String, ByVal productGroup As String) As DataSet
        Dim ds As New DataSet()
        Dim myParameter1 As SqlParameter
        Dim myParameter2 As SqlParameter

        Try
            Dim conn As New SqlConnection(ConnectionString)

            Dim cmd As New SqlCommand()
            cmd.Connection = conn
            cmd.CommandText = "sp_getStandardInvoiceByCountry"
            cmd.CommandType = CommandType.StoredProcedure
            myParameter1 = cmd.CreateParameter()
            myParameter1.ParameterName = "@country"
            myParameter1.Direction = ParameterDirection.Input
            myParameter1.SqlDbType = SqlDbType.VarChar

            myParameter1.Value = country
            cmd.Parameters.Add(myParameter1)
            myParameter2 = cmd.CreateParameter()
            myParameter2.ParameterName = "@pgi"
            myParameter2.Direction = ParameterDirection.Input
            myParameter2.SqlDbType = SqlDbType.VarChar

            myParameter2.Value = productGroup
            cmd.Parameters.Add(myParameter2)

            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            Dim adapter As New SqlDataAdapter(cmd)

            adapter.Fill(ds)
            conn.Close()

        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally

        End Try

        Return ds
    End Function

    Public Function GetStandardInvoiceByAccountType(ByVal accountType As String, ByVal productGroup As String) As DataSet
        Dim ds As New DataSet()
        Dim myParameter1 As SqlParameter
        Dim myParameter2 As SqlParameter

        Try
            Dim conn As New SqlConnection(ConnectionString)

            Dim cmd As New SqlCommand()
            cmd.Connection = conn
            cmd.CommandText = "sp_getStandardInvoiceByAccountType"
            cmd.CommandType = CommandType.StoredProcedure
            myParameter1 = cmd.CreateParameter()
            myParameter1.ParameterName = "@account_type"
            myParameter1.Direction = ParameterDirection.Input
            myParameter1.SqlDbType = SqlDbType.VarChar

            myParameter1.Value = accountType
            cmd.Parameters.Add(myParameter1)
            myParameter2 = cmd.CreateParameter()
            myParameter2.ParameterName = "@pgi"
            myParameter2.Direction = ParameterDirection.Input
            myParameter2.SqlDbType = SqlDbType.VarChar

            myParameter2.Value = productGroup
            cmd.Parameters.Add(myParameter2)

            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            Dim adapter As New SqlDataAdapter(cmd)

            adapter.Fill(ds)
            conn.Close()

        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally

        End Try

        Return ds
    End Function

    Public Function GetStandardInvoiceByPaymentMode(ByVal payMode As String, ByVal productGroup As String) As DataSet
        Dim ds As New DataSet()
        Dim myParameter1 As SqlParameter
        Dim myParameter2 As SqlParameter

        Try
            Dim conn As New SqlConnection(ConnectionString)

            Dim cmd As New SqlCommand()
            cmd.Connection = conn
            cmd.CommandText = "sp_getStandardInvoiceByPaymentMode"
            cmd.CommandType = CommandType.StoredProcedure
            myParameter1 = cmd.CreateParameter()
            myParameter1.ParameterName = "@paymentmode"
            myParameter1.Direction = ParameterDirection.Input
            myParameter1.SqlDbType = SqlDbType.VarChar

            myParameter1.Value = payMode
            cmd.Parameters.Add(myParameter1)
            myParameter2 = cmd.CreateParameter()
            myParameter2.ParameterName = "@pgi"
            myParameter2.Direction = ParameterDirection.Input
            myParameter2.SqlDbType = SqlDbType.VarChar

            myParameter2.Value = productGroup
            cmd.Parameters.Add(myParameter2)

            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            Dim adapter As New SqlDataAdapter(cmd)

            adapter.Fill(ds)
            conn.Close()

        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally

        End Try

        Return ds
    End Function

    Public Function GetStandardInvoiceByInvoiceNo(ByVal invoiceNo As String, ByVal productGroup As String) As DataSet
        Dim ds As New DataSet()
        Dim myParameter1 As SqlParameter
        Dim myParameter2 As SqlParameter

        Try
            Dim conn As New SqlConnection(ConnectionString)

            Dim cmd As New SqlCommand()
            cmd.Connection = conn
            cmd.CommandText = "sp_getStandardInvoiceByInvoiceNo"
            cmd.CommandType = CommandType.StoredProcedure
            myParameter1 = cmd.CreateParameter()
            myParameter1.ParameterName = "@invoice_no"
            myParameter1.Direction = ParameterDirection.Input
            myParameter1.SqlDbType = SqlDbType.Int

            myParameter1.Value = invoiceNo.ToString()
            cmd.Parameters.Add(myParameter1)
            myParameter2 = cmd.CreateParameter()
            myParameter2.ParameterName = "@pgi"
            myParameter2.Direction = ParameterDirection.Input
            myParameter2.SqlDbType = SqlDbType.VarChar

            myParameter2.Value = productGroup
            cmd.Parameters.Add(myParameter2)

            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            Dim adapter As New SqlDataAdapter(cmd)

            adapter.Fill(ds)
            conn.Close()

        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally

        End Try

        Return ds
    End Function

    Public Function GetStandardInvoiceByDate(ByVal date1 As String, ByVal date2 As String, ByVal productGroup As String) As DataSet
        Dim ds As New DataSet()
        Dim myParameter1 As SqlParameter
        Dim myParameter2 As SqlParameter
        Dim myParameter3 As SqlParameter

        Try
            Dim conn As New SqlConnection(ConnectionString)

            Dim cmd As New SqlCommand()
            cmd.Connection = conn
            cmd.CommandText = "sp_getStandardInvoiceByDate"
            cmd.CommandType = CommandType.StoredProcedure
            myParameter1 = cmd.CreateParameter()
            myParameter1.ParameterName = "@date1"
            myParameter1.Direction = ParameterDirection.Input
            myParameter1.SqlDbType = SqlDbType.DateTime

            myParameter1.Value = date1.ToString()
            cmd.Parameters.Add(myParameter1)

            myParameter2 = cmd.CreateParameter()
            myParameter2.ParameterName = "@date2"
            myParameter2.Direction = ParameterDirection.Input
            myParameter2.SqlDbType = SqlDbType.DateTime

            myParameter2.Value = date2.ToString()
            cmd.Parameters.Add(myParameter2)

            myParameter3 = cmd.CreateParameter()
            myParameter3.ParameterName = "@pgi"
            myParameter3.Direction = ParameterDirection.Input
            myParameter3.SqlDbType = SqlDbType.VarChar

            myParameter3.Value = productGroup
            cmd.Parameters.Add(myParameter3)
            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            Dim adapter As New SqlDataAdapter(cmd)

            adapter.Fill(ds)
            conn.Close()

        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally

        End Try

        Return ds
    End Function

    Public Function GetCancelledInvoiceByDate(ByVal date1 As String, ByVal date2 As String, ByVal productGroup As String) As DataSet
        Dim ds As New DataSet()
        Dim myParameter1 As SqlParameter
        Dim myParameter2 As SqlParameter
        Dim myParameter3 As SqlParameter

        Try
            Dim conn As New SqlConnection(ConnectionString)

            Dim cmd As New SqlCommand()
            cmd.Connection = conn
            cmd.CommandText = "sp_getCancelledInvoiceByDate"
            cmd.CommandType = CommandType.StoredProcedure
            myParameter1 = cmd.CreateParameter()
            myParameter1.ParameterName = "@date1"
            myParameter1.Direction = ParameterDirection.Input
            myParameter1.SqlDbType = SqlDbType.DateTime

            myParameter1.Value = date1.ToString()
            cmd.Parameters.Add(myParameter1)

            myParameter2 = cmd.CreateParameter()
            myParameter2.ParameterName = "@date2"
            myParameter2.Direction = ParameterDirection.Input
            myParameter2.SqlDbType = SqlDbType.DateTime

            myParameter2.Value = date2.ToString()
            cmd.Parameters.Add(myParameter2)

            myParameter3 = cmd.CreateParameter()
            myParameter3.ParameterName = "@pgi"
            myParameter3.Direction = ParameterDirection.Input
            myParameter3.SqlDbType = SqlDbType.VarChar

            myParameter3.Value = productGroup
            cmd.Parameters.Add(myParameter3)
            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            Dim adapter As New SqlDataAdapter(cmd)

            adapter.Fill(ds)
            conn.Close()

        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally

        End Try

        Return ds
    End Function

    Public Function GetStandardProductByDate(ByVal date1 As String, ByVal date2 As String, ByVal productGroup As String) As DataSet
        Dim ds As New DataSet()
        Dim myParameter1 As SqlParameter
        Dim myParameter2 As SqlParameter
        Dim myParameter3 As SqlParameter

        Try
            Dim conn As New SqlConnection(ConnectionString)

            Dim cmd As New SqlCommand()
            cmd.Connection = conn
            cmd.CommandText = "sp_getStandardProductByDate"
            cmd.CommandType = CommandType.StoredProcedure
            myParameter1 = cmd.CreateParameter()
            myParameter1.ParameterName = "@date1"
            myParameter1.Direction = ParameterDirection.Input
            myParameter1.SqlDbType = SqlDbType.DateTime

            myParameter1.Value = date1.ToString()
            cmd.Parameters.Add(myParameter1)

            myParameter2 = cmd.CreateParameter()
            myParameter2.ParameterName = "@date2"
            myParameter2.Direction = ParameterDirection.Input
            myParameter2.SqlDbType = SqlDbType.DateTime

            myParameter2.Value = date2.ToString()
            cmd.Parameters.Add(myParameter2)

            myParameter3 = cmd.CreateParameter()
            myParameter3.ParameterName = "@pgi"
            myParameter3.Direction = ParameterDirection.Input
            myParameter3.SqlDbType = SqlDbType.VarChar

            myParameter3.Value = productGroup
            cmd.Parameters.Add(myParameter3)
            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            Dim adapter As New SqlDataAdapter(cmd)

            adapter.Fill(ds)
            conn.Close()

        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally

        End Try

        Return ds
    End Function

    Public Function GetStandardInvoiceByMonth(ByVal month As String, ByVal year As String, ByVal productGroup As String) As DataSet
        Dim ds As New DataSet()
        Dim myParameter1 As SqlParameter
        Dim myParameter2 As SqlParameter
        Dim myParameter3 As SqlParameter

        Try
            Dim conn As New SqlConnection(ConnectionString)

            Dim cmd As New SqlCommand()
            cmd.Connection = conn
            cmd.CommandText = "sp_getStandardInvoiceByMonth"
            cmd.CommandType = CommandType.StoredProcedure
            myParameter1 = cmd.CreateParameter()
            myParameter1.ParameterName = "@month"
            myParameter1.Direction = ParameterDirection.Input
            myParameter1.SqlDbType = SqlDbType.Int

            myParameter1.Value = month.ToString()
            cmd.Parameters.Add(myParameter1)
            myParameter2 = cmd.CreateParameter()
            myParameter2.ParameterName = "@year"
            myParameter2.Direction = ParameterDirection.Input
            myParameter2.SqlDbType = SqlDbType.Int

            myParameter2.Value = year.ToString()
            cmd.Parameters.Add(myParameter2)
            myParameter3 = cmd.CreateParameter()
            myParameter3.ParameterName = "@pgi"
            myParameter3.Direction = ParameterDirection.Input
            myParameter3.SqlDbType = SqlDbType.VarChar

            myParameter3.Value = productGroup
            cmd.Parameters.Add(myParameter3)
            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            Dim adapter As New SqlDataAdapter(cmd)

            adapter.Fill(ds)
            conn.Close()

        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally

        End Try

        Return ds
    End Function

    Public Function GetStandardProductByMonth(ByVal month As String, ByVal year As String, ByVal productGroup As String) As DataSet
        Dim ds As New DataSet()
        Dim myParameter1 As SqlParameter
        Dim myParameter2 As SqlParameter
        Dim myParameter3 As SqlParameter

        Try
            Dim conn As New SqlConnection(ConnectionString)

            Dim cmd As New SqlCommand()
            cmd.Connection = conn
            cmd.CommandText = "sp_getStandardProductByMonth"
            cmd.CommandType = CommandType.StoredProcedure
            myParameter1 = cmd.CreateParameter()
            myParameter1.ParameterName = "@month"
            myParameter1.Direction = ParameterDirection.Input
            myParameter1.SqlDbType = SqlDbType.Int

            myParameter1.Value = month.ToString()
            cmd.Parameters.Add(myParameter1)
            myParameter2 = cmd.CreateParameter()
            myParameter2.ParameterName = "@year"
            myParameter2.Direction = ParameterDirection.Input
            myParameter2.SqlDbType = SqlDbType.Int

            myParameter2.Value = year.ToString()
            cmd.Parameters.Add(myParameter2)
            myParameter3 = cmd.CreateParameter()
            myParameter3.ParameterName = "@pgi"
            myParameter3.Direction = ParameterDirection.Input
            myParameter3.SqlDbType = SqlDbType.VarChar

            myParameter3.Value = productGroup
            cmd.Parameters.Add(myParameter3)
            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            Dim adapter As New SqlDataAdapter(cmd)

            adapter.Fill(ds)
            conn.Close()

        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally

        End Try

        Return ds
    End Function

    Public Function GetStandardInvoiceOrderBy(ByVal criteria As String, ByVal order As String, ByVal productGroup As String) As DataSet
        Dim ds As New DataSet()
        Dim myParameter1 As SqlParameter
        Dim myParameter2 As SqlParameter
        Dim myParameter3 As SqlParameter

        Try
            Dim conn As New SqlConnection(ConnectionString)

            Dim cmd As New SqlCommand()
            cmd.Connection = conn
            cmd.CommandText = "sp_getStandardInvoiceOrderBy"
            cmd.CommandType = CommandType.StoredProcedure
            myParameter1 = cmd.CreateParameter()
            myParameter1.ParameterName = "@criteria"
            myParameter1.Direction = ParameterDirection.Input
            myParameter1.SqlDbType = SqlDbType.VarChar

            myParameter1.Value = criteria
            cmd.Parameters.Add(myParameter1)
            myParameter2 = cmd.CreateParameter()
            myParameter2.ParameterName = "@order"
            myParameter2.Direction = ParameterDirection.Input
            myParameter2.SqlDbType = SqlDbType.VarChar

            myParameter2.Value = order
            cmd.Parameters.Add(myParameter2)
            myParameter3 = cmd.CreateParameter()
            myParameter3.ParameterName = "@pgi"
            myParameter3.Direction = ParameterDirection.Input
            myParameter3.SqlDbType = SqlDbType.VarChar

            myParameter3.Value = productGroup
            cmd.Parameters.Add(myParameter3)
            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            Dim adapter As New SqlDataAdapter(cmd)

            adapter.Fill(ds)
            conn.Close()

        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally

        End Try

        Return ds
    End Function

    Public Function GetCancelledInvoiceOrderBy(ByVal criteria As String, ByVal order As String, ByVal productGroup As String) As DataSet
        Dim ds As New DataSet()
        Dim myParameter1 As SqlParameter
        Dim myParameter2 As SqlParameter
        Dim myParameter3 As SqlParameter

        Try
            Dim conn As New SqlConnection(ConnectionString)

            Dim cmd As New SqlCommand()
            cmd.Connection = conn
            cmd.CommandText = "sp_getCancelledInvoiceOrderBy"
            cmd.CommandType = CommandType.StoredProcedure
            myParameter1 = cmd.CreateParameter()
            myParameter1.ParameterName = "@criteria"
            myParameter1.Direction = ParameterDirection.Input
            myParameter1.SqlDbType = SqlDbType.VarChar

            myParameter1.Value = criteria
            cmd.Parameters.Add(myParameter1)
            myParameter2 = cmd.CreateParameter()
            myParameter2.ParameterName = "@order"
            myParameter2.Direction = ParameterDirection.Input
            myParameter2.SqlDbType = SqlDbType.VarChar

            myParameter2.Value = order
            cmd.Parameters.Add(myParameter2)
            myParameter3 = cmd.CreateParameter()
            myParameter3.ParameterName = "@pgi"
            myParameter3.Direction = ParameterDirection.Input
            myParameter3.SqlDbType = SqlDbType.VarChar

            myParameter3.Value = productGroup
            cmd.Parameters.Add(myParameter3)
            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            Dim adapter As New SqlDataAdapter(cmd)

            adapter.Fill(ds)
            conn.Close()

        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally

        End Try

        Return ds
    End Function

    Public Overloads Function getInvoiceDetails(ByVal invoiceNo As Integer) As DataTable

        Dim DT As New DataTable()
        Dim conn As New SqlConnection(ConnectionString)
        Dim Query As String = "select e.PName As ProductName, c.CustomerID + ' - ' + c.CustomerName As [Customer], ip.Quantity, i.DiscountFactor From Invoice i "
        Query &= "inner join Admin_InvoiceProduct ip ON i.InvoiceNo = ip.InvoiceNo  "
        Query &= "inner join Admin_Product e ON e.ProductID = ip.ProductNo "
        Query &= "inner join Customer c on c.CustomerID = i.CustomerID  "
        Query &= "where i.InvoiceNo = @InvoiceNo"

        Dim cmd As New SqlCommand(Query, conn)
        Try

            cmd.Parameters.Add("InvoiceNo", SqlDbType.Int).Value = invoiceNo
            conn.Open()
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)

        Catch err As Exception
            Throw New ApplicationException("Error in connecting to DB " & err.Message)
        Finally
            conn.Close()
            Query = ""
            cmd = Nothing
        End Try

        Return DT
    End Function
    Public Overloads Function getInvoiceDetailsLegalReview(ByVal invoiceNo As Integer) As DataTable

        Dim DT As New DataTable()
        Dim conn As New SqlConnection(ConnectionString)
        Dim Query As String = "select e.PName As ProductName, c.CustomerID + ' - ' + c.CustomerName As [Customer], ip.Quantity, i.DiscountFactor From Invoice i "
        Query &= "inner join Admin_InvoiceProduct ip ON i.InvoiceNo = ip.InvoiceNo  "
        Query &= "inner join Admin_Product e ON e.ProductID = ip.ProductNo "
        Query &= "inner join Customer c on c.CustomerID = i.CustomerID  "
        Query &= "where i.InvoiceNo = @InvoiceNo"

        Dim cmd As New SqlCommand(Query, conn)
        Try

            cmd.Parameters.Add("InvoiceNo", SqlDbType.Int).Value = invoiceNo
            conn.Open()
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)

        Catch err As Exception
            Throw New ApplicationException("Error in connecting to DB " & err.Message)
        Finally
            conn.Close()
            Query = ""
            cmd = Nothing
        End Try

        Return DT
    End Function
    Public Function GetStandardProductOrderBy(ByVal criteria As String, ByVal order As String, ByVal productGroup As String) As DataSet
        Dim ds As New DataSet()
        Dim myParameter1 As SqlParameter
        Dim myParameter2 As SqlParameter
        Dim myParameter3 As SqlParameter

        Try
            Dim conn As New SqlConnection(ConnectionString)

            Dim cmd As New SqlCommand()
            cmd.Connection = conn
            cmd.CommandText = "sp_getStandardProductOrderBy"
            cmd.CommandType = CommandType.StoredProcedure
            myParameter1 = cmd.CreateParameter()
            myParameter1.ParameterName = "@criteria"
            myParameter1.Direction = ParameterDirection.Input
            myParameter1.SqlDbType = SqlDbType.VarChar

            myParameter1.Value = criteria
            cmd.Parameters.Add(myParameter1)
            myParameter2 = cmd.CreateParameter()
            myParameter2.ParameterName = "@order"
            myParameter2.Direction = ParameterDirection.Input
            myParameter2.SqlDbType = SqlDbType.VarChar

            myParameter2.Value = order
            cmd.Parameters.Add(myParameter2)
            myParameter3 = cmd.CreateParameter()
            myParameter3.ParameterName = "@pgi"
            myParameter3.Direction = ParameterDirection.Input
            myParameter3.SqlDbType = SqlDbType.VarChar

            myParameter3.Value = productGroup
            cmd.Parameters.Add(myParameter3)
            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            Dim adapter As New SqlDataAdapter(cmd)

            adapter.Fill(ds)
            conn.Close()

        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally

        End Try

        Return ds
    End Function

    Public Function GetStandardSalesReportOrderBy(ByVal criteria As String, ByVal order As String, ByVal productGroup As String) As DataSet
        Dim ds As New DataSet()
        Dim myParameter1 As SqlParameter
        Dim myParameter2 As SqlParameter
        Dim myParameter3 As SqlParameter

        Try
            Dim conn As New SqlConnection(ConnectionString)

            Dim cmd As New SqlCommand()
            cmd.Connection = conn
            cmd.CommandText = "sp_getStandardSalesReportOrderBy"
            cmd.CommandType = CommandType.StoredProcedure
            myParameter1 = cmd.CreateParameter()
            myParameter1.ParameterName = "@criteria"
            myParameter1.Direction = ParameterDirection.Input
            myParameter1.SqlDbType = SqlDbType.VarChar

            myParameter1.Value = criteria
            cmd.Parameters.Add(myParameter1)
            myParameter2 = cmd.CreateParameter()
            myParameter2.ParameterName = "@order"
            myParameter2.Direction = ParameterDirection.Input
            myParameter2.SqlDbType = SqlDbType.VarChar

            myParameter2.Value = order
            cmd.Parameters.Add(myParameter2)
            myParameter3 = cmd.CreateParameter()
            myParameter3.ParameterName = "@pgi"
            myParameter3.Direction = ParameterDirection.Input
            myParameter3.SqlDbType = SqlDbType.VarChar

            myParameter3.Value = productGroup
            cmd.Parameters.Add(myParameter3)
            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            Dim adapter As New SqlDataAdapter(cmd)

            adapter.Fill(ds)
            conn.Close()

        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally

        End Try

        Return ds
    End Function

    Public Function GetStandardInvoiceByProduct(ByVal product As String, ByVal productGroup As String) As DataSet
        Dim ds As New DataSet()
        Dim myParameter1 As SqlParameter
        Dim myParameter2 As SqlParameter

        Try
            Dim conn As New SqlConnection(ConnectionString)

            Dim cmd As New SqlCommand()
            cmd.Connection = conn
            cmd.CommandText = "sp_getStandardInvoiceByProduct"
            cmd.CommandType = CommandType.StoredProcedure
            myParameter1 = cmd.CreateParameter()
            myParameter1.ParameterName = "@product_name"
            myParameter1.Direction = ParameterDirection.Input
            myParameter1.SqlDbType = SqlDbType.VarChar

            myParameter1.Value = product
            cmd.Parameters.Add(myParameter1)
            myParameter2 = cmd.CreateParameter()
            myParameter2.ParameterName = "@pgi"
            myParameter2.Direction = ParameterDirection.Input
            myParameter2.SqlDbType = SqlDbType.VarChar

            myParameter2.Value = productGroup
            cmd.Parameters.Add(myParameter2)

            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            Dim adapter As New SqlDataAdapter(cmd)

            adapter.Fill(ds)
            conn.Close()

        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally

        End Try

        Return ds
    End Function

    Public Function GetStandardProductByIDOrName(ByVal criteria As String, ByVal type As String, ByVal productGroup As String) As DataSet
        Dim ds As New DataSet()
        Dim myParameter1 As SqlParameter
        Dim myParameter2 As SqlParameter
        Dim myParameter3 As SqlParameter

        Try
            Dim conn As New SqlConnection(ConnectionString)

            Dim cmd As New SqlCommand()
            cmd.Connection = conn
            cmd.CommandText = "sp_getStandardProductByIDOrName"
            cmd.CommandType = CommandType.StoredProcedure
            myParameter1 = cmd.CreateParameter()
            myParameter1.ParameterName = "@criteria"
            myParameter1.Direction = ParameterDirection.Input
            myParameter1.SqlDbType = SqlDbType.VarChar

            myParameter1.Value = criteria
            cmd.Parameters.Add(myParameter1)
            myParameter2 = cmd.CreateParameter()
            myParameter2.ParameterName = "@type"
            myParameter2.Direction = ParameterDirection.Input
            myParameter2.SqlDbType = SqlDbType.VarChar

            myParameter2.Value = type
            cmd.Parameters.Add(myParameter2)
            myParameter3 = cmd.CreateParameter()
            myParameter3.ParameterName = "@pgi"
            myParameter3.Direction = ParameterDirection.Input
            myParameter3.SqlDbType = SqlDbType.VarChar

            myParameter3.Value = productGroup
            cmd.Parameters.Add(myParameter3)
            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            Dim adapter As New SqlDataAdapter(cmd)

            adapter.Fill(ds)
            conn.Close()

        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally

        End Try

        Return ds
    End Function

    Public Function GetStandardSalesReportByIDOrName(ByVal criteria As String, ByVal type As String, ByVal productGroup As String) As DataSet
        Dim ds As New DataSet()
        Dim myParameter1 As SqlParameter
        Dim myParameter2 As SqlParameter
        Dim myParameter3 As SqlParameter

        Try
            Dim conn As New SqlConnection(ConnectionString)

            Dim cmd As New SqlCommand()
            cmd.Connection = conn
            cmd.CommandText = "sp_getStandardSalesReportByIDOrName"
            cmd.CommandType = CommandType.StoredProcedure
            myParameter1 = cmd.CreateParameter()
            myParameter1.ParameterName = "@criteria"
            myParameter1.Direction = ParameterDirection.Input
            myParameter1.SqlDbType = SqlDbType.VarChar

            myParameter1.Value = criteria
            cmd.Parameters.Add(myParameter1)
            myParameter2 = cmd.CreateParameter()
            myParameter2.ParameterName = "@type"
            myParameter2.Direction = ParameterDirection.Input
            myParameter2.SqlDbType = SqlDbType.VarChar

            myParameter2.Value = type
            cmd.Parameters.Add(myParameter2)
            myParameter3 = cmd.CreateParameter()
            myParameter3.ParameterName = "@pgi"
            myParameter3.Direction = ParameterDirection.Input
            myParameter3.SqlDbType = SqlDbType.VarChar

            myParameter3.Value = productGroup
            cmd.Parameters.Add(myParameter3)
            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            Dim adapter As New SqlDataAdapter(cmd)

            adapter.Fill(ds)
            conn.Close()

        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally

        End Try

        Return ds
    End Function

    Public Function GetStandardSalesReportByStatus(ByVal status As String, ByVal productGroup As String) As DataSet
        Dim ds As New DataSet()
        Dim myParameter1 As SqlParameter
        Dim myParameter2 As SqlParameter

        Try
            Dim conn As New SqlConnection(ConnectionString)

            Dim cmd As New SqlCommand()
            cmd.Connection = conn
            cmd.CommandText = "sp_getStandardSalesReportByStatus"
            cmd.CommandType = CommandType.StoredProcedure
            myParameter1 = cmd.CreateParameter()
            myParameter1.ParameterName = "@status"
            myParameter1.Direction = ParameterDirection.Input
            myParameter1.SqlDbType = SqlDbType.VarChar

            myParameter1.Value = status

            cmd.Parameters.Add(myParameter1)
            myParameter2 = cmd.CreateParameter()
            myParameter2.ParameterName = "@pgi"
            myParameter2.Direction = ParameterDirection.Input
            myParameter2.SqlDbType = SqlDbType.VarChar

            myParameter2.Value = productGroup
            cmd.Parameters.Add(myParameter2)

            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            Dim adapter As New SqlDataAdapter(cmd)

            adapter.Fill(ds)
            conn.Close()

        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally

        End Try

        Return ds
    End Function

    Public Overloads Function getSalesReportByDate(ByVal productGroupID As String, ByVal date1 As Date, ByVal date2 As Date) As DataTable

        Dim DT As New DataTable()
        Dim conn As New SqlConnection(ConnectionString)
        Dim Query As String = "select I.InvoiceNo, PM.Status, C.CustomerName, p.AmountPaid, I.IDType + CONVERT(varchar,I.InvoiceNo) As NewInvoiceNo, I.Status As [InvoiceStatus], PM.Balance_Invoice "
        Query &= "from [elawdb].[dbo].Invoice I "
        Query &= "INNER JOIN [elawdb].[dbo].Customer C ON c.CustomerID = i.CustomerID "
        Query &= "INNER JOIN [elawdb].[dbo].Admin_InvoiceProduct ip ON i.InvoiceNo = ip.InvoiceNo "
        Query &= "INNER JOIN elawdb.dbo.Admin_PaymentMaster PM ON i.InvoiceNo = PM.InvoiceNo "
        Query &= "INNER JOIN [elawdb].[dbo].Admin_Payment p ON p.CusPayNo = PM.CusPayNo "
        Query &= "INNER JOIN [elawdb].[dbo].Admin_Product pr ON pr.ProductID = ip.ProductNo "
        Query &= "where pr.ProductGroupID = @pgi and I.IDate>=@date1 and I.IDate <= @date2"
        Dim cmd As New SqlCommand(Query, conn)
        Try


            cmd.Parameters.Add("pgi", SqlDbType.VarChar, 10).Value = productGroupID
            cmd.Parameters.Add("date1", SqlDbType.Date).Value = date1
            cmd.Parameters.Add("date2", SqlDbType.Date).Value = date2
            conn.Open()
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)

        Catch err As Exception
            Throw New ApplicationException("Error in connecting to DB " & err.Message)
        Finally
            conn.Close()
            Query = ""
            cmd = Nothing
        End Try

        Return DT
    End Function

    Public Overloads Function getMonthlySalesReport(ByVal productGroupID As String, ByVal month As Integer, ByVal year As Integer) As DataTable

        Dim DT As New DataTable()
        Dim conn As New SqlConnection(ConnectionString)
        Dim Query As String = "select I.InvoiceNo, PM.Status, C.CustomerName, p.AmountPaid, I.IDType + CONVERT(varchar,I.InvoiceNo) As NewInvoiceNo, I.Status As [InvoiceStatus], PM.Balance_Invoice "
        Query &= "from [elawdb].[dbo].Invoice I "
        Query &= "INNER JOIN [elawdb].[dbo].Customer C ON c.CustomerID = i.CustomerID "
        Query &= "INNER JOIN [elawdb].[dbo].Admin_InvoiceProduct ip ON i.InvoiceNo = ip.InvoiceNo "
        Query &= "INNER JOIN elawdb.dbo.Admin_PaymentMaster PM ON i.InvoiceNo = PM.InvoiceNo "
        Query &= "INNER JOIN [elawdb].[dbo].Admin_Payment p ON p.CusPayNo = PM.CusPayNo "
        Query &= "INNER JOIN [elawdb].[dbo].Admin_Product pr ON pr.ProductID = ip.ProductNo "
        Query &= "where pr.ProductGroupID = @pgi and month(I.IDate)=@month and YEAR(I.IDate)=@year"
        Dim cmd As New SqlCommand(Query, conn)
        Try


            cmd.Parameters.Add("pgi", SqlDbType.VarChar, 10).Value = productGroupID
            cmd.Parameters.Add("month", SqlDbType.Int).Value = month
            cmd.Parameters.Add("year", SqlDbType.Int).Value = year
            conn.Open()
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)

        Catch err As Exception
            Throw New ApplicationException("Error in connecting to DB " & err.Message)
        Finally
            conn.Close()
            Query = ""
            cmd = Nothing
        End Try

        Return DT
    End Function

    Public Function UpdateReceiptDetails(ByVal InvoiceNo As String, ByVal ReceiptNo As String, ByVal amountPaid As Decimal, ByVal chequeNo As String, ByVal bank As String, ByVal status As String, ByVal payMode As String, ByVal ccdate As Date) As Boolean
        Dim UpdateRecord As Boolean
        Dim conn As New SqlConnection(ConnectionString)

        Dim cmd As New SqlCommand()
        Try

            cmd.Connection = conn
            cmd.CommandText = "sp_UpdateReceiptDetails"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.Add("@invoice_no", SqlDbType.VarChar, 10).Value = InvoiceNo
            cmd.Parameters.Add("@receipt_no", SqlDbType.VarChar, 10).Value = ReceiptNo
            cmd.Parameters.Add("@amount_paid", SqlDbType.Money).Value = amountPaid
            cmd.Parameters.Add("@cheque_no", SqlDbType.VarChar, 25).Value = chequeNo
            cmd.Parameters.Add("@bank", SqlDbType.VarChar, 50).Value = bank
            cmd.Parameters.Add("@status", SqlDbType.VarChar, 10).Value = status
            cmd.Parameters.Add("@paymode", SqlDbType.VarChar, 11).Value = payMode
            cmd.Parameters.Add("@ccdate", SqlDbType.Date).Value = ccdate
            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            conn.Close()
            UpdateRecord = True
        Catch err As DataException
            Throw New ApplicationException("Error in inserting to DB  " & err.Message)
            UpdateRecord = False
        Finally
            conn.Close()
            cmd.Dispose()
        End Try

        Return UpdateRecord
    End Function

    Public Function UpdateStoredProcedure(ByVal criteria As String, ByVal criteria2 As String, ByVal parameterName As String, ByVal parameterName2 As String, ByVal procedureName As String, ByVal inputSize As Integer) As Boolean
        Dim UpdateRecord As Boolean
        Dim conn As New SqlConnection(ConnectionString)

        Dim cmd As New SqlCommand()
        Try

            cmd.Connection = conn
            cmd.CommandText = procedureName
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.Add(parameterName, SqlDbType.VarChar, inputSize).Value = criteria2
            cmd.Parameters.Add(parameterName2, SqlDbType.VarChar, inputSize).Value = criteria
            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            conn.Close()
            UpdateRecord = True
        Catch err As DataException
            Throw New ApplicationException("Error in inserting to DB  " & err.Message)
            UpdateRecord = False
        Finally
            conn.Close()
            cmd.Dispose()
        End Try

        Return UpdateRecord
    End Function

    Public Function UpdateStoredProcedurePassword(ByVal criteria As String, ByVal criteria2 As String, ByVal parameterName As String, ByVal parameterName2 As String, ByVal procedureName As String) As Boolean
        Dim UpdateRecord As Boolean
        Dim conn As New SqlConnection(ConnectionString)

        Dim cmd As New SqlCommand()
        Try

            cmd.Connection = conn
            cmd.CommandText = procedureName
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.Add(parameterName, SqlDbType.VarChar, 10).Value = criteria2
            cmd.Parameters.Add(parameterName2, SqlDbType.VarChar, 15).Value = criteria
            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            conn.Close()
            UpdateRecord = True
        Catch err As DataException
            Throw New ApplicationException("Error in inserting to DB  " & err.Message)
            UpdateRecord = False
        Finally
            conn.Close()
            cmd.Dispose()
        End Try

        Return UpdateRecord
    End Function

    Public Function UpdateReasonToDeactivate(ByVal UserID As String, ByVal Reason As String) As Boolean
        Dim UpdateRecord As Boolean
        Dim conn As New SqlConnection(ConnectionString)

        Dim cmd As New SqlCommand()
        Try

            cmd.Connection = conn
            cmd.CommandText = "sp_updateReasonToActivateNDeactivate"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.Add("@user_id", SqlDbType.VarChar, 10).Value = UserID
            cmd.Parameters.Add("@criteria", SqlDbType.VarChar, 50).Value = Reason
            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            conn.Close()
            UpdateRecord = True
        Catch err As DataException
            Throw New ApplicationException("Error in inserting to DB  " & err.Message)
            UpdateRecord = False
        Finally
            conn.Close()
            cmd.Dispose()
        End Try

        Return UpdateRecord
    End Function

    Public Function UpdateStandardInvoice(ByVal InvoiceNo As String, ByVal customerName As String, ByVal productName As String, ByVal amount As String, ByVal paymentMode As String) As Boolean
        Dim UpdateRecord As Boolean
        Dim conn As New SqlConnection(ConnectionString)

        Dim cmd As New SqlCommand()
        Try

            cmd.Connection = conn
            cmd.CommandText = "sp_updateStandardInvoice"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.Add("@invoice_no", SqlDbType.VarChar, 10).Value = InvoiceNo
            cmd.Parameters.Add("@amount", SqlDbType.Money).Value = Convert.ToDecimal(amount)
            cmd.Parameters.Add("@product", SqlDbType.VarChar, 30).Value = productName
            cmd.Parameters.Add("@customer", SqlDbType.VarChar, 35).Value = customerName
            cmd.Parameters.Add("@paymentmode", SqlDbType.VarChar, 11).Value = paymentMode
            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            conn.Close()
            UpdateRecord = True
        Catch err As DataException
            Throw New ApplicationException("Error in inserting to DB  " & err.Message)
            UpdateRecord = False
        Finally
            conn.Close()
            cmd.Dispose()
        End Try

        Return UpdateRecord
    End Function

    Public Function UpdateUserBasicDetails(ByVal UserID As String, ByVal UserName As String, ByVal Status As String, ByVal UserType As String, ByVal firstName As String, ByVal lastName As String, ByVal profession As String, ByVal email As String, ByVal phone_num As String, ByVal AllotedSize As String, ByVal CustomerName As String, ByVal Address1 As String, ByVal Address2 As String, ByVal City As String, ByVal State As String, ByVal PostalCode As String, ByVal Country As String, ByVal FaxNum As String) As Boolean
        Dim UpdateRecord As Boolean
        Dim conn As New SqlConnection(ConnectionString)

        Dim cmd As New SqlCommand()
        Try

            cmd.Connection = conn
            cmd.CommandText = "sp_UpdateUserBasicDetails"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.Add("@userid", SqlDbType.VarChar, 10).Value = UserID
            cmd.Parameters.Add("@username", SqlDbType.VarChar, 20).Value = UserName
            cmd.Parameters.Add("@status", SqlDbType.VarChar, 10).Value = Status
            cmd.Parameters.Add("@usertype", SqlDbType.VarChar, 10).Value = UserType
            cmd.Parameters.Add("@firstname", SqlDbType.VarChar, 35).Value = firstName
            cmd.Parameters.Add("@lastname", SqlDbType.VarChar, 35).Value = lastName
            cmd.Parameters.Add("@profession", SqlDbType.VarChar, 35).Value = profession
            cmd.Parameters.Add("@email", SqlDbType.VarChar, 35).Value = email
            cmd.Parameters.Add("@telno", SqlDbType.VarChar, 18).Value = phone_num
            cmd.Parameters.Add("@asize", SqlDbType.VarChar, 25).Value = AllotedSize
            cmd.Parameters.Add("@customername", SqlDbType.VarChar, 35).Value = CustomerName
            cmd.Parameters.Add("@address1", SqlDbType.VarChar, 35).Value = Address1
            cmd.Parameters.Add("@address2", SqlDbType.VarChar, 35).Value = Address2
            cmd.Parameters.Add("@city", SqlDbType.VarChar, 35).Value = City
            cmd.Parameters.Add("@state", SqlDbType.VarChar, 35).Value = State
            cmd.Parameters.Add("@postalcode", SqlDbType.VarChar, 35).Value = PostalCode
            cmd.Parameters.Add("@country", SqlDbType.VarChar, 35).Value = Country
            cmd.Parameters.Add("@faxno", SqlDbType.VarChar, 18).Value = FaxNum
            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            conn.Close()
            UpdateRecord = True
        Catch err As DataException
            Throw New ApplicationException("Error in inserting to DB  " & err.Message)
            UpdateRecord = False
        Finally
            conn.Close()
            cmd.Dispose()
        End Try

        Return UpdateRecord
    End Function

    Public Function UpdateUserAdvancedDetails(ByVal ReceiptNum As String, ByVal remarks As String) As Boolean
        Dim UpdateRecord As Boolean
        Dim conn As New SqlConnection(ConnectionString)

        Dim cmd As New SqlCommand()
        Try

            cmd.Connection = conn
            cmd.CommandText = "sp_UpdateUserAdvancedDetails"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.Add("@receiptNum", SqlDbType.VarChar, 10).Value = ReceiptNum
            cmd.Parameters.Add("@remarks", SqlDbType.VarChar, 50).Value = remarks

            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            conn.Close()
            UpdateRecord = True
        Catch err As DataException
            Throw New ApplicationException("Error in inserting to DB  " & err.Message)
            UpdateRecord = False
        Finally
            conn.Close()
            cmd.Dispose()
        End Try

        Return UpdateRecord
    End Function

    Public Function RenewAccount(ByVal UserID As String, ByVal ExpiryDate As Date, ByVal AccountType As String, ByVal PaymentMode As String, ByVal InvoiceNum As Integer, ByVal chequeDate As Date, ByVal comments As String) As Boolean
        Dim UpdateRecord As Boolean
        Dim conn As New SqlConnection(ConnectionString)

        Dim cmd As New SqlCommand()
        Try

            cmd.Connection = conn
            cmd.CommandText = "sp_RenewAccount"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.Add("@userid", SqlDbType.VarChar, 10).Value = UserID
            cmd.Parameters.Add("@expiry_date", SqlDbType.Date).Value = ExpiryDate
            cmd.Parameters.Add("@acct_type", SqlDbType.VarChar, 10).Value = AccountType
            cmd.Parameters.Add("@paymode", SqlDbType.VarChar, 11).Value = PaymentMode
            cmd.Parameters.Add("@invoice_num", SqlDbType.Int).Value = InvoiceNum
            cmd.Parameters.Add("@chequedate", SqlDbType.Date).Value = chequeDate
            cmd.Parameters.Add("@comments", SqlDbType.VarChar, 50).Value = comments
            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            conn.Close()
            UpdateRecord = True
        Catch err As DataException
            Throw New ApplicationException("Error in inserting to DB  " & err.Message)
            UpdateRecord = False
        Finally
            conn.Close()
            cmd.Dispose()
        End Try

        Return UpdateRecord
    End Function

    Public Function UpdateAdminPassword(ByVal Password As String, ByVal UserName As String) As Boolean
        Dim UpdateRecord As Boolean
        Dim conn As New SqlConnection(ConnectionString)

        Dim cmd As New SqlCommand()
        Try

            cmd.Connection = conn
            cmd.CommandText = "sp_UpdateAdminPassword"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.Add("@password", SqlDbType.VarChar, 10).Value = Password
            cmd.Parameters.Add("@UserName", SqlDbType.VarChar, 15).Value = UserName

            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            conn.Close()
            UpdateRecord = True
        Catch err As DataException
            Throw New ApplicationException("Error in inserting to DB  " & err.Message)
            UpdateRecord = False
        Finally
            conn.Close()
            cmd.Dispose()
        End Try

        Return UpdateRecord
    End Function

    Public Function CancelInvoice(ByVal InvoiceNo As String) As Boolean
        Dim UpdateRecord As Boolean
        Dim conn As New SqlConnection(ConnectionString)

        Dim cmd As New SqlCommand()
        Try

            cmd.Connection = conn
            cmd.CommandText = "sp_CancelInvoice"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.Add("@invoice_no", SqlDbType.VarChar, 10).Value = InvoiceNo

            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            conn.Close()
            UpdateRecord = True
        Catch err As DataException
            Throw New ApplicationException("Error in inserting to DB  " & err.Message)
            UpdateRecord = False
        Finally
            conn.Close()
            cmd.Dispose()
        End Try

        Return UpdateRecord
    End Function

    Public Function InsertGroupUserForMaster(ByVal customerName As String, ByVal address As String, ByVal address2 As String, ByVal city As String, ByVal state As String, ByVal postalcode As String, ByVal country As String, ByVal phone_num As String, ByVal fax_num As String, ByVal first_name As String, ByVal last_name As String, ByVal position As String, ByVal tel_num As String, ByVal asize As String, ByVal account_type As String, ByVal accountID As String, ByVal AccountExpiry As Date, ByVal Site_Name As String) As Boolean
        Dim InsertRecord As Boolean
        Dim conn As New SqlConnection(ConnectionString)

        Dim cmd As New SqlCommand()
        Try

            cmd.Connection = conn
            cmd.CommandText = "sp_insertGroupUserForMaster"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.Add("@customerName", SqlDbType.VarChar, 35).Value = customerName
            cmd.Parameters.Add("@address1", SqlDbType.VarChar, 35).Value = address
            cmd.Parameters.Add("@address2", SqlDbType.VarChar, 35).Value = address2
            cmd.Parameters.Add("@city", SqlDbType.VarChar, 35).Value = city
            cmd.Parameters.Add("@state", SqlDbType.VarChar, 35).Value = state
            cmd.Parameters.Add("@postalcode", SqlDbType.VarChar, 35).Value = postalcode
            cmd.Parameters.Add("@country", SqlDbType.VarChar, 35).Value = country
            cmd.Parameters.Add("@phonenum", SqlDbType.VarChar, 18).Value = phone_num
            cmd.Parameters.Add("@faxnum", SqlDbType.VarChar, 18).Value = fax_num
            cmd.Parameters.Add("@firstname", SqlDbType.VarChar, 35).Value = first_name
            cmd.Parameters.Add("@lastname", SqlDbType.VarChar, 35).Value = last_name
            cmd.Parameters.Add("@position", SqlDbType.VarChar, 35).Value = position
            cmd.Parameters.Add("@telnum", SqlDbType.VarChar, 18).Value = tel_num
            cmd.Parameters.Add("@asize", SqlDbType.VarChar, 25).Value = asize
            cmd.Parameters.Add("@accttype", SqlDbType.VarChar, 10).Value = account_type
            cmd.Parameters.Add("@accountID", SqlDbType.VarChar, 10).Value = accountID
            cmd.Parameters.Add("@expiry_date", SqlDbType.DateTime).Value = AccountExpiry
            cmd.Parameters.Add("@SiteName", SqlDbType.VarChar, 50).Value = Site_Name
            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            conn.Close()
            InsertRecord = True
        Catch err As DataException
            Throw New ApplicationException("Error in inserting to DB  " & err.Message)
            InsertRecord = False
        Finally
            conn.Close()
            cmd.Dispose()
        End Try

        Return InsertRecord
    End Function

    Public Function UpdateInvoice(ByVal invoiceNum As Integer, ByVal customerID As String, ByVal discount As Decimal, ByVal amount As Decimal, ByVal totalAmount As Decimal, ByVal adminName As String) As Boolean
        Dim UpdateRecord As Boolean
        Dim conn As New SqlConnection(ConnectionString)

        Dim Query As String = "update Invoice set CustomerID=@cid, IDate=GETDATE(), Amount = @amount, DiscountFactor = @discount, TotalAmount = @totalamount, Status = 'Active',CreatedStaff=@admin where InvoiceNo=@invno"
        Dim cmd As New SqlCommand(Query, conn)
        Try

            cmd.Parameters.Add("@cid", SqlDbType.VarChar, 10).Value = customerID
            cmd.Parameters.Add("@amount", SqlDbType.Money).Value = amount
            Dim spm As SqlParameter = cmd.Parameters.Add("@discount", SqlDbType.Float)
            spm.Value = discount
            'spm.Precision = 4
            'spm.Scale = 2
            cmd.Parameters.Add("@totalamount", SqlDbType.Money).Value = totalAmount
            cmd.Parameters.Add("@admin", SqlDbType.VarChar, 10).Value = adminName
            cmd.Parameters.Add("@invno", SqlDbType.Int).Value = invoiceNum

            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            conn.Close()
            UpdateRecord = True
        Catch err As DataException
            Throw New ApplicationException("Error in inserting to DB  " & err.Message)
            UpdateRecord = False
        Finally
            conn.Close()
            cmd.Dispose()
        End Try

        Return UpdateRecord
    End Function

    Public Function UpdateInvoiceProduct(ByVal invoiceNum As Integer, ByVal newEventID As Integer, ByVal quantity As Integer, ByVal totalAmount As Decimal, ByVal adminName As String) As Boolean
        Dim UpdateRecord As Boolean
        Dim conn As New SqlConnection(ConnectionString)

        Dim Query As String = "update Admin_InvoiceProduct set ProductNo=@eid, Quantity=@quantity, TotalAmount = @totalamount,CreatedStaff=@admin where InvoiceNo=@invno"
        Dim cmd As New SqlCommand(Query, conn)
        Try

            cmd.Parameters.Add("@eid", SqlDbType.Int).Value = newEventID
            cmd.Parameters.Add("@quantity", SqlDbType.Int).Value = quantity

            cmd.Parameters.Add("@totalamount", SqlDbType.Money).Value = totalAmount
            cmd.Parameters.Add("@admin", SqlDbType.VarChar, 10).Value = adminName
            cmd.Parameters.Add("@invno", SqlDbType.BigInt).Value = invoiceNum


            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            conn.Close()
            UpdateRecord = True
        Catch err As DataException
            Throw New ApplicationException("Error in inserting to DB  " & err.Message)
            UpdateRecord = False
        Finally
            conn.Close()
            cmd.Dispose()
        End Try

        Return UpdateRecord
    End Function

    Public Function UpdatePayment(ByVal cpNum As Integer, ByVal payMode As String, ByVal adminName As String) As Boolean
        Dim UpdateRecord As Boolean
        Dim conn As New SqlConnection(ConnectionString)

        Dim Query As String = "update Admin_Payment set PDate=GETDATE(), AmountPaid=0.00,From_Of_Payment=@paymode,CardNo='',CreditBankName='',CC_Expiry_Date='1/1/1900',ChequeNo='',ChequeBankName='',ChequeDate=GETDATE(),Status='Unpaid',CreatedStaff=@admin where CusPayNo=@cpn"
        Dim cmd As New SqlCommand(Query, conn)
        Try

            cmd.Parameters.Add("@paymode", SqlDbType.VarChar, 11).Value = payMode
            cmd.Parameters.Add("@admin", SqlDbType.VarChar, 10).Value = adminName
            cmd.Parameters.Add("@cpn", SqlDbType.Int).Value = cpNum


            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            conn.Close()
            UpdateRecord = True
        Catch err As DataException
            Throw New ApplicationException("Error in inserting to DB  " & err.Message)
            UpdateRecord = False
        Finally
            conn.Close()
            cmd.Dispose()
        End Try

        Return UpdateRecord
    End Function

    Public Function UpdatePaymentMaster(ByVal invoiceNum As Integer, ByVal payType As String, ByVal totalAmount As Decimal, ByVal adminName As String) As Boolean
        Dim UpdateRecord As Boolean
        Dim conn As New SqlConnection(ConnectionString)

        Dim Query As String = "update Admin_PaymentMaster set IDate=GETDATE(), PayType=@paytype, TotalAmount = @totalamount,DownPayment=0.00,Balance_Invoice=@totalamount,Status='Unpaid',CreatedStaff=@admin where InvoiceNo=@invno"
        Dim cmd As New SqlCommand(Query, conn)
        Try

            cmd.Parameters.Add("@paytype", SqlDbType.VarChar, 10).Value = payType

            cmd.Parameters.Add("@totalamount", SqlDbType.Money).Value = totalAmount
            cmd.Parameters.Add("@admin", SqlDbType.VarChar, 10).Value = adminName
            cmd.Parameters.Add("@invno", SqlDbType.Int).Value = invoiceNum


            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            conn.Close()
            UpdateRecord = True
        Catch err As DataException
            Throw New ApplicationException("Error in inserting to DB  " & err.Message)
            UpdateRecord = False
        Finally
            conn.Close()
            cmd.Dispose()
        End Try

        Return UpdateRecord
    End Function

    Public Function UpdateGroupNameAndEmailForMaster(ByVal groupName As String, ByVal emailID As String) As Boolean
        Dim UpdateRecord As Boolean
        Dim conn As New SqlConnection(ConnectionString)

        Dim cmd As New SqlCommand()
        Try

            cmd.Connection = conn
            cmd.CommandText = "sp_UpdateGroupNameAndEmailForMaster"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.Add("@gname", SqlDbType.VarChar, 100).Value = groupName
            cmd.Parameters.Add("@emailid", SqlDbType.VarChar, 100).Value = emailID

            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            conn.Close()
            UpdateRecord = True
        Catch err As DataException
            Throw New ApplicationException("Error in inserting to DB  " & err.Message)
            UpdateRecord = False
        Finally
            conn.Close()
            cmd.Dispose()
        End Try

        Return UpdateRecord
    End Function

    Private Sub myErrorHandler(ByVal Err As Exception)
        Throw New ApplicationException("Error is..  " & Err.Message)
    End Sub
    Public Function ExtendSubscribe(ByVal userid As String, ByVal expired As Date) As Boolean
        Dim UpdateRecord As Boolean
        Dim conn As New SqlConnection(ConnectionString)

        Dim cmd As New SqlCommand()
        Try

            cmd.Connection = conn
            cmd.CommandText = "sp_ExtendSubscribe"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.Add("@userid", SqlDbType.VarChar, 10).Value = userid
            cmd.Parameters.Add("@expiry_date", SqlDbType.Date).Value = expired

            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            conn.Close()
            UpdateRecord = True
        Catch err As DataException
            Throw New ApplicationException("Error in inserting to DB  " & err.Message)
            UpdateRecord = False
        Finally
            conn.Close()
            cmd.Dispose()
        End Try

        Return UpdateRecord
    End Function

    Function CheckInvoiceStatus(ByVal UserId As String) As Boolean
        Dim Status As Boolean = False
        Dim StoreVar As String = ""
        Dim Query As String = "select  top 1  ap.Status,ap.InvoiceNo from Invoice as i ,Admin_PaymentMaster as ap where CustomerID=@userID and i.InvoiceNo=ap.InvoiceNo order by ap.InvoiceNo desc"
        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd = New SqlCommand(Query, conn)
        cmd.Parameters.AddWithValue("@userID", UserId)
        Dim mysqlreader As SqlDataReader
        Try
            conn.Open()
            mysqlreader = cmd.ExecuteReader()
            While mysqlreader.Read
                StoreVar = mysqlreader("Status").ToString()
            End While
            If StoreVar = "Paid" Or StoreVar = "paid" Then
                Status = True
            Else
                Status = False
            End If
        Catch ex As Exception
            Status = False
        Finally
            conn.Dispose()
            conn.Close()
            StoreVar = ""
        End Try
        Return Status
    End Function

#Region "Update User "
    Function CheckUserNameExist(ByVal UserName As String) As Boolean
        Dim Status As Boolean = False
        Dim StoreVar As String = ""
        Dim Query As String = "Select USER_NAME,Password,Email_ID from master_users where USER_NAME=@UserName"
        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd = New SqlCommand(Query, conn)
        cmd.Parameters.AddWithValue("@UserName", UserName)
        Dim mysqlreader As SqlDataReader
        Try
            conn.Open()
            mysqlreader = cmd.ExecuteReader()
            While mysqlreader.Read
                StoreVar = mysqlreader("USER_NAME").ToString()
            End While
            If StoreVar = "Paid" Or StoreVar = "paid" Then
                Status = True
            Else
                Status = False
            End If
        Catch ex As Exception
            Status = False
        Finally
            conn.Dispose()
            conn.Close()
            StoreVar = ""
        End Try
        Return Status
    End Function
    'Public Function SearchUserName(ByVal UserName As String, ByVal SiteName As String) As DataTable
    Public Function SearchUserName(ByVal UserName As String) As DataTable
        Dim DT As New DataTable()

        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand()

        Try
            cmd.Connection = conn
            cmd.CommandText = "sp_GetUserInfo"
            cmd.CommandType = CommandType.StoredProcedure

            cmd.Parameters.Add(New SqlParameter("@USER_NAME", SqlDbType.VarChar)).Value = UserName
            ' cmd.Parameters.Add(New SqlParameter("@SiteName", SqlDbType.VarChar)).Value = SiteName


            conn.Open()
            cmd.ExecuteNonQuery()

            Dim adapter As New SqlDataAdapter(cmd)

            adapter.Fill(DT)
            conn.Close()
        Catch err As Exception
            Dim msg1 As String = Err.Message
            '            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally
            conn.Close()
            conn.Dispose()
            cmd.Dispose()
        End Try

        Return DT
    End Function
    'Public Function SearchUserEmail(ByVal Email As String, ByVal SiteName As String) As DataTable
    Public Function SearchUserEmail(ByVal Email As String) As DataTable
        Dim DT As New DataTable()

        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand()

        Try
            cmd.Connection = conn
            cmd.CommandText = "sp_GetUserEmail"
            cmd.CommandType = CommandType.StoredProcedure

            cmd.Parameters.Add(New SqlParameter("@Email", SqlDbType.VarChar)).Value = Email
            ' cmd.Parameters.Add(New SqlParameter("@SiteName", SqlDbType.VarChar)).Value = SiteName

            conn.Open()
            cmd.ExecuteNonQuery()

            Dim adapter As New SqlDataAdapter(cmd)

            adapter.Fill(DT)
            conn.Close()
        Catch err As Exception
            Dim msg1 As String = Err.Message
            '            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally
            conn.Close()
            conn.Dispose()
            cmd.Dispose()
        End Try

        Return DT
    End Function

    Public Function SearchUserName() As DataTable
        Dim DT As New DataTable()

        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand()

        Try
            cmd.Connection = conn
            cmd.CommandText = "sp_GetAllSubscribeUsers"
            cmd.CommandType = CommandType.StoredProcedure
            conn.Open()
            cmd.ExecuteNonQuery()

            Dim adapter As New SqlDataAdapter(cmd)

            adapter.Fill(DT)
            conn.Close()
        Catch err As Exception
            Dim msg1 As String = err.Message
        Finally
            conn.Close()
            conn.Dispose()
            cmd.Dispose()
        End Try

        Return DT
    End Function

    Public Function SerachSubscribeUser(ByVal s_Module As String) As DataTable
        Dim DT As New DataTable()

        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand()

        Try
            cmd.Connection = conn
            cmd.CommandText = "sp_SearchExpiryDetails"
            cmd.CommandType = CommandType.StoredProcedure

            cmd.Parameters.Add(New SqlParameter("@Module", SqlDbType.VarChar)).Value = s_Module

            conn.Open()
            cmd.ExecuteNonQuery()

            Dim adapter As New SqlDataAdapter(cmd)

            adapter.Fill(DT)
            conn.Close()
        Catch err As Exception
            Dim msg1 As String = err.Message
            '            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally
            conn.Close()
            conn.Dispose()
            cmd.Dispose()
        End Try

        Return DT
    End Function


    Public Function GetUserInfo(ByVal UserID As String) As DataTable
        Dim DT As New DataTable()

        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand()

        Try
            cmd.Connection = conn
            cmd.CommandText = "sp_GetAllUser"
            cmd.CommandType = CommandType.StoredProcedure

            cmd.Parameters.Add(New SqlParameter("@UserID", SqlDbType.Int)).Value = UserID
            conn.Open()
            cmd.ExecuteNonQuery()

            Dim adapter As New SqlDataAdapter(cmd)

            adapter.Fill(DT)
            conn.Close()
        Catch err As Exception
            Dim msg1 As String = err.Message
            '            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally
            conn.Close()
            conn.Dispose()
            cmd.Dispose()
        End Try

        Return DT
    End Function

    Public Function CheckUserName(ByVal UserName As String) As Boolean
        Dim Status As Boolean = False
        Dim s_username As String = ""
        Dim Query As String = "Select User_Name , Password from maser_users where User_Name =@UserName"
        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd = New SqlCommand(Query, conn)
        cmd.Parameters.AddWithValue("@UserName", UserName)
        Dim mysqlreader As SqlDataReader
        Try
            conn.Open()
            mysqlreader = cmd.ExecuteReader()
            While mysqlreader.Read
                s_username = mysqlreader("USER_NAME").ToString()
            End While
            If s_username <> "" Then
                Status = True
            Else
                Status = False
            End If
        Catch ex As Exception
            Status = False
        Finally
            conn.Dispose()
            conn.Close()
            s_username = ""
        End Try
        Return Status
    End Function

    'Public Function UpdateMasterUserTable(ByVal UserName As String, ByVal UserID As String, ByVal AccountID As String, ByVal Password As String, ByVal AccessType As String, ByVal AccountType As String, ByVal blStatus As String, ByVal Address As String, ByVal Phone As String, ByVal accountExpiry As Date, ByVal FirmName As String, ByVal SiteName As String, ByVal FirstName As String, ByVal Address2 As String, ByVal City As String, ByVal State As String, ByVal PostalCode As String) As Boolean

    '    Dim conn As New SqlConnection(ConnectionString)
    '    Dim cmd As New SqlCommand()
    '    Dim UpdateRecord As Boolean
    '    Try
    '        cmd.Connection = conn
    '        cmd.CommandText = "sp_UpdateUserInfo"
    '        cmd.CommandType = CommandType.StoredProcedure

    '        cmd.Parameters.Add(New SqlParameter("@UserID", SqlDbType.VarChar)).Value = UserID
    '        cmd.Parameters.Add(New SqlParameter("@User_Name", SqlDbType.VarChar)).Value = UserName
    '        cmd.Parameters.Add(New SqlParameter("@AccountID", SqlDbType.VarChar)).Value = AccountID
    '        cmd.Parameters.Add(New SqlParameter("@Password", SqlDbType.VarChar)).Value = Password
    '        cmd.Parameters.Add(New SqlParameter("@Access_Type", SqlDbType.VarChar)).Value = AccessType
    '        cmd.Parameters.Add(New SqlParameter("@Acct_Type", SqlDbType.VarChar)).Value = AccountType
    '        cmd.Parameters.Add(New SqlParameter("@Status", SqlDbType.VarChar)).Value = blStatus
    '        cmd.Parameters.Add(New SqlParameter("@Address", SqlDbType.VarChar)).Value = Address
    '        cmd.Parameters.Add(New SqlParameter("@Phone", SqlDbType.VarChar)).Value = Phone
    '        cmd.Parameters.Add(New SqlParameter("@Acct_Expiry", SqlDbType.DateTime)).Value = accountExpiry
    '        cmd.Parameters.Add(New SqlParameter("@Firm_Name", SqlDbType.VarChar)).Value = FirmName
    '        cmd.Parameters.Add(New SqlParameter("@FirstName", SqlDbType.VarChar)).Value = FirstName

    '        cmd.Parameters.Add(New SqlParameter("@Address2", SqlDbType.VarChar)).Value = Address2
    '        cmd.Parameters.Add(New SqlParameter("@City", SqlDbType.DateTime)).Value = City
    '        cmd.Parameters.Add(New SqlParameter("@State", SqlDbType.VarChar)).Value = State
    '        cmd.Parameters.Add(New SqlParameter("@PostalCode", SqlDbType.VarChar)).Value = PostalCode


    '        conn.Open()
    '        cmd.ExecuteNonQuery()

    '        UpdateRecord = True
    '        conn.Close()
    '    Catch err As Exception
    '        Dim msg1 As String = err.Message
    '        UpdateRecord = False

    '    Finally
    '        conn.Close()
    '        conn.Dispose()
    '        cmd.Dispose()
    '    End Try


    'End Function


    Public Function UpdateMasterUserTable(ByVal UserName As String, ByVal UserID As String, ByVal AccountID As String, ByVal Password As String, ByVal AccessType As String, ByVal AccountType As String, ByVal blStatus As String, ByVal Address As String, ByVal Phone As String, ByVal accountExpiry As String, ByVal FirmName As String, ByVal SiteName As String, ByVal FirstName As String, ByVal LastName As String, ByVal Address2 As String, ByVal City As String, ByVal State As String, ByVal PostalCode As String, ByVal NoOfAllowedUser As Int32, ByVal accountRegistration As String, ByVal EmailId As String) As Boolean
        'Public Function UpdateMasterUserTable(ByVal UserName As String, ByVal UserID As String, ByVal AccountID As String, ByVal Password As String, ByVal AccessType As String, ByVal AccountType As String, ByVal blStatus As String, ByVal Address As String, ByVal Phone As String, ByVal FirmName As String, ByVal SiteName As String, ByVal FirstName As String, ByVal Address2 As String, ByVal City As String, ByVal State As String, ByVal PostalCode As String) As Boolean

        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand()
        Dim UpdateRecord As Boolean
        Try
            cmd.Connection = conn
            cmd.CommandText = "sp_UpdateUserInfo"
            cmd.CommandType = CommandType.StoredProcedure

            'accountExpiry.ToString().Replace("#", "")

            cmd.Parameters.Add(New SqlParameter("@UserID", SqlDbType.VarChar)).Value = UserID
            cmd.Parameters.Add(New SqlParameter("@User_Name", SqlDbType.VarChar)).Value = UserName
            cmd.Parameters.Add(New SqlParameter("@AccountID", SqlDbType.VarChar)).Value = AccountID
            cmd.Parameters.Add(New SqlParameter("@Password", SqlDbType.VarChar)).Value = Password
            cmd.Parameters.Add(New SqlParameter("@Access_Type", SqlDbType.VarChar)).Value = AccessType
            cmd.Parameters.Add(New SqlParameter("@Acct_Type", SqlDbType.VarChar)).Value = AccountType
            cmd.Parameters.Add(New SqlParameter("@Status", SqlDbType.VarChar)).Value = blStatus
            cmd.Parameters.Add(New SqlParameter("@Address", SqlDbType.VarChar)).Value = Address
            cmd.Parameters.Add(New SqlParameter("@Phone", SqlDbType.VarChar)).Value = Phone
            cmd.Parameters.Add(New SqlParameter("@Acct_Expiry", SqlDbType.Date)).Value = accountExpiry
            cmd.Parameters.Add(New SqlParameter("@Firm_Name", SqlDbType.VarChar)).Value = FirmName
            cmd.Parameters.Add(New SqlParameter("@FirstName", SqlDbType.VarChar)).Value = FirstName
            cmd.Parameters.Add(New SqlParameter("@LastName", SqlDbType.VarChar)).Value = LastName

            cmd.Parameters.Add(New SqlParameter("@Address2", SqlDbType.VarChar)).Value = Address2
            cmd.Parameters.Add(New SqlParameter("@City", SqlDbType.VarChar)).Value = City
            cmd.Parameters.Add(New SqlParameter("@State", SqlDbType.VarChar)).Value = State
            cmd.Parameters.Add(New SqlParameter("@PostalCode", SqlDbType.VarChar)).Value = PostalCode
            cmd.Parameters.Add(New SqlParameter("@No_Of_Users", SqlDbType.VarChar)).Value = NoOfAllowedUser
            cmd.Parameters.Add(New SqlParameter("@Registration_date", SqlDbType.Date)).Value = accountRegistration
            cmd.Parameters.Add(New SqlParameter("@EmailId", SqlDbType.VarChar)).Value = EmailId

            conn.Open()
            cmd.ExecuteNonQuery()

            UpdateRecord = True
            conn.Close()
        Catch err As Exception
            Dim msg1 As String = err.Message
            UpdateRecord = False

        Finally
            conn.Close()
            conn.Dispose()
            cmd.Dispose()
        End Try


    End Function


    Function GetAccountID(ByVal UserID As String) As String

        Dim StoreVar As String = ""
        Dim Query As String = "Select AccountID,UserName from Admin_Users where UserNo =@UserNo"
        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd = New SqlCommand(Query, conn)
        cmd.Parameters.AddWithValue("@UserNo", UserID)
        Dim mysqlreader As SqlDataReader
        Try
            conn.Open()
            mysqlreader = cmd.ExecuteReader()
            While mysqlreader.Read
                StoreVar = mysqlreader("AccountID").ToString()
            End While

        Catch ex As Exception

        Finally
            conn.Dispose()
            conn.Close()

        End Try
        Return StoreVar
    End Function

    ''' <summary>
    ''' '''''''''''''''''''Changes 07-january-2015 shah
    ''' </summary>
    ''' <param name="UserName"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>

    Public Function GetEmail(ByVal UserName As String) As String
        Dim DT As New DataTable
        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand()
        Dim s_Email As String = ""

        Try
            cmd.CommandText = "sp_GetEmail"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Connection = conn
            cmd.Parameters.Add("@UserName", SqlDbType.VarChar, 50).Value = UserName
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)

            If Not DT Is Nothing Then
                s_Email = DT.Rows(0)("Email_ID").ToString()
            End If


        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally
            conn.Close()
        End Try

        Return s_Email
    End Function
    Public Function getmax_customer_id() As Integer

        Dim conn As New SqlConnection(ConnectionString)

        Dim _increas_id As Integer

        Try
            conn.Open()
            Dim SqlQuery As String = "SELECT TOP 1 CustomerID,id FROM Customer order by id desc"

            Dim MYcmd = New SqlCommand(SqlQuery, conn)

            Dim cmd = New SqlCommand(SqlQuery, conn)
            Dim mysqlreader As SqlDataReader


            mysqlreader = cmd.ExecuteReader()
            While mysqlreader.Read
                _increas_id = mysqlreader("id").ToString()
            End While
            _increas_id = _increas_id + 1

        Catch ex As Exception

        End Try
        conn.Close()
        Return _increas_id

    End Function

    Public Overloads Function DisplayBasicDetailsByUserNumber(ByVal UserName As String) As DataTable
        Dim DT As New DataTable
        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand()
        'Dim Reader1 As SqlClient.SqlDataReader
        Try
            cmd.CommandText = "sp_getBasicDetailsofInvoiceBasedOnUserNo"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Connection = conn
            cmd.Parameters.Add("@UserNo", SqlDbType.VarChar, 20).Value = UserName
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)


        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally
            conn.Close()
        End Try

        Return DT
    End Function
#End Region


    Public Function UpdateUserStatus(ByVal UserName As String) As Boolean

        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand()
        Dim UpdateRecord As Boolean
        Try
            cmd.Connection = conn
            cmd.CommandText = "sp_UpdateUserStatus"
            cmd.CommandType = CommandType.StoredProcedure

            cmd.Parameters.Add(New SqlParameter("@User_Name", SqlDbType.VarChar)).Value = UserName


            conn.Open()
            cmd.ExecuteNonQuery()

            UpdateRecord = True
            conn.Close()
        Catch err As Exception
            Dim msg1 As String = err.Message
            UpdateRecord = False

        Finally
            conn.Close()
            conn.Dispose()
            cmd.Dispose()
        End Try


    End Function
    Public Function UpdateSimultaneousConnection(ByVal UserName As String) As Boolean

        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand()
        Dim UpdateRecord As Boolean
        Try
            cmd.Connection = conn
            cmd.CommandText = "sp_UpdateUserConnection"
            cmd.CommandType = CommandType.StoredProcedure

            cmd.Parameters.Add(New SqlParameter("@User_Name", SqlDbType.VarChar)).Value = UserName


            conn.Open()
            cmd.ExecuteNonQuery()

            UpdateRecord = True
            conn.Close()
        Catch err As Exception
            Dim msg1 As String = err.Message
            UpdateRecord = False

        Finally
            conn.Close()
            conn.Dispose()
            cmd.Dispose()
        End Try


    End Function


    Public Function SearchCases(ByVal s_Title As String, ByVal s_Module As String) As DataTable
        Dim DT As New DataTable()

        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand()

        Try
            cmd.Connection = conn

            If s_Module = "CASES" Then
                cmd.CommandText = "sp_GetSelectedCase"

            Else
                cmd.CommandText = "sp_GetSelectedLegislation"
            End If

            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.Add("@Title", SqlDbType.VarChar, 8000).Value = s_Title

            conn.Open()
            cmd.ExecuteNonQuery()

            Dim adapter As New SqlDataAdapter(cmd)

            adapter.Fill(DT)
            conn.Close()
        Catch err As Exception
            Dim msg1 As String = err.Message
        Finally
            conn.Close()
            conn.Dispose()
            cmd.Dispose()
        End Try

        Return DT
    End Function

    Public Function UpdateSelectedCase(ByVal DataFileName As String) As Boolean
        Dim UpdateRecord As Boolean
        Dim conn As New SqlConnection(ConnectionString)

        Dim Query As String = "update cases set isSelectedCase = 1  where DataFileName= '" & DataFileName.Trim() & "'"
        Dim cmd As New SqlCommand(Query, conn)
        Try

            conn.Open()

            cmd.ExecuteNonQuery()

            conn.Close()
            UpdateRecord = True
        Catch err As DataException
            Throw New ApplicationException("Error in inserting to DB  " & err.Message)
            UpdateRecord = False
        Finally
            conn.Close()
            cmd.Dispose()
        End Try

        Return UpdateRecord
    End Function

    Public Function UpdateSelectedLegislation(ByVal DataFileName As String) As Boolean
        Dim UpdateRecord As Boolean
        Dim conn As New SqlConnection(ConnectionString)

        Dim Query As String = "update LEGISLATION set isSelectedLegislation = 1  where DataFileName= '" & DataFileName.Trim() & "'"
        Dim cmd As New SqlCommand(Query, conn)
        Try

            conn.Open()

            cmd.ExecuteNonQuery()

            conn.Close()
            UpdateRecord = True
        Catch err As DataException
            Throw New ApplicationException("Error in inserting to DB  " & err.Message)
            UpdateRecord = False
        Finally
            conn.Close()
            cmd.Dispose()
        End Try

        Return UpdateRecord
    End Function


    ''Update at 17-December-2017
    Public Function GetInvoiceDiscountAmount(ByVal InvoiceNo As String) As String

        Try

            Dim DT As New DataTable()
            Dim DiscountAmount As Integer = 0

            Dim conn As New SqlConnection(ConnectionString)
            Dim cmd As New SqlCommand()
            cmd.CommandText = "sp_GetDiscountAmount"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Connection = conn
            cmd.Parameters.Add(New SqlParameter("@InvoiceNo", SqlDbType.Int)).Value = InvoiceNo
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)

            If Not DT Is Nothing Then
                DiscountAmount = DT.Rows(0)("DiscountAmount").ToString()
            End If

            conn.Close()

            Return DiscountAmount
        Catch err As Exception
            Dim msg1 As String = err.Message
            Return ""

        End Try


    End Function

    Public Function UpdateDiscountAmount(ByVal InvoiceNo As String, ByVal DiscountAmount As String) As Boolean
        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand()
        Dim UpdateRecord As Boolean
        Try
            cmd.Connection = conn
            cmd.CommandText = "sp_UpdateInvoiceDiscount"
            cmd.CommandType = CommandType.StoredProcedure

            cmd.Parameters.Add(New SqlParameter("@DiscountAmount", SqlDbType.Money)).Value = DiscountAmount
            cmd.Parameters.Add(New SqlParameter("@InvoiceNo", SqlDbType.Int)).Value = InvoiceNo


            conn.Open()
            cmd.ExecuteNonQuery()

            UpdateRecord = True
            conn.Close()
        Catch err As Exception
            Dim msg1 As String = err.Message
            UpdateRecord = False

        Finally
            conn.Close()
            conn.Dispose()
            cmd.Dispose()
        End Try
    End Function




End Class

