'/********************************************************************/
'/*	Developer 	    : Usman Sarwar  								*/
'/*	Company     	: Mylawbox Sdn Bhd		    					*/
'/* Date Modified	: 25 july 2005          									*/  
'/*	Description		: Utility library                                               */
'/*	Version			: 1.0											*/
'/********************************************************************/


Imports System.Text.RegularExpressions


Namespace admin1


Public Class clsMyUtility

    Public Function refineSentence_old(ByVal sentence As String) As String

        sentence = Trim(LCase((sentence)))
        sentence = Replace(sentence, " of ", " ")
        sentence = Replace(sentence, " about ", " ")
        sentence = Replace(sentence, " is ", " ")
        sentence = Replace(sentence, " a ", " ")
        sentence = Replace(sentence, " an ", " ")
        sentence = Replace(sentence, "an ", " ")
        sentence = Replace(sentence, " the ", " ")
        sentence = Replace(sentence, " all ", " ")
        sentence = Replace(sentence, " from ", " ")
        sentence = Replace(sentence, " the ", " ")
        sentence = Replace(sentence, " to ", " ")
        sentence = Replace(sentence, " any ", " ")
        sentence = Replace(sentence, "+", "")
        sentence = Replace(sentence, "/", "")
        sentence = Replace(sentence, "*", "")
        sentence = Replace(sentence, "$", "")
        sentence = Replace(sentence, "^", "")
        sentence = Replace(sentence, "(", "")
        sentence = Replace(sentence, ")", "")
        sentence = Replace(sentence, "&", "")
        sentence = Replace(sentence, "@", "")
        sentence = Replace(sentence, "#", "")
        sentence = Replace(sentence, "!", "")
        sentence = Replace(sentence, "~", "")
        sentence = Replace(sentence, "%", "")
        sentence = Replace(sentence, ".", "")
        sentence = Replace(sentence, ",", "")
        sentence = Replace(sentence, "<", "")
        sentence = Replace(sentence, ">", "")
        sentence = Replace(sentence, "?", "")
        sentence = Replace(sentence, "\", "")
        sentence = Replace(sentence, "|", "")
        sentence = Replace(sentence, "=", "")
        sentence = Replace(sentence, "-", "")
        sentence = Replace(sentence, "_", "")
        sentence = Replace(sentence, ";", "")
        sentence = Replace(sentence, ":", "")

        '        Label1.Text = sentence
        Return sentence
    End Function

        Public Function refineNoice_wordsJudge(ByVal sentence As String) As String

            sentence = Trim(LCase((sentence)))
            sentence = Replace(sentence, " CJ", " ")
            sentence = Replace(sentence, " FJ", " ")
            sentence = Replace(sentence, " SCJJ", " ")
            sentence = Replace(sentence, " CJ Malaya", " ")
            sentence = Replace(sentence, " JCA", " ")
            sentence = Replace(sentence, " FCJJ", " ")
            sentence = Replace(sentence, " Ss CJ", "")
            sentence = Replace(sentence, " CJSS", "")
            sentence = Replace(sentence, "  J", " ")
            sentence = Replace(sentence, " A G CJ", " ")
            sentence = Replace(sentence, " Fjj", " ")
            sentence = Replace(sentence, " LP", " ")
            sentence = Replace(sentence, " FC", " ")
            sentence = Replace(sentence, " Fjj", " ")
            sentence = Replace(sentence, " LP J", "")
            sentence = Replace(sentence, " Ffj", "")
            sentence = Replace(sentence, " Fc", "")
            sentence = Replace(sentence, "Fc ", "")
            sentence = Replace(sentence, " Malaya CJ", "")
            sentence = Replace(sentence, ", &", ", ")
            sentence = Replace(sentence, " SCjj", " ")
            sentence = Replace(sentence, " Jr SCJ", "")
            sentence = Replace(sentence, " PCA", "")
            sentence = Replace(sentence, "  CJSS", "")
            sentence = Replace(sentence, " JCA", "")
            sentence = Replace(sentence, " CJSS", "")

            sentence = Replace(sentence, "  HMP", "")
            sentence = Replace(sentence, " Members:", "")
            sentence = Replace(sentence, " CJSS", "")
            sentence = Replace(sentence, "Kmn", "")
            sentence = Replace(sentence, "Sk", "")
            sentence = Replace(sentence, "Pkj", "")
            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

            sentence = Replace(sentence, "Abdul Aziz", "Abdul Aziz Mohamad")
            sentence = Replace(sentence, "Abdul Hamid", "Abdul Hamid Mohamad")
            sentence = Replace(sentence, "Abdul Hamid Acting", "Abdul Hamid Mohamad")
            sentence = Replace(sentence, "Abdul Hamid Mohamed", "Abdul Hamid Mohamad")
            sentence = Replace(sentence, "Abdul Hamid Omar Omar", "Abdul Hamid Omar")
            sentence = Replace(sentence, "Abdul Malek Ahmad  Siti Norma Yaakob", "Abdul Malek Ahmad")
            sentence = Replace(sentence, "Ahmad Fairuz Denis Ong", "Ahmad Fairuz")
            sentence = Replace(sentence, "Alauddin Mohd Sherif", "Alauddin Mohd Sheriff")
            sentence = Replace(sentence, "Anuar Bin  Zainal Abidin", "Anuar Zainal Abidin")
            sentence = Replace(sentence, "Arifin Zakaria", "Ariffin Zakaria")
            sentence = Replace(sentence, "Barakbah Malaya", "Barakbah")
            sentence = Replace(sentence, "Chong Siew Fah", "Chong Siew Fai")
            sentence = Replace(sentence, "Dan Mohamed Yusoff", "Mohamed Yusoff")
            sentence = Replace(sentence, "Gill Malaya", "Gill")
            sentence = Replace(sentence, "Gunn Chit Tuan", "Gunn Chit Tuan")
            sentence = Replace(sentence, "Gunn Chittuan", "Gunn Chit Tuan")
            sentence = Replace(sentence, "Harun M Hashim", "Harun Hashim")
            sentence = Replace(sentence, "Harun Hashim and Mohamed Yusoff", "Harun Hashim")
            sentence = Replace(sentence, "Hashim A Yeop Sani", "Hashim Yeop Sani")
            sentence = Replace(sentence, "Hashim Yeop A San", "Hashim Yeop Sani")
            sentence = Replace(sentence, "Hashim Yusof", "Hashim Yusoff")
            sentence = Replace(sentence, "James C Y Foong", "James Foong")
            sentence = Replace(sentence, "james c y foong jjca", "James Foong")
            sentence = Replace(sentence, "Lee Hun", "Lee Hun Hoe")
            sentence = Replace(sentence, "Malaya Lee Hun Hoe", "Lee Hun Hoe")
            sentence = Replace(sentence, "Macintyre", "William Mcintyre")
            sentence = Replace(sentence, "Mcintyre", "William Mcintyre")
            sentence = Replace(sentence, "Mohamad Yusoff B Mohamed", "Mohamad Yusoff Mohamed")
            sentence = Replace(sentence, "Mohamed Dzaiddin", "Mohamed Dzaiddin Abdullah")
            sentence = Replace(sentence, "Mohamed Dzaiddin Hjabdullah", "Mohamed Dzaiddin Abdullah")
            sentence = Replace(sentence, "Mohamed Yusoff Jemuri Serjan", "Mohamed Yusoff")
            sentence = Replace(sentence, "Mohamed Yusoff Mohamed", "Mohamed Yusoff")
            sentence = Replace(sentence, "Mohd Azmi", "Mohd Azmi Kamaruddin")
            sentence = Replace(sentence, "Mohd Azmi Bin   Kamaruddin", "Mohd Azmi Kamaruddin")
            sentence = Replace(sentence, "Mohd AzmiKamaruddin", "Mohd Azmi Kamaruddin")
            sentence = Replace(sentence, "Mohd Ghazali Yusof", "Mohd Ghazali Yusoff")
            sentence = Replace(sentence, "Mohd Yusof Mohamed", "Mohd Yusoff Mohamed")
            sentence = Replace(sentence, "Mohd Yussoff Mohamed", "Mohd Yusoff Mohamed")
            sentence = Replace(sentence, "Murray", "Murray Aynsley")
            sentence = Replace(sentence, "Murray Aynsley Singapore", "Murray Aynsley")
            sentence = Replace(sentence, "Murray Aynstely", "Murray Aynsley")
            sentence = Replace(sentence, "n Union Murray Aynsely", "Murray Aynsley")
            sentence = Replace(sentence, "Nik Hashim", "Nik Hashim Nik Ab Rahman")
            sentence = Replace(sentence, "Ong", "Ong Hock Sim")
            sentence = Replace(sentence, "Ong Hock Sim Wan Suleiman", "Ong Hock Sim")
            sentence = Replace(sentence, "Ong Hock Sin", "Ong Hock Sim")
            sentence = Replace(sentence, "n Union Murray Aynsely", "Ong Hock Sim")
            sentence = Replace(sentence, "Ong Hock They", "Ong Hock Thye")
            sentence = Replace(sentence, "Ong J", "Ong Hock Thye")
            sentence = Replace(sentence, "Ong Malaya", "Ong Hock Thye")
            sentence = Replace(sentence, "Pretheroe  Federation Of Malaya", "Pretheroe")
            sentence = Replace(sentence, "Raja Azian Shah", "Raja Azlan Shah")
            sentence = Replace(sentence, "Raja Azlan", "Raja Azlan Shah")
            sentence = Replace(sentence, "Salleh Abas Abdul Hamid Omar", "Salleh Abas")
            sentence = Replace(sentence, "Syed il Barakabah", "Syed Al Barakbah")
            sentence = Replace(sentence, "Syed il Barakah", "Syed Al Barakbah")
            sentence = Replace(sentence, "Syed il Barakbah", "Syed Al Barakbah")
            sentence = Replace(sentence, "Syed Sheikh", "Syed Sheikh Barakbah")
            sentence = Replace(sentence, "Terrell Malaya Jordon Smith", "Terrell")
            sentence = Replace(sentence, "Thomson", "Thomas")
            sentence = Replace(sentence, "Wan Adnan", "Wan Adnan Ismail")
            sentence = Replace(sentence, "Wan Adnan Bin Ismail", "Wan Adnan Ismail")
            sentence = Replace(sentence, "Wan Adnan Ismail Ahmad Fairuz Denis Ong", "Wan Adnan Ismail")
            sentence = Replace(sentence, "Wan Sulaiman Acting", "Wan Sulaiman")
            sentence = Replace(sentence, "Wan Suleiman  Chang Min Tat", "Wan Sulaiman")
            sentence = Replace(sentence, "Wan Suleiman Actinzg", "Wan Sulaiman")
            sentence = Replace(sentence, "Wan SuleimanJ", "Wan Sulaiman")
            sentence = Replace(sentence, "Wan Sulelnum", "Wan Sulaiman")
            sentence = Replace(sentence, "Wan Yahya", "Wira Wan Yahya Pawan Teh")
            sentence = Replace(sentence, "Wan Yahya Pawan Teh", "Wira Wan Yahya Pawan Teh")
            sentence = Replace(sentence, "Wira Wan Yahya Pawan Teh Hma", "Wira Wan Yahya Pawan Teh")
            sentence = Replace(sentence, "Wira Wan Yahya Pawan The", "Wira Wan Yahya Pawan Teh")
            sentence = Replace(sentence, "Willan", "William")
            sentence = Replace(sentence, "Wylie Borneo", "Wylie")
            sentence = Replace(sentence, "Zakaria M Yatim", "Zakaria Mohamed Yatim")
            sentence = Replace(sentence, "Zakaria Yatim", "Zakaria Mohamed Yatim")
            sentence = Replace(sentence, "Zulkefli Makinuddin", "Zulkefli Ahmad Makinudin")
            sentence = Replace(sentence, "Zulkefli Makinudin", "Zulkefli Ahmad Makinudin")

            '        Label1.Text = sentence
            Return sentence
        End Function

    Public Function Refine_XML_File_Simple(ByVal sentence As String) As String
        Dim ReplacePattern As String = " "
        Dim SearchPattern As String

        sentence = Trim(LCase((sentence)))

        sentence = Refine_XML_Tags_Simple(sentence)

        sentence = Replace(sentence, Chr(34), " ") ' double quotes

        sentence = Replace(sentence, "'", "''") 'Replacing single quote as when i will insert into table it will give sql insert query error

        sentence = Replace(sentence, Chr(10), " ") ' new line
        sentence = Replace(sentence, Chr(13), " ") 'Carriage return

        sentence = Replace(sentence, "  ", " ")
        sentence = Replace(sentence, "   ", " ")
        sentence = Replace(sentence, "    ", " ")
        sentence = Replace(sentence, "     ", " ")
        sentence = Replace(sentence, "      ", " ")
        sentence = Replace(sentence, "       ", " ")
        sentence = Replace(sentence, "        ", " ")
        sentence = Replace(sentence, "         ", " ")
        sentence = Replace(sentence, "          ", " ")
        sentence = Replace(sentence, "           ", " ")


        Return sentence
    End Function


    Public Function Refine_XML_File(ByVal sentence As String) As String
        Dim ReplacePattern As String = " "
        Dim SearchPattern As String

        sentence = Trim(LCase((sentence)))

        sentence = Refine_XML_Tags(sentence)



        SearchPattern = "\bof\b"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bby\b"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bbe\b"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\babout\b"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bis\b"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)


        SearchPattern = "\bin\b"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\ban\b"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bam\b"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bas\b"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bthe\b"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\ball\b"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bfrom\b"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bfor\b"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bto\b"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\band\b"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bany\b"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bor\b"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bnot\b"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bxor\b"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bxnor\b"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bdid\b"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bdoes\b"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bdo\b"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bshall\b"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bare\b"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bwas\b"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bwere\b"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bthere\b"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\btheir\b"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bwe\b"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bthe\b"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bhe\b"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bshe\b"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bit\b"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bhad\b"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bhas\b"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bhave\b"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bto\b"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bthey\b"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bthose\b"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bthem\b"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bthen\b"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bthat\b"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bthis\b"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bthat\b"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bme\b"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bmy\b"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bus\b"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bshall\b"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bhis\b"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bhim\b"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bhad\b"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bmy\b"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bmine\b"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bnot\b"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bhave\b"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bwho\b"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bwith\b"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bwhat\b"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\byour\b"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\byou\b"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "-"
        sentence = Regex.Replace(sentence, SearchPattern, " ", RegexOptions.IgnoreCase)

        SearchPattern = "_"
        sentence = Regex.Replace(sentence, SearchPattern, " ", RegexOptions.IgnoreCase)

        SearchPattern = ";"
        sentence = Regex.Replace(sentence, SearchPattern, " ", RegexOptions.IgnoreCase)

        SearchPattern = ":"
        sentence = Regex.Replace(sentence, SearchPattern, " ", RegexOptions.IgnoreCase)

        Dim i As Int16
        For i = 65 To 90 '''include all English alphabets [A-Z,a-z] as its ignore case
            SearchPattern = "\b" & Chr(i) & "\b"
            sentence = Regex.Replace(sentence, SearchPattern, " ", RegexOptions.IgnoreCase)

        Next

        For i = 48 To 57 '''include [0-9] as its ignore case
            SearchPattern = "\b" & Chr(i) & "\b"
            sentence = Regex.Replace(sentence, SearchPattern, " ", RegexOptions.IgnoreCase)

        Next

        sentence = Replace(sentence, ")", " ")
        sentence = Replace(sentence, "[", " ")
        sentence = Replace(sentence, "]", " ")

        sentence = Replace(sentence, "{", " ")
        sentence = Replace(sentence, "}", " ")

        sentence = Replace(sentence, "(", " ")
        sentence = Replace(sentence, ")", " ")

        sentence = Replace(sentence, "<", " ")
        sentence = Replace(sentence, ">", " ")

        sentence = Replace(sentence, "?", " ")

        sentence = Replace(sentence, ".", " ")
        sentence = Replace(sentence, ",", " ")
        sentence = Replace(sentence, ";", " ")
        sentence = Replace(sentence, ":", " ")
        sentence = Replace(sentence, "/", " ")
        sentence = Replace(sentence, "\", " ")
        sentence = Replace(sentence, "|", " ")
        sentence = Replace(sentence, "-", " ")
        sentence = Replace(sentence, "_", " ")
        sentence = Replace(sentence, "=", " ")
        sentence = Replace(sentence, "+", " ")
        sentence = Replace(sentence, "@", " ")
        sentence = Replace(sentence, "!", " ")
        sentence = Replace(sentence, "*", " ")
        sentence = Replace(sentence, "`", " ")
        sentence = Replace(sentence, "'", " ")
        sentence = Replace(sentence, "#", " ")
        sentence = Replace(sentence, "$", " ")
        sentence = Replace(sentence, "%", " ")
        sentence = Replace(sentence, Chr(34), " ")

        sentence = Replace(sentence, Chr(10), " ")
        sentence = Replace(sentence, Chr(13), " ")

        sentence = Replace(sentence, "  ", " ")
        sentence = Replace(sentence, "   ", " ")
        sentence = Replace(sentence, "    ", " ")
        sentence = Replace(sentence, "     ", " ")
        sentence = Replace(sentence, "      ", " ")
        sentence = Replace(sentence, "       ", " ")
        sentence = Replace(sentence, "        ", " ")
        sentence = Replace(sentence, "         ", " ")
        sentence = Replace(sentence, "          ", " ")
        sentence = Replace(sentence, "           ", " ")


        SearchPattern = "\bmy\b"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bfs\b"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bpua\b"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bpub\b"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bpdf\b"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        Return sentence
    End Function


    Public Function Refine_XML_Tags_Simple(ByVal sentence As String) As String
        Dim ReplacePattern As String = " "
        Dim SearchPattern As String
        Dim Pattern As String


        If sentence = "" Or Len(sentence) = 0 Then
            Exit Function
        End If

        sentence = Replace(sentence, "<p>", " ", RegexOptions.IgnoreCase)
        sentence = Replace(sentence, "</p>", " ", RegexOptions.IgnoreCase)
        sentence = Replace(sentence, "<P>", " ", RegexOptions.IgnoreCase)
        sentence = Replace(sentence, "</P>", " ", RegexOptions.IgnoreCase)
        sentence = Replace(sentence, "<br>", " ", RegexOptions.IgnoreCase)
        sentence = Replace(sentence, "</br>", " ", RegexOptions.IgnoreCase)
        sentence = Replace(sentence, "<BR>", " ", RegexOptions.IgnoreCase)
        sentence = Replace(sentence, "</BR>", " ", RegexOptions.IgnoreCase)
        sentence = Replace(sentence, "<p>", " ", RegexOptions.IgnoreCase)
        sentence = Replace(sentence, "</p>", " ", RegexOptions.IgnoreCase)
        sentence = Replace(sentence, "<P>", " ", RegexOptions.IgnoreCase)
        sentence = Replace(sentence, "</P>", " ", RegexOptions.IgnoreCase)
        sentence = Replace(sentence, "<i>", " ", RegexOptions.IgnoreCase)
        sentence = Replace(sentence, "</i>", " ", RegexOptions.IgnoreCase)
        sentence = Replace(sentence, "<I>", " ", RegexOptions.IgnoreCase)
        sentence = Replace(sentence, "</I>", " ", RegexOptions.IgnoreCase)
        sentence = Replace(sentence, "<b>", " ", RegexOptions.IgnoreCase)
        sentence = Replace(sentence, "</b>", " ", RegexOptions.IgnoreCase)
        sentence = Replace(sentence, "<B>", " ", RegexOptions.IgnoreCase)
        sentence = Replace(sentence, "</B>", " ", RegexOptions.IgnoreCase)
        sentence = Replace(sentence, "<U>", " ", RegexOptions.IgnoreCase)
        sentence = Replace(sentence, "</U>", " ", RegexOptions.IgnoreCase)


        Pattern = "\b<LINK\w*\s*</LINK>\b"
        sentence = Regex.Replace(sentence, Pattern, " ", RegexOptions.IgnoreCase)

        SearchPattern = "<LINK HREF=" & Chr(34) & "headnoteresult.asp?"
        sentence = Regex.Replace(sentence, SearchPattern, " ", RegexOptions.IgnoreCase)

        SearchPattern = "</LINK>"
        sentence = Regex.Replace(sentence, SearchPattern, " ", RegexOptions.IgnoreCase)

        SearchPattern = "<LINK HREF=" & Chr(34) & "legislationsectiondisplayformat.asp?"
        sentence = Regex.Replace(sentence, SearchPattern, " ", RegexOptions.IgnoreCase)

        SearchPattern = "</LINK>"
        sentence = Regex.Replace(sentence, SearchPattern, " ", RegexOptions.IgnoreCase)


        sentence = Regex.Replace(sentence, "\b<CATCHWORDS>\b", " ", RegexOptions.IgnoreCase)
        sentence = Regex.Replace(sentence, "\b</CATCHWORDS>\b", " ", RegexOptions.IgnoreCase)

        sentence = Regex.Replace(sentence, "<CATCHWORDS>", " ", RegexOptions.IgnoreCase)
        sentence = Regex.Replace(sentence, "</CATCHWORDS>", " ", RegexOptions.IgnoreCase)

        sentence = Regex.Replace(sentence, "\b<SUBJECT>\b", " ", RegexOptions.IgnoreCase)
        sentence = Regex.Replace(sentence, "\b</SUBJECT>\b", " ", RegexOptions.IgnoreCase)

        sentence = Regex.Replace(sentence, "<subject>", " ", RegexOptions.IgnoreCase)
        sentence = Regex.Replace(sentence, "</subject>", " ", RegexOptions.IgnoreCase)

        sentence = Regex.Replace(sentence, "\b<MODULE>\b", " ", RegexOptions.IgnoreCase)
        sentence = Regex.Replace(sentence, "\b</MODULE>\b", " ", RegexOptions.IgnoreCase)


        sentence = Regex.Replace(sentence, "<MODULE>", " ", RegexOptions.IgnoreCase)
        sentence = Regex.Replace(sentence, "</MODULE>", " ", RegexOptions.IgnoreCase)

        sentence = Regex.Replace(sentence, "\b<COUNSEL>\b", " ", RegexOptions.IgnoreCase)
        sentence = Regex.Replace(sentence, "\b</COUNSEL>\b", " ", RegexOptions.IgnoreCase)

        sentence = Regex.Replace(sentence, "<COUNSEL>", " ", RegexOptions.IgnoreCase)
        sentence = Regex.Replace(sentence, "</COUNSEL>", " ", RegexOptions.IgnoreCase)

        sentence = Regex.Replace(sentence, "\b<VERDICT>\b", " ", RegexOptions.IgnoreCase)
        sentence = Regex.Replace(sentence, "\b</VERDICT>\b", " ", RegexOptions.IgnoreCase)

        sentence = Regex.Replace(sentence, "<VERDICT>", " ", RegexOptions.IgnoreCase)
        sentence = Regex.Replace(sentence, "</VERDICT>", " ", RegexOptions.IgnoreCase)

        sentence = Regex.Replace(sentence, "\b<EM>\b", " ", RegexOptions.IgnoreCase)
        sentence = Regex.Replace(sentence, "\b</EM>\b", " ", RegexOptions.IgnoreCase)

        sentence = Regex.Replace(sentence, "<em>", " ", RegexOptions.IgnoreCase)
        sentence = Regex.Replace(sentence, "</em>", " ", RegexOptions.IgnoreCase)

        sentence = Regex.Replace(sentence, "\b<LEGISLATIONREFERREDTO>\b", " ", RegexOptions.IgnoreCase)
        sentence = Regex.Replace(sentence, "\b</LEGISLATIONREFERREDTO>\b", " ", RegexOptions.IgnoreCase)

        sentence = Regex.Replace(sentence, "<LEGISLATIONREFERREDTO>", " ", RegexOptions.IgnoreCase)
        sentence = Regex.Replace(sentence, "</LEGISLATIONREFERREDTO>", " ", RegexOptions.IgnoreCase)

        sentence = Regex.Replace(sentence, "\b<CASESREFERREDTO>\b", " ", RegexOptions.IgnoreCase)
        sentence = Regex.Replace(sentence, "\b</CASESREFERREDTO>\b", " ", RegexOptions.IgnoreCase)

        sentence = Regex.Replace(sentence, "<CASESREFERREDTO>", " ", RegexOptions.IgnoreCase)
        sentence = Regex.Replace(sentence, "</CASESREFERREDTO>", " ", RegexOptions.IgnoreCase)

        sentence = Regex.Replace(sentence, "\b<OTHERSREFERREDTO>\b", " ", RegexOptions.IgnoreCase)
        sentence = Regex.Replace(sentence, "\b</OTHERSREFERREDTO>\b", " ", RegexOptions.IgnoreCase)


        sentence = Regex.Replace(sentence, "<OTHERSREFERREDTO>", " ", RegexOptions.IgnoreCase)
        sentence = Regex.Replace(sentence, "</OTHERSREFERREDTO>", " ", RegexOptions.IgnoreCase)

        sentence = Regex.Replace(sentence, "\bfs\b", " ", RegexOptions.IgnoreCase)

        SearchPattern = "&em"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "&amp"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "&nbsp"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "catchwords:"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        Return sentence
    End Function


    Public Function Refine_XML_Tags(ByVal sentence As String) As String
        Dim ReplacePattern As String = " "
        Dim SearchPattern As String
        Dim Pattern As String

        sentence = Trim(LCase((sentence)))
        If sentence = "" Or Len(sentence) = 0 Then
            Exit Function
        End If

        sentence = Replace(sentence, "<p>", " ", RegexOptions.IgnoreCase)
        sentence = Replace(sentence, "</p>", " ", RegexOptions.IgnoreCase)
        sentence = Replace(sentence, "<br>", " ", RegexOptions.IgnoreCase)
        sentence = Replace(sentence, "</br>", " ", RegexOptions.IgnoreCase)
        sentence = Replace(sentence, "<p>", " ", RegexOptions.IgnoreCase)
        sentence = Replace(sentence, "</p>", " ", RegexOptions.IgnoreCase)
        sentence = Replace(sentence, "<i>", " ", RegexOptions.IgnoreCase)
        sentence = Replace(sentence, "</i>", " ", RegexOptions.IgnoreCase)
        sentence = Replace(sentence, "<b>", " ", RegexOptions.IgnoreCase)
        sentence = Replace(sentence, "</b>", " ", RegexOptions.IgnoreCase)

        Pattern = "\b<LINK\w*\s*</LINK>\b"
        sentence = Regex.Replace(sentence, Pattern, " ", RegexOptions.IgnoreCase)


        SearchPattern = "<LINK HREF=" & Chr(34) & "headnoteresult.asp?"
        sentence = Regex.Replace(sentence, SearchPattern, " ", RegexOptions.IgnoreCase)

        SearchPattern = "</LINK>"
        sentence = Regex.Replace(sentence, SearchPattern, " ", RegexOptions.IgnoreCase)

        SearchPattern = "<LINK HREF=" & Chr(34) & "legislationsectiondisplayformat.asp?"
        sentence = Regex.Replace(sentence, SearchPattern, " ", RegexOptions.IgnoreCase)

        SearchPattern = "</LINK>"
        sentence = Regex.Replace(sentence, SearchPattern, " ", RegexOptions.IgnoreCase)


        sentence = Regex.Replace(sentence, "\b<CATCHWORDS>\b", " ", RegexOptions.IgnoreCase)
        sentence = Regex.Replace(sentence, "\b</CATCHWORDS>\b", " ", RegexOptions.IgnoreCase)

        sentence = Regex.Replace(sentence, "<CATCHWORDS>", " ", RegexOptions.IgnoreCase)
        sentence = Regex.Replace(sentence, "</CATCHWORDS>", " ", RegexOptions.IgnoreCase)

        sentence = Regex.Replace(sentence, "\b<SUBJECT>\b", " ", RegexOptions.IgnoreCase)
        sentence = Regex.Replace(sentence, "\b</SUBJECT>\b", " ", RegexOptions.IgnoreCase)

        sentence = Regex.Replace(sentence, "<subject>", " ", RegexOptions.IgnoreCase)
        sentence = Regex.Replace(sentence, "</subject>", " ", RegexOptions.IgnoreCase)

        sentence = Regex.Replace(sentence, "\b<MODULE>\b", " ", RegexOptions.IgnoreCase)
        sentence = Regex.Replace(sentence, "\b</MODULE>\b", " ", RegexOptions.IgnoreCase)


        sentence = Regex.Replace(sentence, "<MODULE>", " ", RegexOptions.IgnoreCase)
        sentence = Regex.Replace(sentence, "</MODULE>", " ", RegexOptions.IgnoreCase)

        sentence = Regex.Replace(sentence, "\b<COUNSEL>\b", " ", RegexOptions.IgnoreCase)
        sentence = Regex.Replace(sentence, "\b</COUNSEL>\b", " ", RegexOptions.IgnoreCase)

        sentence = Regex.Replace(sentence, "<COUNSEL>", " ", RegexOptions.IgnoreCase)
        sentence = Regex.Replace(sentence, "</COUNSEL>", " ", RegexOptions.IgnoreCase)

        sentence = Regex.Replace(sentence, "\b<VERDICT>\b", " ", RegexOptions.IgnoreCase)
        sentence = Regex.Replace(sentence, "\b</VERDICT>\b", " ", RegexOptions.IgnoreCase)

        sentence = Regex.Replace(sentence, "<VERDICT>", " ", RegexOptions.IgnoreCase)
        sentence = Regex.Replace(sentence, "</VERDICT>", " ", RegexOptions.IgnoreCase)

        sentence = Regex.Replace(sentence, "\b<EM>\b", " ", RegexOptions.IgnoreCase)
        sentence = Regex.Replace(sentence, "\b</EM>\b", " ", RegexOptions.IgnoreCase)

        sentence = Regex.Replace(sentence, "<em>", " ", RegexOptions.IgnoreCase)
        sentence = Regex.Replace(sentence, "</em>", " ", RegexOptions.IgnoreCase)

        sentence = Regex.Replace(sentence, "\b<LEGISLATIONREFERREDTO>\b", " ", RegexOptions.IgnoreCase)
        sentence = Regex.Replace(sentence, "\b</LEGISLATIONREFERREDTO>\b", " ", RegexOptions.IgnoreCase)

        sentence = Regex.Replace(sentence, "<LEGISLATIONREFERREDTO>", " ", RegexOptions.IgnoreCase)
        sentence = Regex.Replace(sentence, "</LEGISLATIONREFERREDTO>", " ", RegexOptions.IgnoreCase)

        sentence = Regex.Replace(sentence, "\b<CASESREFERREDTO>\b", " ", RegexOptions.IgnoreCase)
        sentence = Regex.Replace(sentence, "\b</CASESREFERREDTO>\b", " ", RegexOptions.IgnoreCase)

        sentence = Regex.Replace(sentence, "<CASESREFERREDTO>", " ", RegexOptions.IgnoreCase)
        sentence = Regex.Replace(sentence, "</CASESREFERREDTO>", " ", RegexOptions.IgnoreCase)

        sentence = Regex.Replace(sentence, "\b<OTHERSREFERREDTO>\b", " ", RegexOptions.IgnoreCase)
        sentence = Regex.Replace(sentence, "\b</OTHERSREFERREDTO>\b", " ", RegexOptions.IgnoreCase)


        sentence = Regex.Replace(sentence, "<OTHERSREFERREDTO>", " ", RegexOptions.IgnoreCase)
        sentence = Regex.Replace(sentence, "</OTHERSREFERREDTO>", " ", RegexOptions.IgnoreCase)

        sentence = Regex.Replace(sentence, "\bfs\b", " ", RegexOptions.IgnoreCase)

        SearchPattern = "'"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = " & chr(34) & "
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        sentence = Replace(sentence, "/", " ")
        sentence = Replace(sentence, "\", " ")
        sentence = Replace(sentence, "|", " ")
        sentence = Replace(sentence, ")", " ")
        sentence = Replace(sentence, "[", " ")
        sentence = Replace(sentence, "]", " ")

        sentence = Replace(sentence, "{", " ")
        sentence = Replace(sentence, "}", " ")

        sentence = Replace(sentence, "(", " ")
        sentence = Replace(sentence, ")", " ")

        sentence = Replace(sentence, "<", " ")
        sentence = Replace(sentence, ">", " ")

        sentence = Replace(sentence, "?", " ")

        sentence = Replace(sentence, ".", " ")
        sentence = Replace(sentence, ",", " ")
        sentence = Replace(sentence, ";", " ")
        sentence = Replace(sentence, ":", " ")
        sentence = Replace(sentence, "/", " ")
        sentence = Replace(sentence, "\", " ")
        sentence = Replace(sentence, "|", " ")
        sentence = Replace(sentence, "-", " ")
        sentence = Replace(sentence, "_", " ")
        sentence = Replace(sentence, "=", " ")
        sentence = Replace(sentence, "+", " ")
        sentence = Replace(sentence, "@", " ")
        sentence = Replace(sentence, "!", " ")
        sentence = Replace(sentence, "*", " ")
        sentence = Replace(sentence, "`", " ")
        sentence = Replace(sentence, "'", " ")
        sentence = Replace(sentence, "''", " ")
        sentence = Replace(sentence, "#", " ")
        sentence = Replace(sentence, "$", " ")
        sentence = Replace(sentence, "%", " ")
        sentence = Replace(sentence, Chr(34), " ")
        sentence = Replace(sentence, Chr(10), " ")
        sentence = Replace(sentence, Chr(13), " ")



        SearchPattern = "&em"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "&amp"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "&nbsp"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "catchwords:"
        sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        sentence = Replace(sentence, "  ", " ")
        sentence = Replace(sentence, "   ", " ")
        sentence = Replace(sentence, "    ", " ")
        sentence = Replace(sentence, "     ", " ")
        sentence = Replace(sentence, "      ", " ")
        sentence = Replace(sentence, "       ", " ")
        sentence = Replace(sentence, "        ", " ")
        sentence = Replace(sentence, "         ", " ")
        sentence = Replace(sentence, "          ", " ")
        sentence = Replace(sentence, "           ", " ")

        Return sentence
    End Function

    Public Function RefineSentence(ByVal Sentence As String) As String

        Dim i As Int16
        Dim ReplacePattern As String = ""
        Dim ReplacePattern1 As String = " "
        Dim SearchPattern As String
        Dim sbSentence As New System.Text.StringBuilder
        Sentence = Trim(Sentence)

        ''' for stoping XSS ATTACK
        SearchPattern = "\b<script>\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\b</script>\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)


        For i = 65 To 90 '''include all English alphabets [A-Z,a-z] as its ignore case
            SearchPattern = "\b" & Chr(i) & "\b"
            Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        Next

        For i = 48 To 57 '''include all English alphabets [A-Z,a-z] as its ignore case
            SearchPattern = "\b" & Chr(i) & "\b"
            Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        Next


        SearchPattern = "\b+\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern1, RegexOptions.IgnoreCase)

        'SearchPattern = "\b-\b"
        'Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\b/\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern1, RegexOptions.IgnoreCase)

        SearchPattern = "\b*\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\b$\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern1, RegexOptions.IgnoreCase)

        SearchPattern = "^"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)


        '        SearchPattern = "("
        'Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        'SearchPattern = ")"
        'Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        'SearchPattern = "["
        'Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        'SearchPattern = "]"
        'Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        'SearchPattern = "{"
        'Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        'SearchPattern = "}"
        'Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "&"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern1, RegexOptions.IgnoreCase)

        SearchPattern = "@"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern1, RegexOptions.IgnoreCase)

        SearchPattern = "#"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern1, RegexOptions.IgnoreCase)

        SearchPattern = "!"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern1, RegexOptions.IgnoreCase)

        SearchPattern = "~"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "'"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern1, RegexOptions.IgnoreCase)

        SearchPattern = "%"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern1, RegexOptions.IgnoreCase)

        SearchPattern = "\b.\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern1, RegexOptions.IgnoreCase)

        SearchPattern = "\b,\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern1, RegexOptions.IgnoreCase)


        'SearchPattern = "?"
        'Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern1, RegexOptions.IgnoreCase)

        SearchPattern = "\b\\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern1, RegexOptions.IgnoreCase)

        SearchPattern = "|"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "="
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern1, RegexOptions.IgnoreCase)
        ''/* Imp
        ''  i have to chk where to put replacepattern1 by testing
        ''  i came to know about - and _ so i m putting because anti-money is becoming
        ''  antimoney
        ''*/
        SearchPattern = "-"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern1, RegexOptions.IgnoreCase)

        SearchPattern = "_"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern1, RegexOptions.IgnoreCase)

        SearchPattern = ";"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern1, RegexOptions.IgnoreCase)

        SearchPattern = ":"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern1, RegexOptions.IgnoreCase)

        SearchPattern = "'"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern1, RegexOptions.IgnoreCase)

        SearchPattern = " & chr(34) & "
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern1, RegexOptions.IgnoreCase)


        SearchPattern = "\banother\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bafter\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bof\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bby\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bbe\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)


        SearchPattern = "\babout\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bis\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)


        SearchPattern = "\bin\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\ban\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bam\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bas\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bthe\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bout\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\ball\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bfrom\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bfor\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bto\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\band\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bany\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bor\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bnot\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bxor\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bxnor\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bdid\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bdoes\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bdo\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bshall\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bare\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bwas\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bwere\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bthere\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\btheir\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bwe\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bthe\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bhe\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bshe\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bit\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bhad\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bhas\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bhave\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bto\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bthey\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bthose\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bthem\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bthen\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bthat\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bthis\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bme\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bmy\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bus\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bwill\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bshall\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bhis\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bhim\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bhad\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bmy\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bmine\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bnot\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bhave\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)


        SearchPattern = "\bwho\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bwith\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bwhat\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)



        '''===================New================

        SearchPattern = "\bother\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\banother\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bafter\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bbecause\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bbeen\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bbefore\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bbeing\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bbetween\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bboth\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bbut\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bby\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bcame\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bcome\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bcan\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bcould\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bbefore\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\beach\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bfor\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bfrom\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bget\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bgot\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bhere\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bhimself\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bhow\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bhis\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bif\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bin\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\binto\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bis\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bit\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\blike\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bmake\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bmany\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bme\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bmight\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bbefore\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bmore\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bmost\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bmuch\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bmy\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bnever\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bnow\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bof\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bon\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bonly\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bother\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bour\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bout\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bover\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bsaid\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bsame\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bsee\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bsince\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bshould\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bsince\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bsome\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bstill\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bsuch\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\btake\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bthen\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bthat\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bthe\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\btheir\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bthem\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bthen\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bthere\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bthese\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bthey\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bthis\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bthose\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bthrough\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bto\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\btoo\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bunder\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bup\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bvery\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bwas\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bway\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bwe\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bwell\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bwere\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bwhere\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bwhich\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bwhile\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bwho\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bwith\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\bwould\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\byou\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        SearchPattern = "\byour\b"
        Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

        '''=====================================
        'SearchPattern = "\bfrom\b"
        'Sentence = Regex.Replace(Sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)



        Sentence = Replace(Sentence, ")", " ")
        Sentence = Replace(Sentence, "[", " ")
        Sentence = Replace(Sentence, "]", " ")

        Sentence = Replace(Sentence, "{", " ")
        Sentence = Replace(Sentence, "}", " ")

        Sentence = Replace(Sentence, "(", " ")
        Sentence = Replace(Sentence, ")", " ")

        Sentence = Replace(Sentence, "?", " ")

        Sentence = Replace(Sentence, ".", " ")
        Sentence = Replace(Sentence, ",", " ")
        Sentence = Replace(Sentence, ";", " ")
        Sentence = Replace(Sentence, ":", " ")
        Sentence = Replace(Sentence, "/", " ")
        Sentence = Replace(Sentence, "\", " ")
        Sentence = Replace(Sentence, "|", " ")
        Sentence = Replace(Sentence, "-", " ")
        Sentence = Replace(Sentence, "_", " ")
        Sentence = Replace(Sentence, "=", " ")
        Sentence = Replace(Sentence, "+", " ")
        Sentence = Replace(Sentence, "*", " ")

        Sentence = Replace(Sentence, Chr(10), " ")
        Sentence = Replace(Sentence, Chr(13), " ")

        Sentence = Replace(Sentence, "  ", " ")
        Sentence = Replace(Sentence, "   ", " ")
        Sentence = Replace(Sentence, "    ", " ")
        Sentence = Replace(Sentence, "     ", " ")
        Sentence = Replace(Sentence, "      ", " ")
        Sentence = Replace(Sentence, "       ", " ")
        Sentence = Replace(Sentence, "        ", " ")
        Sentence = Replace(Sentence, "         ", " ")
        Sentence = Replace(Sentence, "          ", " ")
        Sentence = Replace(Sentence, "           ", " ")

        'sentence = Replace(sentence, " will ", " ") '' check according requirement


        Return Sentence

    End Function


    Public Function myParser(ByVal sentence As String, ByVal FIELD As String, ByVal LogicOperator As String) As String
        Dim col As New Collections.ArrayList
        Dim i As Integer
        Dim Result As String

        'sentence = WordExtractor(TextBox1.Text)
        Result = ""
        col = Tokenizer(sentence, " ")


        For i = 0 To col.Count - 1
            If i = 0 Then
                'Result = "'" & col.Item(i) & "%'"
                Result = " ( " & FIELD & " like '%" & col.Item(i) & "%'" & " )"
                GoTo againLoop
            End If
            If (col.Item(i) <> "" And col.Item(i) <> " ") Then
                ' this condition is for stoping search for space or null in collection
                Result &= " " & LogicOperator & " ( " & FIELD & " like '%" & col.Item(i) & "%' " & " ) "
            End If

againLoop:
        Next

        Return Result
    End Function

    Public Function myParser1(ByVal sentence As String, ByVal FIELD As String, ByVal LogicOperator As String) As String
        Dim col As New Collections.ArrayList
        Dim i As Integer
        Dim Result As String

        'sentence = WordExtractor(TextBox1.Text)
        Result = ""
        col = Tokenizer(sentence, " ")
        '


        For i = 0 To col.Count - 1
            If i = 0 Then
                'Result = "'" & col.Item(i) & "%'"
                Result = "" & col.Item(i) & "*"
                GoTo againLoop
            End If
            '           Result &= " " & LogicOperator & " " &  contains FIELD & " like %" & col.Item(i) & "% "
againLoop:
        Next

        If LogicOperator = "and" And i > 0 Then

        End If

        Return Result
    End Function

    Public Function Tokenizer(ByVal Statement As String, ByVal Identifier As String) As Collections.ArrayList

        Dim ST As String
        Dim Length As Integer
        Dim i As Integer
        Dim COLL As New Collections.ArrayList

        Length = Len(Statement)

        Dim starr(Length) As String

        Statement = Trim(Statement)

        For i = 1 To Length

            starr(i) = Mid(Statement, i, 1)

            If starr(i) = Identifier Then

                COLL.Add(ST)
                ST = ""

            End If

            If starr(i) <> Identifier Then
                ST = ST & starr(i)
            End If


        Next i
        COLL.Add(ST)

        Tokenizer = COLL

    End Function

    Public Function CountryParser(ByVal sentence As String, ByVal FIELD As String, ByVal LogicOperator As String) As String
        Dim col As New Collections.ArrayList
        Dim i As Integer
        Dim Result As String

        'sentence = WordExtractor(TextBox1.Text)
        Result = ""
        col = Tokenizer(sentence, ",")


        For i = 0 To col.Count - 1
            If i = 0 Then
                'Result = "'" & col.Item(i) & "%'"
                Result = "" & col.Item(i) & "%'"
                GoTo againLoop
            End If
            If (col.Item(i) <> "" And col.Item(i) <> " ") Then
                ' this condition is for stoping search for space or null in collection
                Result &= " " & LogicOperator & " " & FIELD & " like '%" & col.Item(i) & "%' "
            End If

againLoop:
        Next

        If LogicOperator = "and" And i > 0 Then

        End If

        Return Result
    End Function

    Public Function Contains_Parser_notDetailed(ByVal sentence As String, ByVal FIELD As String, ByVal LogicOperator As String) As String
        'this means that contains will not have % 
        Dim col As New Collections.ArrayList
        Dim i As Integer
        Dim Result As String

        Result = ""
        col = Tokenizer(sentence, " ")


        For i = 0 To col.Count - 1
            If i = 0 Then
                'Result = "'" & col.Item(i) & "%'"
                Result = " Contains( " & FIELD & " , '" & col.Item(i) & "' )"
                GoTo againLoop
            End If
            If (col.Item(i) <> "" And col.Item(i) <> " ") Then
                ' this condition is for stoping search for space or null in collection
                'EG. contains(field,"data") and contains(field,"data")
                Result &= " " & LogicOperator & " Contains(" & FIELD & " , '" & col.Item(i) & "' ) "

            End If

againLoop:
        Next

        Return Result
    End Function

    Public Function Contains_Parser_Detailed(ByVal sentence As String, ByVal FIELD As String, ByVal LogicOperator As String) As String
        'this means that contains will have % for more results
        Dim col As New Collections.ArrayList
        Dim i As Integer
        Dim Result As String

        Result = ""
        col = Tokenizer(sentence, " ")


        For i = 0 To col.Count - 1
            If i = 0 Then
                'Result = "'" & col.Item(i) & "%'"
                Result = " Contains( " & FIELD & " , '*" & col.Item(i) & "*'" & ")"
                GoTo againLoop
            End If
            If (col.Item(i) <> "" And col.Item(i) <> " ") Then
                ' this condition is for stoping search for space or null in collection
                'EG. contains(field,"data") and contains(field,"data")
                Result &= " " & LogicOperator & " Contains(" & FIELD & " , '*" & col.Item(i) & "*'" & " )"

            End If

againLoop:
        Next

        Return Result
    End Function



End Class

End Namespace

