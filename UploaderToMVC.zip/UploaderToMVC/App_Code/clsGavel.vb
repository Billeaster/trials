
'/******************************************************************************/
'/*	Developer 	    : Updated & Modify by Ali,Abdo          								   */
'/*	Company     	: Elaw Sdn Bhd		    	    				        */
'/* Date Modified	: 2/ 1/ 2014       		        		    		     */  
'/*	Description		: This library has functions related to cases like fetching case citator etc      */
'/*	Version			: 1.0											            */
'/*******************************************************************************/


Imports System.Data.SqlClient
Imports System.Exception
Imports System.Data


Namespace membersarea


    Public Class clsGavel
        ' Inherits clsGavel
        Public ConnectionString As String = "Data Source=DSSBNB06;initial catalog=elawdb;persist security info=True; Integrated Security=SSPI;"

        Public Sub New()

            ' ConnectionString = ConfigurationSettings.AppSettings("ConnectionString")
            ConnectionString = clsConfigs.sGlobalConnectionString

            If ConnectionString = "" Then
                Throw New ApplicationException("Missing ConnectionString variable in web.config file.")
            End If

        End Sub






        Public Overloads Function AddRecord(ByVal Query As String) As Boolean
            'Dim Query As String = "insert into tblUserPrimary "
            AddRecord = False
            Dim Statement As String
            Statement = Query
            Dim conn As New SqlConnection(ConnectionString)
            Dim cmd As New SqlCommand
            Try
                cmd.Connection = conn
                cmd.CommandType = CommandType.Text
                cmd.CommandText = Query
                conn.Open()
                cmd.ExecuteNonQuery()

                AddRecord = True
            Catch err As Exception
                AddRecord = False
                Throw New Exception("Error in inserting to DB  " & err.Message)


            Finally
                conn.Close()
                cmd = Nothing
            End Try
            Return AddRecord

        End Function

        'Public Shared Function ExecuteMyQuery(ByVal Query As String, ByVal tblName As String) As DataSet
        Public Function ExecuteMyQuery(ByVal Query As String, ByVal tblName As String) As DataSet
            Dim DS As New DataSet
            Dim conn As New SqlConnection(ConnectionString)
            Try

                Dim cmd As New SqlCommand(Query, conn)
                Dim adapter As New SqlDataAdapter(cmd)


                adapter.Fill(DS, tblName)
            Catch err As DataException
                'Throw New ApplicationException("Error in connecting to DB  " & err.Message)
                myErrorHandler(err)
            Finally
                conn.Close()
            End Try

            Return DS
        End Function

        'Public Shared Function ExecuteMyQuery(ByVal Query As String) As DataTable
        Public Function ExecuteMyQuery(ByVal Query As String) As DataTable
            Dim DT As New DataTable
            Dim conn As New SqlConnection(ConnectionString)
            Dim MSG As String

            Try

                Dim cmd As New SqlCommand(Query, conn)
                Dim adapter As New SqlDataAdapter(cmd)

                cmd.CommandTimeout = 1000
                adapter.Fill(DT)
            Catch err As Exception
                'Throw New ApplicationException("Error in connecting to DB  " & err.Message)
                MSG = err.Message
            Finally
                conn.Close()
            End Try
            conn = Nothing
            Return DT
        End Function

        'Public Shared Function ExecuteMyQuery(ByVal Query As String, ByVal tblName As String, ByVal CurRec As Int16) As DataSet
        Public Function ExecuteMyQuery(ByVal Query As String, ByVal tblName As String, ByVal CurRec As Int16) As DataTable
            Dim DS As New DataSet
            Dim DT As New DataTable
            Dim conn As New SqlConnection(ConnectionString)
            Dim MSG As String
            Try

                'Dim cmd As New SqlCommand(Query, conn)
                'Dim adapter As New SqlDataAdapter(cmd)
                Dim adapter As New SqlDataAdapter(Query, conn)


                adapter.Fill(DS, CurRec, 10, tblName)
            Catch err As Exception
                'Throw New ApplicationException("Error in connecting to DB  " & err.Message)

                MSG = err.Message
            Finally
                conn.Close()
            End Try
            If DS.Tables.Count > 0 Then
                DT = DS.Tables(0) '.Add()
            End If
            '//Destructing the values
            DS = Nothing
            MSG = ""
            conn = Nothing ' have to test if this will effect other function
            Return DT
        End Function

        'Public Shared Function ExecuteMyReader(ByVal Query As String) As Int32
        Public Function ExecuteMyReader(ByVal Query As String) As Int32
            ''/*  This is for counting records fetched   */
            '' err in this function

            '        Dim Query As String = "select max(user_id_no) from master_users"
            Dim conn As New SqlConnection(ConnectionString)
            Dim Reader As SqlDataReader
            Dim recCount As Int32
            Dim cmd = New SqlCommand(Query, conn)
            Dim msg As String
            Try
                conn.Open()
                Reader = cmd.ExecuteReader()

                While Reader.Read()
                    recCount = Reader(0)
                End While

            Catch err As Exception
                msg = err.Message
                'myErrorHandler(err)
            Finally
                conn.Close()
                'conn.Dispose()
                conn = Nothing
                Reader = Nothing
                cmd = Nothing
            End Try

            'ExecuteMyReader = recCount
            Return recCount
        End Function



        Public Function UpdateRecord(ByVal Query As String) As Boolean
            'Dim Query As String = "insert into tblUserPrimary "
            UpdateRecord = False
            Dim Statement As String
            Statement = Query
            Dim conn As New SqlConnection(ConnectionString)
            Dim cmd As New SqlCommand
            Try
                cmd.Connection = conn
                cmd.CommandType = CommandType.Text
                cmd.CommandText = Query
                conn.Open()
                cmd.ExecuteNonQuery()

                UpdateRecord = True
            Catch err As Exception
                Throw New Exception("Error in inserting to DB  " & err.Message)
                UpdateRecord = False

            Finally
                conn.Close()
                cmd = Nothing
            End Try
            Return UpdateRecord

        End Function



        Private Shared Sub myErrorHandler(ByVal Err As Exception)
            'Throw New ApplicationException("Error in connecting to DB  " & Err.Message)
            Throw New ApplicationException("Error in connecting to DB  " & Err.StackTrace)
        End Sub

        Public Function InsertBookInfo(ByVal BookName As String, ByVal Author As String, ByVal PublishDate As String, ByVal ISBN As String) As Int32
            ' Public Function InsertGavel(ByVal ChapterNo As String, ByVal ChapterTitle As String, ByVal JudgementCountry As String, ByVal JudgementLanguage As String, ByVal BOOLEANTEXT As String, ByVal HeadNotes As String) As Int32
            Dim DT As New DataTable() ' DataSet()
            Dim DS As New DataSet

            Dim conn As New SqlConnection(ConnectionString)
            Dim cmd As New SqlCommand()

            Try
                cmd.Connection = conn
                cmd.CommandText = "sp_InsertBookInfo"
                cmd.CommandType = CommandType.StoredProcedure


                cmd.Parameters.Add(New SqlParameter("@BookName", SqlDbType.VarChar)).Value = BookName
                cmd.Parameters.Add(New SqlParameter("@Author", SqlDbType.VarChar)).Value = Author

                If PublishDate.Trim() <> "" Then
                    cmd.Parameters.Add(New SqlParameter("@PublishDate", SqlDbType.DateTime)).Value = Convert.ToDateTime(PublishDate)
                Else
                    cmd.Parameters.Add(New SqlParameter("@PublishDate", SqlDbType.DateTime)).Value = DBNull.Value
                End If

                cmd.Parameters.Add(New SqlParameter("@ISBN", SqlDbType.VarChar)).Value = ISBN
                cmd.Parameters.Add(New SqlParameter("@BookID", SqlDbType.Int)).Direction = ParameterDirection.Output
                conn.Open()

                cmd.ExecuteNonQuery()



                conn.Close()
            Catch err As Exception
                Dim msg1 As String = err.Message
                '          
            Finally
                conn.Close()
                conn.Dispose()
                cmd.Dispose()
            End Try


            conn = Nothing ' have to test if this will effect other function
            Return Convert.ToInt32(cmd.Parameters("@BookID").Value.ToString())
        End Function

        Public Function InsertGavel(ByVal ChapterNo As String, ByVal ChapterTitle As String, ByVal JudgementCountry As String, ByVal JudgementLanguage As String, ByVal HeadNotes As String, ByVal BookID As Int32) As Int32
            ' Public Function InsertGavel(ByVal ChapterNo As String, ByVal ChapterTitle As String, ByVal JudgementCountry As String, ByVal JudgementLanguage As String, ByVal BOOLEANTEXT As String, ByVal HeadNotes As String) As Int32
            Dim DT As New DataTable() ' DataSet()
            Dim DS As New DataSet

            Dim conn As New SqlConnection(ConnectionString)
            Dim cmd As New SqlCommand()

            Try
                cmd.Connection = conn
                cmd.CommandText = "sp_InsertBook1"
                cmd.CommandType = CommandType.StoredProcedure


                cmd.Parameters.Add(New SqlParameter("@ChapterNo", SqlDbType.VarChar)).Value = ChapterNo
                cmd.Parameters.Add(New SqlParameter("@ChapterTitle", SqlDbType.VarChar)).Value = ChapterTitle
                cmd.Parameters.Add(New SqlParameter("@JudgementCountry", SqlDbType.VarChar)).Value = JudgementCountry
                cmd.Parameters.Add(New SqlParameter("@JudgementLanguage", SqlDbType.VarChar)).Value = JudgementLanguage
                'cmd.Parameters.Add(New SqlParameter("@BOOLEANTEXT", SqlDbType.Text)).Value = BOOLEANTEXT
                cmd.Parameters.Add(New SqlParameter("@HeadNotes", SqlDbType.Text)).Value = HeadNotes
                cmd.Parameters.Add(New SqlParameter("@BookID", SqlDbType.Int)).Value = BookID
                cmd.Parameters.Add(New SqlParameter("@GavelID", SqlDbType.Int)).Direction = ParameterDirection.Output


                conn.Open()
                cmd.ExecuteNonQuery()



                conn.Close()
            Catch err As Exception
                Dim msg1 As String = err.Message
                '          
            Finally
                conn.Close()
                conn.Dispose()
                cmd.Dispose()
            End Try


            conn = Nothing ' have to test if this will effect other function
            Return Convert.ToInt32(cmd.Parameters("@GavelID").Value.ToString())
        End Function

        ' Public Function InsertGavelSubjectIndex(ByVal GavelID As Int32, ByVal SubjectIndex As String, ByVal SubjectIndexContent As String) As Int32
        Public Function InsertGavelSubjectIndex(ByVal GavelID As Int32, ByVal SubjectIndex As String) As Int32
            Dim DT As New DataTable() ' DataSet()
            Dim DS As New DataSet

            Dim conn As New SqlConnection(ConnectionString)
            Dim cmd As New SqlCommand()

            Try
                cmd.Connection = conn
                cmd.CommandText = "sp_InsertBook1SubjectIndex"
                cmd.CommandType = CommandType.StoredProcedure


                cmd.Parameters.Add(New SqlParameter("@GavelID", SqlDbType.Int)).Value = GavelID
                cmd.Parameters.Add(New SqlParameter("@SubjectIndex", SqlDbType.VarChar)).Value = SubjectIndex
                'cmd.Parameters.Add(New SqlParameter("@SubjectIndexContent", SqlDbType.VarChar)).Value = SubjectIndexContent


                cmd.Parameters.Add(New SqlParameter("@SubjectIndexID", SqlDbType.Int)).Direction = ParameterDirection.Output
                conn.Open()
                cmd.ExecuteNonQuery()

                conn.Close()
            Catch err As Exception
                Dim msg1 As String = err.Message
                '          
            Finally
                conn.Close()
                conn.Dispose()
                cmd.Dispose()
            End Try


            conn = Nothing ' have to test if this will effect other function

            Return Convert.ToInt32(cmd.Parameters("@SubjectIndexID").Value.ToString())

        End Function

        Public Function InsertGavelSubjectIndexContent(ByVal SubjectIndexID As Int32, ByVal SubjectIndexContent As String)
            Dim DT As New DataTable() ' DataSet()
            Dim DS As New DataSet

            Dim conn As New SqlConnection(ConnectionString)
            Dim cmd As New SqlCommand()

            Try
                cmd.Connection = conn
                cmd.CommandText = "sp_InsertBook1SubjectIndexContent"
                cmd.CommandType = CommandType.StoredProcedure


                cmd.Parameters.Add(New SqlParameter("@SubjectIndexID", SqlDbType.Int)).Value = SubjectIndexID
                cmd.Parameters.Add(New SqlParameter("@SubjectIndexContent", SqlDbType.Text)).Value = SubjectIndexContent
                'cmd.Parameters.Add(New SqlParameter("@SubjectIndexContent", SqlDbType.VarChar)).Value = SubjectIndexContent


                ' cmd.Parameters.Add(New SqlParameter("@TotalRowcount", SqlDbType.Int)).Direction = ParameterDirection.Output
                conn.Open()
                cmd.ExecuteNonQuery()

                conn.Close()
            Catch err As Exception
                Dim msg1 As String = err.Message
                '          
            Finally
                conn.Close()
                conn.Dispose()
                cmd.Dispose()
            End Try


            conn = Nothing ' have to test if this will effect other function

        End Function

        Public Function UpdateGavel(ByVal ChapterNo As String, ByVal Booleantext As String)
            ' Public Function InsertGavel(ByVal ChapterNo As String, ByVal ChapterTitle As String, ByVal JudgementCountry As String, ByVal JudgementLanguage As String, ByVal BOOLEANTEXT As String, ByVal HeadNotes As String) As Int32
            Dim DT As New DataTable() ' DataSet()
            Dim DS As New DataSet

            Dim conn As New SqlConnection(ConnectionString)
            Dim cmd As New SqlCommand()

            Try
                cmd.Connection = conn
                cmd.CommandText = "sp_UpdateMain"
                cmd.CommandType = CommandType.StoredProcedure


                cmd.Parameters.Add(New SqlParameter("@ChapterNo", SqlDbType.VarChar)).Value = ChapterNo
                cmd.Parameters.Add(New SqlParameter("@BooleanText", SqlDbType.VarChar)).Value = Booleantext

                conn.Open()
                cmd.ExecuteNonQuery()

                conn.Close()
            Catch err As Exception
                Dim msg1 As String = err.Message
                '          
            Finally
                conn.Close()
                conn.Dispose()
                cmd.Dispose()
            End Try


            conn = Nothing ' have to test if this will effect other function

        End Function


        Public Function CheckChapterNoAlreadyExist(ByVal ChapterNo As String) As DataTable

            Dim ds As New DataTable
            ' Dim myParameter As SqlParameter
            Dim conn As New SqlConnection(ConnectionString)
            Dim cmd As New SqlCommand()

            Try

                cmd.Connection = conn
                cmd.CommandText = "sp_CheckChapterAlreadtExist"

                cmd.CommandType = CommandType.StoredProcedure
                cmd.Parameters.Add(New SqlParameter("@ChapterNo", SqlDbType.VarChar)).Value = ChapterNo
                conn.Open()
                cmd.ExecuteNonQuery()

                Dim adapter As New SqlDataAdapter(cmd)

                adapter.Fill(ds)
                conn.Close()

            Catch err As DataException
                Throw New ApplicationException("Error in connecting to DB  " & err.Message)
            Finally
                conn.Close()
                conn.Dispose()
                cmd.Dispose()
            End Try

            Return ds

        End Function
    End Class

    Public Class clsConfigs

        Public Function ConnString() As String
            Dim sGlobalConnectionString As String = "Data Source=DSSBNB06;initial catalog=elawdb;persist security info=True; Integrated Security=SSPI;"

            Return sGlobalConnectionString
        End Function

        Public Shared ReadOnly sGlobalConnectionString As String = "Data Source=DSSBNB06;initial catalog=elawdb;persist security info=True; Integrated Security=SSPI;"

    End Class

End Namespace
