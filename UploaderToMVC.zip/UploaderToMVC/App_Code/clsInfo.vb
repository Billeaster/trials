


Imports System.Data.SqlClient
Imports System.Exception


'Namespace admin1


Public Class clsInfo

    Private ConnectionString As String
    Public Sub New()

        ConnectionString = ConfigurationSettings.AppSettings("ConnectionString")

        If ConnectionString = "" Then
            Throw New ApplicationException("Missing ConnectionString variable in web.config file.")
        End If

    End Sub


    Public Function LoadAllCountries() As DataTable

        Dim DT As New DataTable()
        Dim myParameter As SqlParameter
        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand()
        Dim TotalResult As Int16
        Dim temp As String

        Try
            cmd.Connection = conn
            cmd.CommandText = "sp_getCountries"
            cmd.CommandType = CommandType.StoredProcedure
            conn.Open()
            cmd.ExecuteNonQuery()

            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)
        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally
            conn.Close()
            conn.Dispose()
            cmd.Dispose()
        End Try

        Return DT
    End Function

    Public Function getMembersCountries() As DataTable

        Dim DT As New DataTable()
        Dim myParameter As SqlParameter
        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand()
        Dim TotalResult As Int16
        Dim temp As String

        Try
            cmd.Connection = conn
            cmd.CommandText = "sp_getCountries"
            cmd.CommandType = CommandType.StoredProcedure
            conn.Open()
            cmd.ExecuteNonQuery()

            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)
        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally
            conn.Close()
            conn.Dispose()
            cmd.Dispose()
        End Try

        Return DT
    End Function

    Public Function getMemberSiteNames() As DataTable

        Dim DT As New DataTable()
        Dim Query As String
        Dim Obj As New clsUsers()
        Query = "Select distinct Site_Name from master_users"

        Try
            DT = Obj.FetchDataSet(Query)


        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally
            Obj = Nothing
        End Try

        Return DT
    End Function

    Public Function getMemberStatesByCountries(ByVal Country As String) As DataTable

        Dim DT As New DataTable()
        Dim Query As String
        Dim Obj As New clsUsers()
        Query = "Select distinct state from master_users where country='" & Country & "' "

        Try
            DT = Obj.FetchDataSet(Query)


        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally
            Obj = Nothing
        End Try

        Return DT
    End Function

    Public Function getSalesRepresentative() As DataTable

        Dim DT As New DataTable()
        Dim myParameter As SqlParameter
        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand()
        Dim TotalResult As Int16
        Dim temp As String

        Try
            cmd.Connection = conn
            cmd.CommandText = "sp_getSalesRepName"
            cmd.CommandType = CommandType.StoredProcedure
            conn.Open()
            cmd.ExecuteNonQuery()

            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)
        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally
            conn.Close()
            conn.Dispose()
            cmd.Dispose()
        End Try

        Return DT
    End Function

    Public Function GetSiteNames() As ArrayList
        Dim SiteNames As New ArrayList()
        SiteNames.Add("MYLAWBOX")
        SiteNames.Add("LANKALAWBOX")
        SiteNames.Add("PKLAWBOX")
        ''------------
        'Note: Modules
        SiteNames.Add("BANKING AND FINANCE")
        SiteNames.Add("LAND")
        SiteNames.Add("INTELLECTUAL PROPERTY")
        SiteNames.Add("CRIMINAL")
        SiteNames.Add("FAMILY")
        SiteNames.Add("MARITIME")
        SiteNames.Add("ARBITRATION")
        SiteNames.Add("TAX")
        SiteNames.Add("INDUSTRIAL")
        SiteNames.Add("PUBLIC")
        SiteNames.Add("COMPANY")
        SiteNames.Add("TORT")
        SiteNames.Add("MEDICAL")
        ''Note :- This is for future modules
        'SiteNames.Add("CIVIL")
        'SiteNames.Add("ISLAMIC")
        'SiteNames.Add("BANKRUPTCY")
        'SiteNames.Add("DAMAGES")
        'SiteNames.Add("CONTRACT")


        Return SiteNames
    End Function


    Public Function GetAccountStatusType() As ArrayList
        Dim List As New ArrayList
        List.Add("All")
        List.Add("New Account")
        List.Add("Renewal")

        Return List
    End Function

    Public Function GetmodeOfPayment() As ArrayList
        Dim List As New ArrayList
        List.Add("All")
        List.Add("Cheque")
        List.Add("Credit Card")
        List.Add("EFT")
        Return List
    End Function

    Public Function GetmodeOfPaymentWithoutAll() As ArrayList
        Dim List As New ArrayList
        List.Add("Cheque")
        List.Add("Credit Card")
        List.Add("EFT")
        Return List
    End Function

    Public Function GetPMStatusWithoutAll() As ArrayList
        Dim List As New ArrayList
        List.Add("Paid")
        List.Add("Unpaid")
        List.Add("Partial")
        Return List
    End Function

    Public Function GetAccountType() As ArrayList
        Dim List As New ArrayList

        List.Add("All")
        List.Add("Single")
        List.Add("Group")
        List.Add("Free")
        Return List
    End Function

    Public Function GetAccountTypeVersion2() As ArrayList
        Dim List As New ArrayList
        List.Add("Single")
        List.Add("Group")
        Return List
    End Function

    Public Function GetAccountTypeVersion3() As ArrayList
        Dim List As New ArrayList
        List.Add("Single")
        List.Add("Free")
        Return List
    End Function
    Public Function GetSalesTeam() As DataTable
        Dim DT As New DataTable
        Dim Query As String
        Dim Obj As New clsUsers
        Query = "Select [Sales_ID],[Sales_Name] from [eLaw_Sales_Team]"

        Try
            DT = Obj.FetchDataSet(Query)

        Catch err As DataException
            Throw New DataException("Error in connecting to DB  " & err.Message)
        Finally
            Obj = Nothing
        End Try

        Return DT
    End Function

    Public Function GetCategory() As ArrayList
        Dim List As New ArrayList
        List.Add("Product Code")
        List.Add("Product ID")
        List.Add("Product Name")
        Return List
    End Function

    Public Function GetCategoryForAccount() As ArrayList
        Dim List As New ArrayList
        List.Add("Account ID")
        List.Add("Customer Name")
        Return List
    End Function

    Public Function GetCategoryForDate() As ArrayList
        Dim List As New ArrayList
        List.Add("Confirmation Date")
        List.Add("Account Expiry")
        Return List
    End Function

    Public Function GetCategoryForSalesReport() As ArrayList
        Dim List As New ArrayList
        List.Add("Invoice No")
        List.Add("Customer Name")
        Return List
    End Function

    Public Function GetCategoryForUser() As ArrayList
        Dim List As New ArrayList
        List.Add("Account")
        List.Add("User ID")
        Return List
    End Function

    Public Function GetCreatedAccount() As ArrayList
        Dim List As New ArrayList
        List.Add("Admin Team")
        List.Add("Sales Team")
        List.Add("CallBox Team")

        Return List
    End Function


    Public Function GetProfessions() As ArrayList
        Dim ProfessionList As New ArrayList
        ProfessionList.Add("Lawyer")
        ProfessionList.Add("Legal Counsel")
        ProfessionList.Add("Judge")
        ProfessionList.Add("Consultant")
        ProfessionList.Add("Admin/Secretary")
        ProfessionList.Add("Executive/Managerial")
        ProfessionList.Add("IT")
        ProfessionList.Add("Student")
        ProfessionList.Add("Others")


        Return ProfessionList
    End Function

    Public Function GetPaymentStatus() As ArrayList
        Dim List As New ArrayList
        List.Add("Paid")
        List.Add("Partial")
        Return List
    End Function

    Public Function getCasesUploadedCountriesList() As DataTable

        Dim DT As New DataTable
        Dim Query As String
        Dim Obj As New clsUsers
        Query = "Select distinct country from cases"

        Try
            DT = Obj.FetchDataSet(Query)

        Catch err As DataException
            Throw New DataException("Error in connecting to DB  " & err.Message)
        Finally
            Obj = Nothing
        End Try

        Return DT
    End Function

    Public Function getProductGroupCode() As DataTable
        Dim DT As New DataTable
        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand()
        Try

            cmd.Connection = conn
            cmd.CommandText = "sp_getProductGroupCode"
            cmd.CommandType = CommandType.StoredProcedure
            conn.Open()
            cmd.ExecuteNonQuery()
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)


        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally
            conn.Close()
            cmd.Dispose()
            conn.Dispose()

        End Try

        Return DT
    End Function

    Public Function getContactPersonIDs() As DataTable
        Dim DT As New DataTable
        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand()
        Try

            cmd.Connection = conn
            cmd.CommandText = "sp_getAllContactPersonIDs"
            cmd.CommandType = CommandType.StoredProcedure
            conn.Open()
            cmd.ExecuteNonQuery()
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)


        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally
            conn.Close()
            cmd.Dispose()
            conn.Dispose()

        End Try

        Return DT
    End Function

    Public Function getCustomerIDs() As DataTable
        Dim DT As New DataTable
        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand()
        Try

            cmd.Connection = conn
            cmd.CommandText = "sp_getAllCustomerIDs"
            cmd.CommandType = CommandType.StoredProcedure
            conn.Open()
            cmd.ExecuteNonQuery()
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)


        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally
            conn.Close()
            cmd.Dispose()
            conn.Dispose()

        End Try

        Return DT
    End Function

    Public Function getLegislationUploadedCountriesList() As DataTable

        Dim DT As New DataTable
        Dim Query As String
        Dim Obj As New clsUsers
        Query = "Select distinct country from Legislation"

        Try
            DT = Obj.FetchDataSet(Query)

        Catch err As DataException
            Throw New DataException("Error in connecting to DB  " & err.Message)
        Finally
            Obj = Nothing
        End Try

        Return DT
    End Function

    Public Function getArticleUploadedCountriesList() As DataTable

        Dim DT As New DataTable
        Dim Query As String
        Dim Obj As New clsUsers
        Query = "Select distinct country from Article"

        Try
            DT = Obj.FetchDataSet(Query)

        Catch err As DataException
            Throw New DataException("Error in connecting to DB  " & err.Message)
        Finally
            Obj = Nothing
        End Try

        Return DT
    End Function

    Public Function getPracticeNotesUploadedCountriesList() As DataTable

        Dim DT As New DataTable
        Dim Query As String
        Dim Obj As New clsUsers
        Query = "Select distinct country from reference_PRACTICENOTES"

        Try
            DT = Obj.FetchDataSet(Query)

        Catch err As DataException
            Throw New DataException("Error in connecting to DB  " & err.Message)
        Finally
            Obj = Nothing
        End Try

        Return DT
    End Function

    Public Function getPrecedentsUploadedCountriesList() As DataTable

        Dim DT As New DataTable
        Dim Query As String
        Dim Obj As New clsUsers
        Query = "Select distinct country from Precedents"

        Try
            DT = Obj.FetchDataSet(Query)

        Catch err As DataException
            Throw New DataException("Error in connecting to DB  " & err.Message)
        Finally
            Obj = Nothing
        End Try

        Return DT
    End Function

    Public Function getFormsUploadedCountriesList() As DataTable

        Dim DT As New DataTable
        Dim Query As String
        Dim Obj As New clsUsers
        Query = "Select distinct country from Reference_form"

        Try
            DT = Obj.FetchDataSet(Query)

        Catch err As DataException
            Throw New DataException("Error in connecting to DB  " & err.Message)
        Finally
            Obj = Nothing
        End Try

        Return DT
    End Function

    Public Function getCurrentMonthRevenueAllSites() As Double
        Dim Query As String
        Dim CurrentDate As Date
        Dim Month As Int16
        Dim Year As Int16
        Dim obj As New clsUsers
        Dim DT As New DataTable
        Dim Result As Double
        CurrentDate = System.DateTime.Today
        Month = CurrentDate.Month()
        Year = CurrentDate.Year()


        Query = "select sum(tbl2.Total_ammount) from master_users as TBL1, Admin_Master as TBL2,invoiceMembers as TBL3 where (TBL2.Mode_Of_Payment='cheque' or TBL2.Mode_Of_Payment='credit card') and (TBL1.user_id_no = TBL2.user_id_no AND TBL2.user_id_no = TBL3.user_id_no )  AND month(TBL2.Confirmation_Date)=" & Month & " and year(TBL2.Confirmation_Date)= " & Year & "   "
        DT = obj.FetchDataSet(Query)
        Result = DT.Rows(0).Item(0)

        Query = ""
        Month = 0
        Year = 0
        obj = Nothing
        DT = Nothing

        Return Result
    End Function

    Public Function getCurrentMonthPaymentAllSites() As Double
        Dim Query As String
        Dim CurrentDate As Date
        Dim Month As Int16
        Dim Year As Int16
        Dim obj As New clsUsers
        Dim DT As New DataTable
        Dim Result As Double
        CurrentDate = System.DateTime.Today
        Month = CurrentDate.Month()
        Year = CurrentDate.Year()


        Query = "select sum(tbl2.ammount_paid) from master_users as TBL1, Admin_Master as TBL2,invoiceMembers as TBL3 where (TBL2.Mode_Of_Payment='cheque' or TBL2.Mode_Of_Payment='credit card') and (TBL1.user_id_no = TBL2.user_id_no AND TBL2.user_id_no = TBL3.user_id_no )  AND month(TBL2.Confirmation_Date)=" & Month & " and year(TBL2.Confirmation_Date)= " & Year & "   "
        DT = obj.FetchDataSet(Query)
        Result = DT.Rows(0).Item(0)

        Query = ""
        Month = 0
        Year = 0
        obj = Nothing
        DT = Nothing

        Return Result
    End Function



    Public Function getCurrentMonthInvoicesAllSites() As Long
        Dim Query As String
        Dim CurrentDate As Date
        Dim Month As Int16
        Dim Year As Int16
        Dim obj As New clsUsers
        Dim DT As New DataTable
        Dim Result As Long
        CurrentDate = System.DateTime.Today
        Month = CurrentDate.Month()
        Year = CurrentDate.Year()

        Query = "select count(TBL3.invoice_no) from master_users as TBL1, Admin_Master as TBL2,invoiceMembers as TBL3 where (TBL2.Mode_Of_Payment='cheque' or TBL2.Mode_Of_Payment='credit card') and (TBL1.user_id_no = TBL2.user_id_no AND TBL2.user_id_no = TBL3.user_id_no )  AND month(TBL2.Confirmation_Date)=" & Month & " and year(TBL2.Confirmation_Date)= " & Year & " "
        DT = obj.FetchDataSet(Query)
        Result = DT.Rows(0).Item(0)

        Query = ""
        Month = 0
        Year = 0
        obj = Nothing
        DT = Nothing

        Return Result
    End Function
    'Query = "select TBL3.invoice_no, TBL1.user_id_no, TBL1.First_Name, TBL1.Last_Name, TBL1.Firm_Name, TBL1.User_Name, TBL1.Site_Name , TBL2.Payment_Mode , TBL2.Mode_of_Payment , TBL2.Credit_Bank_Name , TBL2.Cheque_Bank_Name , TBL1.Group_Name ,  TBL2.Confirmation_Date , TBL2.Ammount_Paid, TBL2.Total_Ammount,TBL3.Invoice_Date, tbl3.Invoice_Ammount from master_users as TBL1, Admin_Master as TBL2,invoiceMembers as TBL3 where (TBL2.Mode_Of_Payment='cheque' or TBL2.Mode_Of_Payment='credit card') and (TBL1.user_id_no = TBL2.user_id_no AND TBL2.user_id_no = TBL3.user_id_no )  AND month(TBL2.Confirmation_Date)=" & Month & " and year(TBL2.Confirmation_Date)= " & Year & " and TBL1.Site_Name like '%" & SiteName & "%'  and TBL3.Invoice_Status='Cancel' "

    Public Function getCurrentMonthCancelInvoicesAllSites() As Long
        Dim Query As String
        Dim CurrentDate As Date
        Dim Month As Int16
        Dim Year As Int16
        Dim obj As New clsUsers
        Dim DT As New DataTable
        Dim Result As Long
        CurrentDate = System.DateTime.Today
        Month = CurrentDate.Month()
        Year = CurrentDate.Year()

        Query = "select count(TBL3.invoice_no) from master_users as TBL1, Admin_Master as TBL2,invoiceMembers as TBL3 where (TBL2.Mode_Of_Payment='cheque' or TBL2.Mode_Of_Payment='credit card') and (TBL1.user_id_no = TBL2.user_id_no AND TBL2.user_id_no = TBL3.user_id_no )  AND month(TBL2.Confirmation_Date)=" & Month & " and year(TBL2.Confirmation_Date)= " & Year & " and TBL3.Invoice_Status='Cancel' "
        DT = obj.FetchDataSet(Query)
        Result = DT.Rows(0).Item(0)

        Query = ""
        Month = 0
        Year = 0
        obj = Nothing
        DT = Nothing

        Return Result
    End Function


    Public Function GetIndustry() As ArrayList
        Dim IndustryList As New ArrayList

        IndustryList.Add("Banking/Finance /Real Estate")
        IndustryList.Add("Computer Related (IS/MIS/DP, Internet")
        IndustryList.Add("Computer Related - Hardware")
        IndustryList.Add("Computer Related (Software)")
        IndustryList.Add("Education/Research")
        IndustryList.Add("Engineering/Construction")
        IndustryList.Add("Manufacturing/Distribution")
        IndustryList.Add("Business Supplies or Services")
        IndustryList.Add("Medical/Health Services")
        IndustryList.Add("Entertainment/Media/publishing")
        IndustryList.Add("Hospitality / Travel Accommodation")
        IndustryList.Add("Consumer Retail/Wholesale")
        IndustryList.Add("Non-profit/membership organisations")
        IndustryList.Add("Government")
        IndustryList.Add("Legal Services")
        IndustryList.Add("Other")


        Return IndustryList
    End Function

    Public Function GetCreditCardTypes() As ArrayList
        Dim CreditCardList As New ArrayList
        CreditCardList.Add("master_users Card")
        CreditCardList.Add("Visa")
        CreditCardList.Add("American Express")
        Return CreditCardList
    End Function

    Public Function Years() As ArrayList
        Dim YearList As New ArrayList
        Dim i As Int16
        YearList.Add("")
        For i = 2004 To 2020
            YearList.Add(i & "")

        Next

        Return YearList
    End Function

    Public Function Days() As ArrayList
        Dim DayList As New ArrayList
        Dim i As Int16

        For i = 1 To 31
            DayList.Add(i & "")

        Next

        Return DayList
    End Function

    Public Function Months() As ArrayList
        Dim List As New ArrayList
        List.Add("")
        List.Add("January")
        List.Add("February")
        List.Add("March")
        List.Add("April")
        List.Add("May")
        List.Add("June")
        List.Add("July")
        List.Add("August")
        List.Add("September")
        List.Add("October")
        List.Add("November")
        List.Add("December")


        Return List

    End Function

    Public Function PaymentStatus() As ArrayList
        Dim List As New ArrayList
        List.Add("Confirm")
        List.Add("Payment Pending")

        'List.Add("Waiting")

        Return List

    End Function

    Public Overloads Function UserStatus() As ArrayList
        Dim List As New ArrayList
        List.Add("Confirm")
        List.Add("Payment Pending")
        List.Add("Suspend")
        List.Add("Terminate")
        Return List

    End Function

    Public Overloads Function UserStatus(ByVal flg As Boolean) As ArrayList
        Dim List As New ArrayList
        If flg = True Then
            List.Add(" ")
            List.Add("Confirm")
            List.Add("Payment Pending")
            List.Add("Suspend")
            List.Add("Terminate")
        Else
            List.Add("Confirm")
            List.Add("Payment Pending")
            List.Add("Suspend")
            List.Add("Terminate")
        End If

        Return List
    End Function

    Public Function InvoiceStatus() As ArrayList
        Dim List As New ArrayList
        List.Add("Confirm")

        List.Add("Cancel")

        Return List

    End Function

    Public Function InvoiceStatusType() As ArrayList
        Dim List As New ArrayList
        List.Add("Paid")
        List.Add("Active")
        List.Add("Cancelled")

        Return List

    End Function

    Public Function PayType() As ArrayList
        Dim List As New ArrayList
        List.Add("Partial")
        List.Add("Full")

        Return List

    End Function

    Public Function MonthConversion(ByVal sMonth As String) As Byte
        Dim Month As Byte
        If sMonth = "January" Then
            Month = 1
        ElseIf sMonth = "February" Then
            Month = 2

        ElseIf sMonth = "March" Then
            Month = 3

        ElseIf sMonth = "April" Then
            Month = 4

        ElseIf sMonth = "May" Then
            Month = 5

        ElseIf sMonth = "June" Then
            Month = 6

        ElseIf sMonth = "July" Then
            Month = 7

        ElseIf sMonth = "August" Then
            Month = 8

        ElseIf sMonth = "September" Then
            Month = 9

        ElseIf sMonth = "October" Then
            Month = 10

        ElseIf sMonth = "November" Then
            Month = 11

        ElseIf sMonth = "December" Then
            Month = 12
        End If

        Return Month

    End Function

    Public Function NewMonthConversion(ByVal sMonth As String) As String
        Dim Month As Byte
        If sMonth = "January" Then
            Month = "01"
        ElseIf sMonth = "February" Then
            Month = "02"

        ElseIf sMonth = "March" Then
            Month = "03"

        ElseIf sMonth = "April" Then
            Month = "04"

        ElseIf sMonth = "May" Then
            Month = "05"

        ElseIf sMonth = "June" Then
            Month = "06"

        ElseIf sMonth = "July" Then
            Month = "07"

        ElseIf sMonth = "August" Then
            Month = "08"

        ElseIf sMonth = "September" Then
            Month = "09"

        ElseIf sMonth = "October" Then
            Month = "10"

        ElseIf sMonth = "November" Then
            Month = "11"

        ElseIf sMonth = "December" Then
            Month = "12"
        End If

        Return Month

    End Function
End Class

'End Namespace
