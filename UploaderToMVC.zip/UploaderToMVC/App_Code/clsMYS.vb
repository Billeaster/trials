﻿Imports System.Data.SqlClient
Imports System.Exception

Public Class clsMYS
    Private ConnectionString As String
    Private Shared CnString As String
    Public Sub New()

        ConnectionString = ConfigurationSettings.AppSettings("ConnectionString")
        CnString = ConnectionString
        If ConnectionString = "" Then
            Throw New ApplicationException("Missing ConnectionString variable in web.config file.")
        End If

    End Sub

    Public Function CancelInvoice(ByVal InvoiceNo As String) As Boolean
        Dim UpdateRecord As Boolean
        Dim conn As New SqlConnection(ConnectionString)

        Dim cmd As New SqlCommand()
        Try

            cmd.Connection = conn
            cmd.CommandText = "sp_CancelMYSInvoice"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.Add("@invoice_no", SqlDbType.VarChar, 10).Value = InvoiceNo

            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            conn.Close()
            UpdateRecord = True
        Catch err As DataException
            Throw New ApplicationException("Error in inserting to DB  " & err.Message)
            UpdateRecord = False
        Finally
            conn.Close()
            cmd.Dispose()
        End Try

        Return UpdateRecord
    End Function

    Public Function DeleteEventParticipant(ByVal productID As Integer) As Boolean
        Dim DeleteRecord As Boolean
        Dim conn As New SqlConnection(ConnectionString)

        Dim Query As String = "delete from myseminars_PrintParticipant where EventID=@event_id"
        Dim cmd As New SqlCommand(Query, conn)
        Try

            cmd.Parameters.Add("@event_id", SqlDbType.BigInt).Value = productID


            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            conn.Close()
            DeleteRecord = True
        Catch err As DataException
            Throw New ApplicationException("Error in inserting to DB  " & err.Message)
            DeleteRecord = False
        Finally
            conn.Close()
            cmd.Dispose()
        End Try

        Return DeleteRecord
    End Function

    Public Overloads Function DisplayCompanyDetails(ByVal CustomerName As String) As DataTable
        Dim DT As New DataTable
        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand()
        'Dim Reader1 As SqlClient.SqlDataReader
        Try
            cmd.CommandText = "sp_getMYSCompanyDetails"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Connection = conn
            cmd.Parameters.Add("@customer", SqlDbType.VarChar, 35).Value = CustomerName
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)


        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally
            conn.Close()
        End Try

        Return DT
    End Function

    Public Function CustomerExists() As Boolean
        Dim Query As String = "select CustomerID from myseminars_Clients"

        Dim conn As New SqlConnection(ConnectionString)
        Dim Reader As SqlDataReader
        Dim Result As String = ""
        Dim Pwd As String
        Dim Found As Boolean
        Found = False
        Try
            Dim cmd As New SqlCommand(Query, conn)
            conn.Open()
            Reader = cmd.ExecuteReader

            While Reader.Read()
                Result = Reader("CustomerID")

            End While


            If Result = "" Then
                Found = False
            End If
            If Result <> "" Then
                Found = True
            End If


        Catch err As Exception
            Throw New ApplicationException("Error in connecting to DB " & err.Message)
        Finally
            conn.Close()
            Reader.Close()
            Reader = Nothing
            conn = Nothing
            Result = ""
            Query = ""

        End Try

        Return Found
    End Function

    Public Function InvoiceProductExists(ByVal InvoiceNo As Integer, ByVal eventID As Integer) As Boolean
        Dim Query As String = "select InvoiceNo from myseminars_InvoiceProduct where InvoiceNo=@InvoiceNo and EventID=@eid"

        Dim conn As New SqlConnection(ConnectionString)
        Dim Reader As SqlDataReader
        Dim Result As String = ""
        Dim Pwd As String
        Dim Found As Boolean
        Found = False
        Try
            Dim cmd As New SqlCommand(Query, conn)
            cmd.Parameters.Add("InvoiceNo", SqlDbType.BigInt).Value = InvoiceNo
            cmd.Parameters.Add("eid", SqlDbType.BigInt).Value = eventID
            conn.Open()
            Reader = cmd.ExecuteReader

            While Reader.Read()
                Result = Reader("InvoiceNo")

            End While


            If Result = "" Then
                Found = False
            End If
            If Result <> "" Then
                Found = True
            End If


        Catch err As Exception
            Throw New ApplicationException("Error in connecting to DB " & err.Message)
        Finally
            conn.Close()
            Reader.Close()
            Reader = Nothing
            conn = Nothing
            Result = ""
            Query = ""

        End Try

        Return Found
    End Function

    Public Function DeleteEvent(ByVal productName As String) As Boolean

        Dim DeleteRecord As Boolean = False

        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand
        Try
            cmd.Connection = conn
            cmd.CommandText = "sp_deleteStandardMYSProduct"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.Add("@productid", SqlDbType.VarChar, 10).Value = productName
            conn.Open()
            cmd.ExecuteNonQuery()
            conn.Close()
            DeleteRecord = True
        Catch err As Exception
            Throw New Exception("Error in inserting to DB  " & err.Message)
            DeleteRecord = False

        Finally
            conn.Close()
            cmd.Dispose()
        End Try
        Return DeleteRecord

    End Function

    Public Overloads Function DeleteRecord(ByVal Query As String) As Boolean

        DeleteRecord = False
        Dim Statement As String
        Statement = Query
        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand
        Try
            cmd.Connection = conn
            cmd.CommandType = CommandType.Text
            cmd.CommandText = Query
            conn.Open()
            cmd.ExecuteNonQuery()
            conn.Close()
            DeleteRecord = True
        Catch err As Exception
            Throw New Exception("Error in inserting to DB  " & err.Message)
            DeleteRecord = False

        Finally
            conn.Close()
            cmd.Dispose()
        End Try
        Return DeleteRecord

    End Function

    Public Function DeleteSubscriptionPayment(ByVal receiptNum As String) As Boolean

        Dim DeleteRecord As Boolean = False

        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand
        Try
            cmd.Connection = conn
            cmd.CommandText = "sp_deleteStandardMYSPayment"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.Add("@receiptnum", SqlDbType.VarChar, 10).Value = receiptNum
            conn.Open()
            cmd.ExecuteNonQuery()
            conn.Close()
            DeleteRecord = True
        Catch err As Exception
            Throw New Exception("Error in inserting to DB  " & err.Message)
            DeleteRecord = False

        Finally
            conn.Close()
            cmd.Dispose()
        End Try
        Return DeleteRecord

    End Function

    Public Function DeleteUser(ByVal userID As String) As Boolean

        Dim DeleteRecord As Boolean = False

        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand
        Try
            cmd.Connection = conn
            cmd.CommandText = "sp_deleteStandardMYSUser"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.Add("@userid", SqlDbType.VarChar, 10).Value = userID
            conn.Open()
            cmd.ExecuteNonQuery()
            conn.Close()
            DeleteRecord = True
        Catch err As Exception
            Throw New Exception("Error in inserting to DB  " & err.Message)
            DeleteRecord = False

        Finally
            conn.Close()
            cmd.Dispose()
        End Try
        Return DeleteRecord

    End Function

    Public Function DeleteCustomerParticipant(ByVal customerID As String) As Boolean
        Dim DeleteRecord As Boolean
        Dim conn As New SqlConnection(ConnectionString)

        Dim Query As String = "delete from myseminars_Participants where CustomerID=@customer_id"
        Dim cmd As New SqlCommand(Query, conn)
        Try

            cmd.Parameters.Add("@customer_id", SqlDbType.VarChar, 10).Value = customerID


            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            conn.Close()
            DeleteRecord = True
        Catch err As DataException
            Throw New ApplicationException("Error in inserting to DB  " & err.Message)
            DeleteRecord = False
        Finally
            conn.Close()
            cmd.Dispose()
        End Try

        Return DeleteRecord
    End Function

    Public Overloads Function DisplayBasicDetails(ByVal UserID As String, ByVal invoiceNo As Integer) As DataTable
        Dim DT As New DataTable
        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand()
        'Dim Reader1 As SqlClient.SqlDataReader
        Try
            cmd.CommandText = "sp_getBasicDetailsofMYSInvoice"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Connection = conn
            cmd.Parameters.Add("@UserID", SqlDbType.VarChar, 10).Value = UserID
            cmd.Parameters.Add("@invoiceno", SqlDbType.BigInt).Value = invoiceNo
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)


        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally
            conn.Close()
        End Try

        Return DT
    End Function

    Public Overloads Function DisplayAdvancedDetails(ByVal UserID As String, ByVal InvoiceNo As String) As DataTable
        Dim DT As New DataTable
        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand()
        'Dim Reader1 As SqlClient.SqlDataReader
        Try
            cmd.CommandText = "sp_getAdvancedDetailsofMYSInvoice"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Connection = conn
            cmd.Parameters.Add("@UserID", SqlDbType.VarChar, 10).Value = UserID
            cmd.Parameters.Add("@InvoiceNo", SqlDbType.VarChar, 10).Value = InvoiceNo
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)


        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally
            conn.Close()
        End Try

        Return DT
    End Function

    Public Overloads Function DisplayAdvancedUserDetails(ByVal UserID As String) As DataTable
        Dim DT As New DataTable
        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand()
        'Dim Reader1 As SqlClient.SqlDataReader
        Try
            cmd.CommandText = "sp_getAdvancedDetailsofMYSUser"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Connection = conn
            cmd.Parameters.Add("@UserID", SqlDbType.VarChar, 10).Value = UserID
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)


        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally
            conn.Close()
        End Try

        Return DT
    End Function

    Public Overloads Function DisplayReceiptDetails(ByVal InvoiceNo As String) As DataTable
        Dim DT As New DataTable
        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand()
        'Dim Reader1 As SqlClient.SqlDataReader
        Try
            cmd.CommandText = "sp_getMYSReceipt"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Connection = conn
            cmd.Parameters.Add("@invoice_no", SqlDbType.VarChar, 10).Value = InvoiceNo
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)


        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally
            conn.Close()
        End Try

        Return DT
    End Function

    Public Overloads Function DisplayReceiptNo(ByVal InvoiceNo As String) As DataTable
        Dim DT As New DataTable
        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand()
        'Dim Reader1 As SqlClient.SqlDataReader
        Try
            cmd.CommandText = "sp_getMYSReceiptNo"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Connection = conn
            cmd.Parameters.Add("@invoice_no", SqlDbType.VarChar, 10).Value = InvoiceNo
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)


        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally
            conn.Close()
        End Try

        Return DT
    End Function

    Public Function EventExists() As Boolean
        Dim Query As String = "select EventID from myseminars_Event"

        Dim conn As New SqlConnection(ConnectionString)
        Dim Reader As SqlDataReader
        Dim Result As String = ""
        Dim Pwd As String
        Dim Found As Boolean
        Found = False
        Try
            Dim cmd As New SqlCommand(Query, conn)

            conn.Open()
            Reader = cmd.ExecuteReader

            While Reader.Read()
                Result = Reader("EventID")

            End While


            If Result = "" Then
                Found = False
            End If
            If Result <> "" Then
                Found = True
            End If


        Catch err As Exception
            Throw New ApplicationException("Error in connecting to DB " & err.Message)
        Finally
            conn.Close()
            Reader.Close()
            Reader = Nothing
            conn = Nothing
            Result = ""
            Query = ""

        End Try

        Return Found
    End Function

    Public Overloads Function getDebtAmount() As Decimal

        Dim debts As Decimal
        Dim DT As New DataTable()
        Dim conn As New SqlConnection(ConnectionString)
        Dim Query As String = "select ISNULL(SUM(PM.Balance_Invoice),'0.00') As Debts from [elawdb].[dbo].myseminars_Invoice I  "
        Query &= "INNER JOIN [elawdb].[dbo].myseminars_Clients C ON c.CustomerID = i.CustomerID "
        Query &= "INNER JOIN [elawdb].[dbo].myseminars_InvoiceProduct ip ON i.InvoiceNo = ip.InvoiceNo "
        Query &= "INNER JOIN elawdb.dbo.myseminars_PaymentMaster PM ON i.InvoiceNo = PM.InvoiceNo "
        Query &= "INNER JOIN [elawdb].[dbo].myseminars_Payment p ON p.CusPayNo = PM.CusPayNo "
        Query &= "INNER JOIN [elawdb].[dbo].myseminars_Event pr ON pr.EventID = ip.EventID "

        Try
            Dim cmd As New SqlCommand(Query, conn)

            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)

            cmd = Nothing

            debts = DT.Rows(0).Item(0)
        Catch
            debts = 0.0
        Finally

        End Try

        Return debts
    End Function

    Public Overloads Function getEventCompanies(ByVal eventName As String) As DataTable

        Dim DT As New DataTable()
        Dim conn As New SqlConnection(ConnectionString)
        Dim Query As String = "select distinct c.CustomerName, cp.CPFName + ' ' + cp.CPLName As [ContactPerson], cp.CPEmail, cp.CPTelNo, c.FaxNo, c.Address1 + ' ' + c.Address2 As [Address] from myseminars_Clients c "
        Query &= "inner join myseminars_ContactPerson cp on c.CustomerID=cp.CustomerID "
        Query &= "inner join myseminars_Participants p on p.CustomerID =c.CustomerID "
        Query &= "inner join myseminars_PrintParticipant mpp on mpp.StaffID = p.StaffID "
        Query &= "inner join myseminars_Event e on e.EventID = mpp.EventID "
        Query &= "where e.EventName=@event"
        Dim cmd As New SqlCommand(Query, conn)
        Try

            cmd.Parameters.Add("event", SqlDbType.VarChar, 50).Value = eventName
            conn.Open()
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)

        Catch err As Exception
            Throw New ApplicationException("Error in connecting to DB " & err.Message)
        Finally
            conn.Close()
            Query = ""
            cmd = Nothing
        End Try

        Return DT
    End Function

    Public Overloads Function getEventParticipants(ByVal eventName As String) As DataTable

        Dim DT As New DataTable()
        Dim conn As New SqlConnection(ConnectionString)
        Dim Query As String = "select p.StaffName, c.CustomerName, p.JobTitle, p.Email, p.Telno, p.Faxno from myseminars_Clients c "
        Query &= "inner join myseminars_ContactPerson cp on c.CustomerID=cp.CustomerID "
        Query &= "inner join myseminars_Participants p on p.CustomerID =c.CustomerID "
        Query &= "inner join myseminars_PrintParticipant mpp on mpp.StaffID = p.StaffID "
        Query &= "inner join myseminars_Event e on e.EventID = mpp.EventID "
        Query &= "where e.EventName=@event"
        Dim cmd As New SqlCommand(Query, conn)
        Try

            cmd.Parameters.Add("event", SqlDbType.VarChar, 50).Value = eventName
            conn.Open()
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)

        Catch err As Exception
            Throw New ApplicationException("Error in connecting to DB " & err.Message)
        Finally
            conn.Close()
            Query = ""
            cmd = Nothing
        End Try

        Return DT
    End Function

    Public Overloads Function getAllStaffIDs(ByVal customerID As String) As DataTable

        Dim DT As New DataTable()
        Dim conn As New SqlConnection(ConnectionString)
        Dim Query As String = "select cs.StaffID from myseminars_Participants cs inner join myseminars_Clients c on c.CustomerID = cs.CustomerID where c.CustomerID=@cid"


        Dim cmd As New SqlCommand(Query, conn)
        Try

            cmd.Parameters.Add("cid", SqlDbType.VarChar, 10).Value = customerID
            conn.Open()
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)

        Catch err As Exception
            Throw New ApplicationException("Error in connecting to DB " & err.Message)
        Finally
            conn.Close()
            Query = ""
            cmd = Nothing
        End Try

        Return DT
    End Function

    Public Overloads Function getEventIDAndStaffID(ByVal customerID As String) As DataTable

        Dim DT As New DataTable()
        Dim conn As New SqlConnection(ConnectionString)
        Dim Query As String = "select mpp.EventID As ProductID,mpp.StaffID from myseminars_PrintParticipant mpp "
        Query &= "inner join myseminars_Participants cs on cs.StaffID = mpp.StaffID inner join myseminars_Clients c on c.CustomerID = cs.CustomerID "
        Query &= "where c.CustomerID=@cid"

        Dim cmd As New SqlCommand(Query, conn)
        Try

            cmd.Parameters.Add("cid", SqlDbType.VarChar, 10).Value = customerID
            conn.Open()
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)

        Catch err As Exception
            Throw New ApplicationException("Error in connecting to DB " & err.Message)
        Finally
            conn.Close()
            Query = ""
            cmd = Nothing
        End Try

        Return DT
    End Function

    Public Overloads Function getCustomerID(ByVal UserIdNo As String) As String

        Dim CustomerID As String
        Dim DT As New DataTable()
        Dim conn As New SqlConnection(ConnectionString)
        Dim Query As String = "select c.CustomerID from myseminars_Clients c inner join myseminars_Account a on a.CustomerID = c.CustomerID  "
        Query &= "inner join myseminars_User nu on nu.AccountID = a.AccountID where nu.UserID =@uid"
        Try
            Dim cmd As New SqlCommand(Query, conn)
            cmd.Parameters.Add("uid", SqlDbType.VarChar, 10).Value = UserIdNo

            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)

            cmd = Nothing

            CustomerID = DT.Rows(0).Item(0)
        Catch
            CustomerID = ""
        Finally

        End Try

        Return CustomerID
    End Function

    Public Overloads Function getInvoiceDetails(ByVal invoiceNo As Integer) As DataTable

        Dim DT As New DataTable()
        Dim conn As New SqlConnection(ConnectionString)
        Dim Query As String = "select e.EventName As ProductName, c.CustomerID + ' - ' + c.CustomerName As [Customer], ip.Quantity, i.DiscountFactor From myseminars_Invoice i "
        Query &= "inner join myseminars_InvoiceProduct ip ON i.InvoiceNo = ip.InvoiceNo  "
        Query &= "inner join myseminars_Event e ON e.EventID = ip.EventID "
        Query &= "inner join myseminars_Clients c on c.CustomerID = i.CustomerID  "
        Query &= "where i.InvoiceNo = @InvoiceNo"

        Dim cmd As New SqlCommand(Query, conn)
        Try

            cmd.Parameters.Add("InvoiceNo", SqlDbType.BigInt).Value = invoiceNo
            conn.Open()
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)

        Catch err As Exception
            Throw New ApplicationException("Error in connecting to DB " & err.Message)
        Finally
            conn.Close()
            Query = ""
            cmd = Nothing
        End Try

        Return DT
    End Function

    Public Overloads Function getFreeUserDetails(ByVal userID As String) As DataTable

        Dim DT As New DataTable()
        Dim conn As New SqlConnection(ConnectionString)
        Dim Query As String = "select c.CustomerName,cp.CPFName,cp.CPLName,nu.UserName"
        Query &= ",a.Reg_Date, a.AllocatedSize, c.Address1,c.Address2"
        Query &= ",c.city,c.State,c.postalcode,c.Country,c.PhoneNo"
        Query &= ",c.FaxNo,cp.CPEmail, nu.UserType from myseminars_Clients c "
        Query &= "INNER JOIN myseminars_ContactPerson cp on cp.CustomerID =c.CustomerID "
        Query &= "INNER JOIN myseminars_Account a ON a.CustomerID = c.CustomerID "
        Query &= "INNER JOIN myseminars_User nu ON nu.AccountID = a.AccountID  "
        Query &= "where nu.UserID=@UserID"
        Dim cmd As New SqlCommand(Query, conn)
        Try

            cmd.Parameters.Add("UserID", SqlDbType.VarChar, 10).Value = userID
            conn.Open()
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)

        Catch err As Exception
            Throw New ApplicationException("Error in connecting to DB " & err.Message)
        Finally
            conn.Close()
            Query = ""
            cmd = Nothing
        End Try

        Return DT
    End Function

    Public Overloads Function getParticipants(ByVal invoiceNo As Integer) As DataTable

        Dim DT As New DataTable()
        Dim conn As New SqlConnection(ConnectionString)
        Dim Query As String = "select s.StaffName from myseminars_Participants s "
        Query &= "inner join myseminars_PrintParticipant mpp on mpp.StaffID = s.StaffID "
        Query &= "inner join myseminars_Event e on e.EventID = mpp.EventID "
        Query &= "inner join myseminars_InvoiceProduct ip on ip.EventID = e.EventID "
        Query &= "inner join myseminars_Invoice i on i.InvoiceNo = ip.InvoiceNo "
        Query &= "where i.InvoiceNo = @InvoiceNo"

        Dim cmd As New SqlCommand(Query, conn)
        Try

            cmd.Parameters.Add("InvoiceNo", SqlDbType.BigInt).Value = invoiceNo
            conn.Open()
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)

        Catch err As Exception
            Throw New ApplicationException("Error in connecting to DB " & err.Message)
        Finally
            conn.Close()
            Query = ""
            cmd = Nothing
        End Try

        Return DT
    End Function

    Public Overloads Function getReason(ByVal UserIdNo As String) As String

        Dim reason As String
        Dim DT As New DataTable()
        Dim conn As New SqlConnection(ConnectionString)
        Dim Query As String = "select Remarks from myseminars_User where UserID=@UserID"
        Try
            Dim cmd As New SqlCommand(Query, conn)
            cmd.Parameters.Add("UserID", SqlDbType.VarChar, 10).Value = UserIdNo

            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)

            cmd = Nothing

            reason = DT.Rows(0).Item(0)
        Catch
            reason = ""
        Finally

        End Try

        Return reason
    End Function

    Public Overloads Function getStaffID() As Integer

        Dim staffID As Integer
        Dim DT As New DataTable()
        Dim conn As New SqlConnection(ConnectionString)
        Dim Query As String = "select MAX(StaffID) from myseminars_Participants"
        Try
            Dim cmd As New SqlCommand(Query, conn)


            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)

            cmd = Nothing

            staffID = DT.Rows(0).Item(0)
        Catch
            staffID = 0
        Finally

        End Try

        Return staffID
    End Function

    Public Overloads Function getStaffIDByCustomerAndEvent(ByVal customerID As String, ByVal eventID As Integer) As DataTable

        Dim DT As New DataTable()
        Dim conn As New SqlConnection(ConnectionString)
        Dim Query As String = "select mpp.StaffID from myseminars_PrintParticipant mpp "
        Query &= "inner join myseminars_Participants p on mpp.StaffID =p.StaffID  "
        Query &= "where p.CustomerID <> @cid and EventID = @eid"
        Dim cmd As New SqlCommand(Query, conn)
        Try

            cmd.Parameters.Add("cid", SqlDbType.VarChar, 10).Value = customerID
            cmd.Parameters.Add("eid", SqlDbType.Int).Value = eventID
            conn.Open()
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)

        Catch err As Exception
            Throw New ApplicationException("Error in connecting to DB " & err.Message)
        Finally
            conn.Close()
            Query = ""
            cmd = Nothing
        End Try

        Return DT
    End Function

    Public Overloads Function getStaffIDByNewCustomerAndEvent(ByVal customerID As String, ByVal eventID As Integer) As DataTable

        Dim DT As New DataTable()
        Dim conn As New SqlConnection(ConnectionString)
        Dim Query As String = "select mpp.StaffID from myseminars_PrintParticipant mpp "
        Query &= "inner join myseminars_Participants p on mpp.StaffID =p.StaffID  "
        Query &= "where p.CustomerID = @cid and EventID = @eid"
        Dim cmd As New SqlCommand(Query, conn)
        Try

            cmd.Parameters.Add("cid", SqlDbType.VarChar, 10).Value = customerID
            cmd.Parameters.Add("eid", SqlDbType.Int).Value = eventID
            conn.Open()
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)

        Catch err As Exception
            Throw New ApplicationException("Error in connecting to DB " & err.Message)
        Finally
            conn.Close()
            Query = ""
            cmd = Nothing
        End Try

        Return DT
    End Function

    Public Function GetSubscription(ByVal UserID As String) As DataTable
        Dim DT As New DataTable
        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand()
        'Dim Reader1 As SqlClient.SqlDataReader
        Try
            cmd.CommandText = "sp_getMYSSubscriptions"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Connection = conn
            cmd.Parameters.Add("@userid", SqlDbType.VarChar, 10).Value = UserID
            conn.Open()
            cmd.ExecuteNonQuery()
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)


        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally
            conn.Close()
            cmd.Dispose()
            conn.Dispose()
        End Try

        Return DT
    End Function

    Public Function GetUserType(ByVal UserID As String) As String
        Dim Query As String = "select UserType from myseminars_User where UserID =@UserID "

        Dim conn As New SqlConnection(ConnectionString)
        Dim Reader As SqlDataReader
        Dim UserType As String = ""
        Try
            Dim cmd As New SqlCommand(Query, conn)
            cmd.Parameters.Add("UserID", SqlDbType.VarChar, 10).Value = UserID
            conn.Open()
            Reader = cmd.ExecuteReader

            While Reader.Read()
                UserType = Reader("UserType")
            End While

        Catch err As Exception
            Throw New ApplicationException("Error in connecting to DB " & err.Message)
        Finally
            conn.Close()
            Reader.Close()
            Reader = Nothing
            conn = Nothing
            Query = ""

        End Try

        Return UserType
    End Function

    'Public Function InsertMYSUser(ByVal customerName As String, ByVal address As String, ByVal address2 As String, ByVal city As String, ByVal state As String, ByVal postalcode As String, ByVal country As String, ByVal phone_num As String, ByVal fax_num As String, ByVal status As String, ByVal first_name As String, ByVal last_name As String, ByVal position As String, ByVal tel_num As String, ByVal email As String, ByVal account As String, ByVal asize As String, ByVal account_type As String, ByVal user_name As String, ByVal password As String, ByVal customerID As String, ByVal CPID As String, ByVal accountID As String, ByVal userID As String, ByVal AccountExpiry As Date, ByVal adminName As String, ByVal comments As String) As Boolean
    '    Dim InsertRecord As Boolean
    '    Dim conn As New SqlConnection(ConnectionString)

    '    Dim cmd As New SqlCommand()
    '    Try

    '        cmd.Connection = conn
    '        cmd.CommandText = "sp_insertMYSUser"
    '        cmd.CommandType = CommandType.StoredProcedure
    '        cmd.Parameters.Add("@customerName", SqlDbType.VarChar, 35).Value = customerName
    '        cmd.Parameters.Add("@address1", SqlDbType.VarChar, 35).Value = address
    '        cmd.Parameters.Add("@address2", SqlDbType.VarChar, 35).Value = address2
    '        cmd.Parameters.Add("@city", SqlDbType.VarChar, 35).Value = city
    '        cmd.Parameters.Add("@state", SqlDbType.VarChar, 35).Value = state
    '        cmd.Parameters.Add("@postalcode", SqlDbType.VarChar, 35).Value = postalcode
    '        cmd.Parameters.Add("@country", SqlDbType.VarChar, 35).Value = country
    '        cmd.Parameters.Add("@phonenum", SqlDbType.VarChar, 18).Value = phone_num
    '        cmd.Parameters.Add("@faxnum", SqlDbType.VarChar, 18).Value = fax_num
    '        cmd.Parameters.Add("@status", SqlDbType.VarChar, 10).Value = status
    '        cmd.Parameters.Add("@firstname", SqlDbType.VarChar, 35).Value = first_name
    '        cmd.Parameters.Add("@lastname", SqlDbType.VarChar, 35).Value = last_name
    '        cmd.Parameters.Add("@position", SqlDbType.VarChar, 35).Value = position
    '        cmd.Parameters.Add("@telnum", SqlDbType.VarChar, 18).Value = tel_num
    '        cmd.Parameters.Add("@email", SqlDbType.VarChar, 35).Value = email
    '        cmd.Parameters.Add("@account", SqlDbType.VarChar, 25).Value = account
    '        cmd.Parameters.Add("@asize", SqlDbType.VarChar, 25).Value = asize
    '        cmd.Parameters.Add("@accttype", SqlDbType.VarChar, 10).Value = account_type
    '        cmd.Parameters.Add("@username", SqlDbType.VarChar, 20).Value = user_name
    '        cmd.Parameters.Add("@password", SqlDbType.VarChar, 15).Value = password
    '        cmd.Parameters.Add("@customerID", SqlDbType.VarChar, 10).Value = customerID
    '        cmd.Parameters.Add("@CPID", SqlDbType.VarChar, 10).Value = CPID
    '        cmd.Parameters.Add("@accountID", SqlDbType.VarChar, 10).Value = accountID
    '        cmd.Parameters.Add("@userID", SqlDbType.VarChar, 10).Value = userID
    '        cmd.Parameters.Add("@expiry_date", SqlDbType.DateTime).Value = AccountExpiry
    '        cmd.Parameters.Add("@admin", SqlDbType.VarChar, 10).Value = adminName
    '        cmd.Parameters.Add("@comments", SqlDbType.VarChar, 50).Value = comments
    '        conn.Open()

    '        cmd.ExecuteNonQuery() '.ExecuteReader() 

    '        conn.Close()
    '        InsertRecord = True
    '    Catch err As DataException
    '        Throw New ApplicationException("Error in inserting to DB  " & err.Message)
    '        InsertRecord = False
    '    Finally
    '        conn.Close()
    '        cmd.Dispose()
    '    End Try

    '    Return InsertRecord
    'End Function


    Public Function InsertMYSUser(ByVal customerName As String, ByVal address As String, ByVal address2 As String, ByVal city As String, ByVal state As String, ByVal postalcode As String, ByVal country As String, ByVal phone_num As String, ByVal fax_num As String, ByVal status As String, ByVal first_name As String, ByVal last_name As String, ByVal position As String, ByVal tel_num As String, ByVal email As String, ByVal account As String, ByVal asize As String, ByVal account_type As String, ByVal user_name As String, ByVal password As String, ByVal customerID As String, ByVal CPID As String, ByVal accountID As String, ByVal userID As String, ByVal AccountExpiry As Date, ByVal adminName As String, ByVal comments As String) As Boolean
        Dim InsertRecord As Boolean
        Dim conn As New SqlConnection(ConnectionString)

        Dim cmd As New SqlCommand()
        Try

            cmd.Connection = conn
            cmd.CommandText = "sp_insertMYSUser"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.Add("@customerName", SqlDbType.VarChar, 35).Value = customerName
            cmd.Parameters.Add("@address1", SqlDbType.VarChar, 35).Value = address
            cmd.Parameters.Add("@address2", SqlDbType.VarChar, 35).Value = address2
            cmd.Parameters.Add("@city", SqlDbType.VarChar, 35).Value = city
            cmd.Parameters.Add("@state", SqlDbType.VarChar, 35).Value = state
            cmd.Parameters.Add("@postalcode", SqlDbType.VarChar, 35).Value = postalcode
            cmd.Parameters.Add("@country", SqlDbType.VarChar, 35).Value = country
            cmd.Parameters.Add("@phonenum", SqlDbType.VarChar, 18).Value = phone_num
            cmd.Parameters.Add("@faxnum", SqlDbType.VarChar, 18).Value = fax_num
            cmd.Parameters.Add("@status", SqlDbType.VarChar, 10).Value = status
            cmd.Parameters.Add("@firstname", SqlDbType.VarChar, 35).Value = first_name
            cmd.Parameters.Add("@lastname", SqlDbType.VarChar, 35).Value = last_name
            cmd.Parameters.Add("@position", SqlDbType.VarChar, 35).Value = position
            cmd.Parameters.Add("@telnum", SqlDbType.VarChar, 18).Value = tel_num
            cmd.Parameters.Add("@email", SqlDbType.VarChar, 35).Value = email
            cmd.Parameters.Add("@account", SqlDbType.VarChar, 25).Value = account
            cmd.Parameters.Add("@asize", SqlDbType.VarChar, 25).Value = asize
            cmd.Parameters.Add("@accttype", SqlDbType.VarChar, 10).Value = account_type
            cmd.Parameters.Add("@username", SqlDbType.VarChar, 20).Value = user_name
            cmd.Parameters.Add("@password", SqlDbType.VarChar, 15).Value = password
            cmd.Parameters.Add("@customerID", SqlDbType.VarChar, 10).Value = customerID
            cmd.Parameters.Add("@CPID", SqlDbType.VarChar, 10).Value = CPID
            cmd.Parameters.Add("@accountID", SqlDbType.VarChar, 10).Value = accountID
            cmd.Parameters.Add("@userID", SqlDbType.VarChar, 10).Value = userID
            cmd.Parameters.Add("@expiry_date", SqlDbType.DateTime).Value = AccountExpiry
            cmd.Parameters.Add("@admin", SqlDbType.VarChar, 10).Value = adminName
            cmd.Parameters.Add("@comments", SqlDbType.VarChar, 50).Value = comments
            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            conn.Close()
            InsertRecord = True
        Catch err As DataException
            Throw New ApplicationException("Error in inserting to DB  " & err.Message)
            InsertRecord = False
        Finally
            conn.Close()
            cmd.Dispose()
        End Try

        Return InsertRecord
    End Function


    Public Function InsertMYSGroup(ByVal groupID As String, ByVal accountID As String, ByVal groupName As String, ByVal email As String, ByVal noOfUsers As Integer, ByVal status As String, ByVal comments As String, ByVal admin As String) As Boolean
        Dim InsertRecord As Boolean
        Dim conn As New SqlConnection(ConnectionString)

        Dim Query As String = "insert into [myseminars_Group](GroupID,AccountID,GName,EmailID,No_Of_Members,Status,Remarks,CreatedStaff) values(@GroupID,@accountID,@gname,@emailid,@no_of_users,@status,@comments,@admin)"
        Dim cmd As New SqlCommand(Query, conn)
        Try

            cmd.Parameters.Add("@GroupID", SqlDbType.VarChar, 10).Value = groupID
            cmd.Parameters.Add("@accountID", SqlDbType.VarChar, 10).Value = AccountID
            cmd.Parameters.Add("@gname", SqlDbType.VarChar, 20).Value = groupName
            cmd.Parameters.Add("@emailid", SqlDbType.VarChar, 35).Value = email
            cmd.Parameters.Add("@no_of_users", SqlDbType.Int).Value = noOfUsers

            cmd.Parameters.Add("@status", SqlDbType.VarChar, 10).Value = status
            cmd.Parameters.Add("@comments", SqlDbType.VarChar, 50).Value = comments
            cmd.Parameters.Add("@admin", SqlDbType.VarChar, 10).Value = admin

            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            conn.Close()
            InsertRecord = True
        Catch err As DataException
            Throw New ApplicationException("Error in inserting to DB  " & err.Message)
            InsertRecord = False
        Finally
            conn.Close()
            cmd.Dispose()
        End Try

        Return InsertRecord
    End Function

    Public Function InsertMYSGroupUser(ByVal userID As String, ByVal accountID As String, ByVal userName As String, ByVal password As String, ByVal groupID As String, ByVal admin As String) As Boolean
        Dim InsertRecord As Boolean
        Dim conn As New SqlConnection(ConnectionString)

        Dim Query As String = "insert into myseminars_User(UserID,AccountID,UserName,Password,UserType,GroupID,Status,StaffCreated) values(@userid,@accountID,@username,@password,'Group',@groupid,'Active',@admin)"
        Dim cmd As New SqlCommand(Query, conn)
        Try

            cmd.Parameters.Add("@userid", SqlDbType.VarChar, 10).Value = userID
            cmd.Parameters.Add("@accountID", SqlDbType.VarChar, 10).Value = accountID
            cmd.Parameters.Add("@username", SqlDbType.VarChar, 20).Value = userName
            cmd.Parameters.Add("@password", SqlDbType.VarChar, 15).Value = password
            cmd.Parameters.Add("@groupid", SqlDbType.VarChar, 10).Value = groupID
            cmd.Parameters.Add("@admin", SqlDbType.VarChar, 10).Value = admin

            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            conn.Close()
            InsertRecord = True
        Catch err As DataException
            Throw New ApplicationException("Error in inserting to DB  " & err.Message)
            InsertRecord = False
        Finally
            conn.Close()
            cmd.Dispose()
        End Try

        Return InsertRecord
    End Function

    Public Function InsertMYSGroupUserDetails(ByVal customerName As String, ByVal address As String, ByVal address2 As String, ByVal city As String, ByVal state As String, ByVal postalcode As String, ByVal country As String, ByVal phone_num As String, ByVal fax_num As String, ByVal status As String, ByVal first_name As String, ByVal last_name As String, ByVal position As String, ByVal tel_num As String, ByVal email As String, ByVal account As String, ByVal asize As String, ByVal account_type As String, ByVal customerID As String, ByVal CPID As String, ByVal accountID As String, ByVal AccountExpiry As Date, ByVal adminName As String, ByVal comments As String) As Boolean
        Dim InsertRecord As Boolean
        Dim conn As New SqlConnection(ConnectionString)

        Dim cmd As New SqlCommand()
        Try

            cmd.Connection = conn
            cmd.CommandText = "sp_addAdvancedDetailsOfMYSGroupUser"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.Add("@customerName", SqlDbType.VarChar, 35).Value = customerName
            cmd.Parameters.Add("@address1", SqlDbType.VarChar, 35).Value = address
            cmd.Parameters.Add("@address2", SqlDbType.VarChar, 35).Value = address2
            cmd.Parameters.Add("@city", SqlDbType.VarChar, 35).Value = city
            cmd.Parameters.Add("@state", SqlDbType.VarChar, 35).Value = state
            cmd.Parameters.Add("@postalcode", SqlDbType.VarChar, 35).Value = postalcode
            cmd.Parameters.Add("@country", SqlDbType.VarChar, 35).Value = country
            cmd.Parameters.Add("@phonenum", SqlDbType.VarChar, 18).Value = phone_num
            cmd.Parameters.Add("@faxnum", SqlDbType.VarChar, 18).Value = fax_num
            cmd.Parameters.Add("@status", SqlDbType.VarChar, 10).Value = status
            cmd.Parameters.Add("@firstname", SqlDbType.VarChar, 35).Value = first_name
            cmd.Parameters.Add("@lastname", SqlDbType.VarChar, 35).Value = last_name
            cmd.Parameters.Add("@position", SqlDbType.VarChar, 35).Value = position
            cmd.Parameters.Add("@telnum", SqlDbType.VarChar, 18).Value = tel_num
            cmd.Parameters.Add("@email", SqlDbType.VarChar, 35).Value = email
            cmd.Parameters.Add("@account", SqlDbType.VarChar, 25).Value = account
            cmd.Parameters.Add("@asize", SqlDbType.VarChar, 25).Value = asize
            cmd.Parameters.Add("@accttype", SqlDbType.VarChar, 10).Value = account_type
            cmd.Parameters.Add("@customerID", SqlDbType.VarChar, 10).Value = customerID
            cmd.Parameters.Add("@CPID", SqlDbType.VarChar, 10).Value = CPID
            cmd.Parameters.Add("@accountID", SqlDbType.VarChar, 10).Value = accountID
            cmd.Parameters.Add("@expiry_date", SqlDbType.DateTime).Value = AccountExpiry
            cmd.Parameters.Add("@admin", SqlDbType.VarChar, 10).Value = adminName
            cmd.Parameters.Add("@comments", SqlDbType.VarChar, 50).Value = comments
            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            conn.Close()
            InsertRecord = True
        Catch err As DataException
            Throw New ApplicationException("Error in inserting to DB  " & err.Message)
            InsertRecord = False
        Finally
            conn.Close()
            cmd.Dispose()
        End Try

        Return InsertRecord
    End Function

    Public Function GetMYSCPID(ByVal CustomerID As String) As String
        Dim Query As String = "select CPID from myseminars_ContactPerson where CustomerID=@CustID "

        Dim conn As New SqlConnection(ConnectionString)
        Dim Reader As SqlDataReader
        Dim CPID As String = ""
        Try
            Dim cmd As New SqlCommand(Query, conn)
            cmd.Parameters.Add("CustID", SqlDbType.VarChar, 10).Value = CustomerID
            conn.Open()
            Reader = cmd.ExecuteReader

            While Reader.Read()
                CPID = Reader("CPID")
            End While





        Catch err As Exception
            Throw New ApplicationException("Error in connecting to DB " & err.Message)
        Finally
            conn.Close()
            Reader.Close()
            Reader = Nothing
            conn = Nothing
            Query = ""

        End Try

        Return CPID
    End Function

    Public Function InsertEvent(ByVal eventName As String, ByVal pDate As Date, ByVal price As Decimal, ByVal status As String, ByVal remarks As String, ByVal adminName As String, ByVal eventCode As String, ByVal eventType As String, ByVal eventDate As Date, ByVal eventTime As String, ByVal eventDetails As String) As Boolean
        Dim InsertRecord As Boolean
        Dim conn As New SqlConnection(ConnectionString)

        Dim Query As String = "insert into myseminars_Event(EventName,PDate,UnitPrice,[Status],Remarks,CreatedStaff,EventCode,EventType,EventDate,EventTime,EventDetails) values(@product, @pdate,@price,@status,@comments,@staff,@pcode,@etype,@edate,@etime,@edetails)"
        Dim cmd As New SqlCommand(Query, conn)
        Try

            cmd.Parameters.Add("@product", SqlDbType.VarChar, 100).Value = eventName
            cmd.Parameters.Add("@pdate", SqlDbType.Date).Value = pDate
            cmd.Parameters.Add("@price", SqlDbType.Money).Value = price
            cmd.Parameters.Add("@status", SqlDbType.VarChar, 10).Value = status
            cmd.Parameters.Add("@comments", SqlDbType.VarChar, 50).Value = remarks
            cmd.Parameters.Add("@staff", SqlDbType.VarChar, 10).Value = adminName
            cmd.Parameters.Add("@pcode", SqlDbType.VarChar, 10).Value = eventCode
            cmd.Parameters.Add("@etype", SqlDbType.VarChar, 10).Value = eventType
            cmd.Parameters.Add("@edate", SqlDbType.Date).Value = eventDate
            cmd.Parameters.Add("@etime", SqlDbType.VarChar, 20).Value = eventTime
            cmd.Parameters.Add("@edetails", SqlDbType.VarChar, 50).Value = eventDetails
            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            conn.Close()
            InsertRecord = True
        Catch err As DataException
            Throw New ApplicationException("Error in inserting to DB  " & err.Message)
            InsertRecord = False
        Finally
            conn.Close()
            cmd.Dispose()
        End Try

        Return InsertRecord
    End Function

    Public Function InsertNewInvoice(ByVal customerID As String, ByVal Factor As Decimal, ByVal totalAmount As Decimal, ByVal status As String, ByVal product_num As String, ByVal quantity As Integer, ByVal PayType As String, ByVal PayStatus As String, ByVal PaymentMode As String, ByVal expiryDate As String, ByVal CPID As String, ByVal adminName As String, ByVal reason_dis As String) As Boolean
        Dim InsertRecord As Boolean
        Dim conn As New SqlConnection(ConnectionString)

        Dim cmd As New SqlCommand()
        Try

            cmd.Connection = conn
            cmd.CommandText = "sp_InsertNewMYSInvoice"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.Add("@customerID", SqlDbType.VarChar, 10).Value = customerID
            Dim spm As SqlParameter = cmd.Parameters.Add("@dfactor", SqlDbType.Float)
            spm.Value = Factor
            'spm.Precision = 8
            'spm.Scale = 8
            cmd.Parameters.Add("@price", SqlDbType.Money).Value = totalAmount
            cmd.Parameters.Add("@status", SqlDbType.VarChar, 10).Value = status
            cmd.Parameters.Add("@productno", SqlDbType.VarChar, 10).Value = product_num
            cmd.Parameters.Add("@quantity", SqlDbType.Int).Value = quantity
            cmd.Parameters.Add("@paytype", SqlDbType.VarChar, 10).Value = PayType
            cmd.Parameters.Add("@paystatus", SqlDbType.VarChar, 10).Value = PayStatus
            cmd.Parameters.Add("@paymentmode", SqlDbType.VarChar, 11).Value = PaymentMode
            cmd.Parameters.Add("@ccexpirydate", SqlDbType.Date).Value = expiryDate
            cmd.Parameters.Add("@CPID", SqlDbType.VarChar, 10).Value = CPID
            cmd.Parameters.Add("@admin", SqlDbType.VarChar, 10).Value = adminName
            cmd.Parameters.Add("@reason_dis", SqlDbType.VarChar, 100).Value = reason_dis
            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            conn.Close()
            InsertRecord = True
        Catch err As DataException
            Throw New ApplicationException("Error in inserting to DB  " & err.Message)
            InsertRecord = False
        Finally
            conn.Close()
            cmd.Dispose()
        End Try

        Return InsertRecord
    End Function

    Public Function GetCancelledInvoice() As DataSet
        Dim DS As DataSet = FetchDataSet3("sp_getCancelledMYSInvoice")

        Return DS
    End Function

    Public Function GetCancelledInvoiceByDate(ByVal date1 As String, ByVal date2 As String) As DataSet
        Dim ds As New DataSet()
        Dim myParameter1 As SqlParameter
        Dim myParameter2 As SqlParameter

        Try
            Dim conn As New SqlConnection(ConnectionString)

            Dim cmd As New SqlCommand()
            cmd.Connection = conn
            cmd.CommandText = "sp_getCancelledMYSInvoiceByDate"
            cmd.CommandType = CommandType.StoredProcedure
            myParameter1 = cmd.CreateParameter()
            myParameter1.ParameterName = "@date1"
            myParameter1.Direction = ParameterDirection.Input
            myParameter1.SqlDbType = SqlDbType.DateTime

            myParameter1.Value = date1.ToString()
            cmd.Parameters.Add(myParameter1)

            myParameter2 = cmd.CreateParameter()
            myParameter2.ParameterName = "@date2"
            myParameter2.Direction = ParameterDirection.Input
            myParameter2.SqlDbType = SqlDbType.DateTime

            myParameter2.Value = date2.ToString()
            cmd.Parameters.Add(myParameter2)

            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            Dim adapter As New SqlDataAdapter(cmd)

            adapter.Fill(ds)
            conn.Close()

        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally

        End Try

        Return ds
    End Function

    Public Function GetCancelledInvoiceOrderBy(ByVal criteria As String, ByVal order As String) As DataSet
        Dim ds As New DataSet()
        Dim myParameter1 As SqlParameter
        Dim myParameter2 As SqlParameter

        Try
            Dim conn As New SqlConnection(ConnectionString)

            Dim cmd As New SqlCommand()
            cmd.Connection = conn
            cmd.CommandText = "sp_getCancelledMYSInvoiceOrderBy"
            cmd.CommandType = CommandType.StoredProcedure
            myParameter1 = cmd.CreateParameter()
            myParameter1.ParameterName = "@criteria"
            myParameter1.Direction = ParameterDirection.Input
            myParameter1.SqlDbType = SqlDbType.VarChar

            myParameter1.Value = criteria
            cmd.Parameters.Add(myParameter1)
            myParameter2 = cmd.CreateParameter()
            myParameter2.ParameterName = "@order"
            myParameter2.Direction = ParameterDirection.Input
            myParameter2.SqlDbType = SqlDbType.VarChar

            myParameter2.Value = order
            cmd.Parameters.Add(myParameter2)

            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            Dim adapter As New SqlDataAdapter(cmd)

            adapter.Fill(ds)
            conn.Close()

        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally

        End Try

        Return ds
    End Function

    Public Function getMYSCustomer() As DataSet
        Dim Query As String = "select c.CustomerID + ' - ' + c.CustomerName As [Customer] from myseminars_Clients c inner join myseminars_Account a on a.CustomerID =c.CustomerID where a.Acct_Type <> 'Free'"
        Dim DS As DataSet = FetchDataSet(Query, "myseminars_Clients")
        Return DS
    End Function

    Public Function getEvent() As DataSet


        Dim conn As New SqlConnection(ConnectionString)
        Dim ds As New DataSet
        Try

            Dim cmd As New SqlCommand("select EventName As [ProductName],eventid as [product_id] From myseminars_Event where  Status='Active'")
            cmd.Connection = conn
            Dim adapter As New SqlDataAdapter(cmd)

            adapter.Fill(ds, "myseminars_Event")

        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally
            conn.Close()
        End Try

        Return ds
    End Function

    Public Function GetEventID(ByVal ProductName As String) As String
        Dim Query As String = "select EventID from myseminars_Event where EventName=@PName"

        Dim conn As New SqlConnection(ConnectionString)
        Dim Reader As SqlDataReader
        Dim ID As String = ""
        Try
            Dim cmd As New SqlCommand(Query, conn)
            cmd.Parameters.Add("PName", SqlDbType.VarChar, 100).Value = ProductName
            conn.Open()
            Reader = cmd.ExecuteReader

            While Reader.Read()
                ID = Reader("EventID")
            End While





        Catch err As Exception
            Throw New ApplicationException("Error in connecting to DB " & err.Message)
        Finally
            conn.Close()
            Reader.Close()
            Reader = Nothing
            conn = Nothing
            Query = ""

        End Try

        Return ID
    End Function

    Public Function GetEventPrice(ByVal EventName As String) As Decimal
        Dim Query As String = "select UnitPrice from myseminars_Event where EventName=@EN"

        Dim conn As New SqlConnection(ConnectionString)
        Dim Reader As SqlDataReader
        Dim Price As Decimal = 0.0
        Try
            Dim cmd As New SqlCommand(Query, conn)
            cmd.Parameters.Add("EN", SqlDbType.VarChar, 100).Value = EventName
            conn.Open()
            Reader = cmd.ExecuteReader

            While Reader.Read()
                Price = Convert.ToDecimal(Reader("UnitPrice"))
            End While





        Catch err As Exception
            Throw New ApplicationException("Error in connecting to DB " & err.Message)
        Finally
            conn.Close()
            Reader.Close()
            Reader = Nothing
            conn = Nothing
            Query = ""

        End Try

        Return Price
    End Function

    Public Function GetGroupID(ByVal UserID As String) As String
        Dim Query As String = "select GroupID from myseminars_User where UserID=@UserID "

        Dim conn As New SqlConnection(ConnectionString)
        Dim Reader As SqlDataReader
        Dim GroupID As String = ""
        Try
            Dim cmd As New SqlCommand(Query, conn)
            cmd.Parameters.Add("UserID", SqlDbType.VarChar, 10).Value = UserID
            conn.Open()
            Reader = cmd.ExecuteReader

            While Reader.Read()
                GroupID = Reader("GroupID")
            End While

        Catch err As Exception
            Throw New ApplicationException("Error in connecting to DB " & err.Message)
        Finally
            conn.Close()
            Reader.Close()
            Reader = Nothing
            conn = Nothing
            Query = ""

        End Try

        Return GroupID
    End Function

    Public Overloads Function getGroupIDByCustomerName(ByVal customerName As String) As String

        Dim groupID As String
        Dim DT As New DataTable()
        Dim conn As New SqlConnection(ConnectionString)
        Dim Query As String = "select nu.GroupID from myseminars_Account a inner join myseminars_Clients c on c.CustomerID = a.CustomerID inner join myseminars_User nu on nu.AccountID=a.AccountID where c.CustomerName=@CName"
        Try
            Dim cmd As New SqlCommand(Query, conn)
            cmd.Parameters.Add("CName", SqlDbType.VarChar, 35).Value = customerName

            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)

            cmd = Nothing

            groupID = DT.Rows(0).Item(0)
        Catch
            groupID = ""
        Finally

        End Try

        Return groupID
    End Function

    Public Function GetStandardAccount() As DataSet
        Dim DS As DataSet = FetchDataSet3("sp_getStandardMYSAccount")

        Return DS
    End Function

    Public Function GetStandardInvoice() As DataSet
        Dim DS As DataSet = FetchDataSet3("sp_getStandardMYSInvoice")

        Return DS
    End Function

    Public Function GetStandardInvoiceByCountry(ByVal country As String) As DataSet
        Dim ds As New DataSet()
        Dim myParameter1 As SqlParameter

        Try
            Dim conn As New SqlConnection(ConnectionString)

            Dim cmd As New SqlCommand()
            cmd.Connection = conn
            cmd.CommandText = "sp_getStandardMYSInvoiceByCountry"
            cmd.CommandType = CommandType.StoredProcedure
            myParameter1 = cmd.CreateParameter()
            myParameter1.ParameterName = "@country"
            myParameter1.Direction = ParameterDirection.Input
            myParameter1.SqlDbType = SqlDbType.VarChar

            myParameter1.Value = country
            cmd.Parameters.Add(myParameter1)


            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            Dim adapter As New SqlDataAdapter(cmd)

            adapter.Fill(ds)
            conn.Close()

        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally

        End Try

        Return ds
    End Function

    Public Function GetStandardInvoiceByAccountType(ByVal accountType As String) As DataSet
        Dim ds As New DataSet()
        Dim myParameter1 As SqlParameter

        Try
            Dim conn As New SqlConnection(ConnectionString)

            Dim cmd As New SqlCommand()
            cmd.Connection = conn
            cmd.CommandText = "sp_getStandardMYSInvoiceByAccountType"
            cmd.CommandType = CommandType.StoredProcedure
            myParameter1 = cmd.CreateParameter()
            myParameter1.ParameterName = "@account_type"
            myParameter1.Direction = ParameterDirection.Input
            myParameter1.SqlDbType = SqlDbType.VarChar

            myParameter1.Value = accountType
            cmd.Parameters.Add(myParameter1)


            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            Dim adapter As New SqlDataAdapter(cmd)

            adapter.Fill(ds)
            conn.Close()

        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally

        End Try

        Return ds
    End Function

    Public Function GetStandardInvoiceByPaymentMode(ByVal payMode As String) As DataSet
        Dim ds As New DataSet()
        Dim myParameter1 As SqlParameter

        Try
            Dim conn As New SqlConnection(ConnectionString)

            Dim cmd As New SqlCommand()
            cmd.Connection = conn
            cmd.CommandText = "sp_getStandardMYSInvoiceByPaymentMode"
            cmd.CommandType = CommandType.StoredProcedure
            myParameter1 = cmd.CreateParameter()
            myParameter1.ParameterName = "@paymentmode"
            myParameter1.Direction = ParameterDirection.Input
            myParameter1.SqlDbType = SqlDbType.VarChar

            myParameter1.Value = payMode
            cmd.Parameters.Add(myParameter1)

            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            Dim adapter As New SqlDataAdapter(cmd)

            adapter.Fill(ds)
            conn.Close()

        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally

        End Try

        Return ds
    End Function

    Public Function GetStandardInvoiceByInvoiceNo(ByVal invoiceNo As String) As DataSet
        Dim ds As New DataSet()
        Dim myParameter1 As SqlParameter


        Try
            Dim conn As New SqlConnection(ConnectionString)

            Dim cmd As New SqlCommand()
            cmd.Connection = conn
            cmd.CommandText = "sp_getStandardMYSInvoiceByInvoiceNo"
            cmd.CommandType = CommandType.StoredProcedure
            myParameter1 = cmd.CreateParameter()
            myParameter1.ParameterName = "@invoice_no"
            myParameter1.Direction = ParameterDirection.Input
            myParameter1.SqlDbType = SqlDbType.Int

            myParameter1.Value = invoiceNo.ToString()
            cmd.Parameters.Add(myParameter1)

            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            Dim adapter As New SqlDataAdapter(cmd)

            adapter.Fill(ds)
            conn.Close()

        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally

        End Try

        Return ds
    End Function

    Public Function GetStandardInvoiceByDate(ByVal date1 As String, ByVal date2 As String) As DataSet
        Dim ds As New DataSet()
        Dim myParameter1 As SqlParameter
        Dim myParameter2 As SqlParameter


        Try
            Dim conn As New SqlConnection(ConnectionString)

            Dim cmd As New SqlCommand()
            cmd.Connection = conn
            cmd.CommandText = "sp_getStandardMYSInvoiceByDate"
            cmd.CommandType = CommandType.StoredProcedure
            myParameter1 = cmd.CreateParameter()
            myParameter1.ParameterName = "@date1"
            myParameter1.Direction = ParameterDirection.Input
            myParameter1.SqlDbType = SqlDbType.DateTime

            myParameter1.Value = date1.ToString()
            cmd.Parameters.Add(myParameter1)

            myParameter2 = cmd.CreateParameter()
            myParameter2.ParameterName = "@date2"
            myParameter2.Direction = ParameterDirection.Input
            myParameter2.SqlDbType = SqlDbType.DateTime

            myParameter2.Value = date2.ToString()
            cmd.Parameters.Add(myParameter2)

            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            Dim adapter As New SqlDataAdapter(cmd)

            adapter.Fill(ds)
            conn.Close()

        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally

        End Try

        Return ds
    End Function

    Public Function GetStandardInvoiceByMonth(ByVal month As String, ByVal year As String) As DataSet
        Dim ds As New DataSet()
        Dim myParameter1 As SqlParameter
        Dim myParameter2 As SqlParameter

        Try
            Dim conn As New SqlConnection(ConnectionString)

            Dim cmd As New SqlCommand()
            cmd.Connection = conn
            cmd.CommandText = "sp_getStandardMYSInvoiceByMonth"
            cmd.CommandType = CommandType.StoredProcedure
            myParameter1 = cmd.CreateParameter()
            myParameter1.ParameterName = "@month"
            myParameter1.Direction = ParameterDirection.Input
            myParameter1.SqlDbType = SqlDbType.Int

            myParameter1.Value = month.ToString()
            cmd.Parameters.Add(myParameter1)
            myParameter2 = cmd.CreateParameter()
            myParameter2.ParameterName = "@year"
            myParameter2.Direction = ParameterDirection.Input
            myParameter2.SqlDbType = SqlDbType.Int

            myParameter2.Value = year.ToString()
            cmd.Parameters.Add(myParameter2)

            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            Dim adapter As New SqlDataAdapter(cmd)

            adapter.Fill(ds)
            conn.Close()

        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally

        End Try

        Return ds
    End Function

    Public Function GetStandardInvoiceOrderBy(ByVal criteria As String, ByVal order As String) As DataSet
        Dim ds As New DataSet()
        Dim myParameter1 As SqlParameter
        Dim myParameter2 As SqlParameter


        Try
            Dim conn As New SqlConnection(ConnectionString)

            Dim cmd As New SqlCommand()
            cmd.Connection = conn
            cmd.CommandText = "sp_getStandardMYSInvoiceOrderBy"
            cmd.CommandType = CommandType.StoredProcedure
            myParameter1 = cmd.CreateParameter()
            myParameter1.ParameterName = "@criteria"
            myParameter1.Direction = ParameterDirection.Input
            myParameter1.SqlDbType = SqlDbType.VarChar

            myParameter1.Value = criteria
            cmd.Parameters.Add(myParameter1)
            myParameter2 = cmd.CreateParameter()
            myParameter2.ParameterName = "@order"
            myParameter2.Direction = ParameterDirection.Input
            myParameter2.SqlDbType = SqlDbType.VarChar

            myParameter2.Value = order
            cmd.Parameters.Add(myParameter2)

            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            Dim adapter As New SqlDataAdapter(cmd)

            adapter.Fill(ds)
            conn.Close()

        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally

        End Try

        Return ds
    End Function

    Public Function GetStandardInvoiceByProduct(ByVal product As String) As DataSet
        Dim ds As New DataSet()
        Dim myParameter1 As SqlParameter

        Try
            Dim conn As New SqlConnection(ConnectionString)

            Dim cmd As New SqlCommand()
            cmd.Connection = conn
            cmd.CommandText = "sp_getStandardMYSInvoiceByProduct"
            cmd.CommandType = CommandType.StoredProcedure
            myParameter1 = cmd.CreateParameter()
            myParameter1.ParameterName = "@product_name"
            myParameter1.Direction = ParameterDirection.Input
            myParameter1.SqlDbType = SqlDbType.VarChar

            myParameter1.Value = product
            cmd.Parameters.Add(myParameter1)

            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            Dim adapter As New SqlDataAdapter(cmd)

            adapter.Fill(ds)
            conn.Close()

        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally

        End Try

        Return ds
    End Function

    Public Function GetStandardProduct() As DataSet
        Dim DS As DataSet = FetchDataSet3("sp_getStandardMYSProduct")

        Return DS
    End Function

    Public Function GetStandardProductByDate(ByVal date1 As String, ByVal date2 As String) As DataSet
        Dim ds As New DataSet()
        Dim myParameter1 As SqlParameter
        Dim myParameter2 As SqlParameter

        Try
            Dim conn As New SqlConnection(ConnectionString)

            Dim cmd As New SqlCommand()
            cmd.Connection = conn
            cmd.CommandText = "sp_getStandardMYSProductByDate"
            cmd.CommandType = CommandType.StoredProcedure
            myParameter1 = cmd.CreateParameter()
            myParameter1.ParameterName = "@date1"
            myParameter1.Direction = ParameterDirection.Input
            myParameter1.SqlDbType = SqlDbType.DateTime

            myParameter1.Value = date1.ToString()
            cmd.Parameters.Add(myParameter1)

            myParameter2 = cmd.CreateParameter()
            myParameter2.ParameterName = "@date2"
            myParameter2.Direction = ParameterDirection.Input
            myParameter2.SqlDbType = SqlDbType.DateTime

            myParameter2.Value = date2.ToString()
            cmd.Parameters.Add(myParameter2)

            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            Dim adapter As New SqlDataAdapter(cmd)

            adapter.Fill(ds)
            conn.Close()

        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally

        End Try

        Return ds
    End Function

    Public Function GetStandardProductByMonth(ByVal month As String, ByVal year As String) As DataSet
        Dim ds As New DataSet()
        Dim myParameter1 As SqlParameter
        Dim myParameter2 As SqlParameter

        Try
            Dim conn As New SqlConnection(ConnectionString)

            Dim cmd As New SqlCommand()
            cmd.Connection = conn
            cmd.CommandText = "sp_getStandardMYSProductByMonth"
            cmd.CommandType = CommandType.StoredProcedure
            myParameter1 = cmd.CreateParameter()
            myParameter1.ParameterName = "@month"
            myParameter1.Direction = ParameterDirection.Input
            myParameter1.SqlDbType = SqlDbType.Int

            myParameter1.Value = month.ToString()
            cmd.Parameters.Add(myParameter1)
            myParameter2 = cmd.CreateParameter()
            myParameter2.ParameterName = "@year"
            myParameter2.Direction = ParameterDirection.Input
            myParameter2.SqlDbType = SqlDbType.Int

            myParameter2.Value = year.ToString()
            cmd.Parameters.Add(myParameter2)

            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            Dim adapter As New SqlDataAdapter(cmd)

            adapter.Fill(ds)
            conn.Close()

        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally

        End Try

        Return ds
    End Function

    Public Function GetStandardProductByIDOrName(ByVal criteria As String, ByVal type As String) As DataSet
        Dim ds As New DataSet()
        Dim myParameter1 As SqlParameter
        Dim myParameter2 As SqlParameter

        Try
            Dim conn As New SqlConnection(ConnectionString)

            Dim cmd As New SqlCommand()
            cmd.Connection = conn
            cmd.CommandText = "sp_getStandardMYSProductByIDOrName"
            cmd.CommandType = CommandType.StoredProcedure
            myParameter1 = cmd.CreateParameter()
            myParameter1.ParameterName = "@criteria"
            myParameter1.Direction = ParameterDirection.Input
            myParameter1.SqlDbType = SqlDbType.VarChar

            myParameter1.Value = criteria
            cmd.Parameters.Add(myParameter1)
            myParameter2 = cmd.CreateParameter()
            myParameter2.ParameterName = "@type"
            myParameter2.Direction = ParameterDirection.Input
            myParameter2.SqlDbType = SqlDbType.VarChar

            myParameter2.Value = type
            cmd.Parameters.Add(myParameter2)

            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            Dim adapter As New SqlDataAdapter(cmd)

            adapter.Fill(ds)
            conn.Close()

        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally

        End Try

        Return ds
    End Function

    Public Function GetStandardProductOrderBy(ByVal criteria As String, ByVal order As String) As DataSet
        Dim ds As New DataSet()
        Dim myParameter1 As SqlParameter
        Dim myParameter2 As SqlParameter


        Try
            Dim conn As New SqlConnection(ConnectionString)

            Dim cmd As New SqlCommand()
            cmd.Connection = conn
            cmd.CommandText = "sp_getStandardMYSProductOrderBy"
            cmd.CommandType = CommandType.StoredProcedure
            myParameter1 = cmd.CreateParameter()
            myParameter1.ParameterName = "@criteria"
            myParameter1.Direction = ParameterDirection.Input
            myParameter1.SqlDbType = SqlDbType.VarChar

            myParameter1.Value = criteria
            cmd.Parameters.Add(myParameter1)
            myParameter2 = cmd.CreateParameter()
            myParameter2.ParameterName = "@order"
            myParameter2.Direction = ParameterDirection.Input
            myParameter2.SqlDbType = SqlDbType.VarChar

            myParameter2.Value = order
            cmd.Parameters.Add(myParameter2)

            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            Dim adapter As New SqlDataAdapter(cmd)

            adapter.Fill(ds)
            conn.Close()

        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally

        End Try

        Return ds
    End Function

    Public Function GetStandardSalesReport() As DataSet
        Dim DS As DataSet = FetchDataSet3("sp_getStandardMYSSalesReport")

        Return DS
    End Function

    Public Function GetStandardSalesReportAmountDue() As DataSet
        Dim DS As DataSet = FetchDataSet3("sp_getStandardMYSSalesReportAmountDue")

        Return DS
    End Function

    Public Function GetStandardSalesReportByIDOrName(ByVal criteria As String, ByVal type As String) As DataSet
        Dim ds As New DataSet()
        Dim myParameter1 As SqlParameter
        Dim myParameter2 As SqlParameter


        Try
            Dim conn As New SqlConnection(ConnectionString)

            Dim cmd As New SqlCommand()
            cmd.Connection = conn
            cmd.CommandText = "sp_getStandardMYSSalesReportByIDOrName"
            cmd.CommandType = CommandType.StoredProcedure
            myParameter1 = cmd.CreateParameter()
            myParameter1.ParameterName = "@criteria"
            myParameter1.Direction = ParameterDirection.Input
            myParameter1.SqlDbType = SqlDbType.VarChar

            myParameter1.Value = criteria
            cmd.Parameters.Add(myParameter1)
            myParameter2 = cmd.CreateParameter()
            myParameter2.ParameterName = "@type"
            myParameter2.Direction = ParameterDirection.Input
            myParameter2.SqlDbType = SqlDbType.VarChar

            myParameter2.Value = type
            cmd.Parameters.Add(myParameter2)

            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            Dim adapter As New SqlDataAdapter(cmd)

            adapter.Fill(ds)
            conn.Close()

        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally

        End Try

        Return ds
    End Function

    Public Function GetStandardSalesReportOrderBy(ByVal criteria As String, ByVal order As String) As DataSet
        Dim ds As New DataSet()
        Dim myParameter1 As SqlParameter
        Dim myParameter2 As SqlParameter

        Try
            Dim conn As New SqlConnection(ConnectionString)

            Dim cmd As New SqlCommand()
            cmd.Connection = conn
            cmd.CommandText = "sp_getStandardMYSSalesReportOrderBy"
            cmd.CommandType = CommandType.StoredProcedure
            myParameter1 = cmd.CreateParameter()
            myParameter1.ParameterName = "@criteria"
            myParameter1.Direction = ParameterDirection.Input
            myParameter1.SqlDbType = SqlDbType.VarChar

            myParameter1.Value = criteria
            cmd.Parameters.Add(myParameter1)
            myParameter2 = cmd.CreateParameter()
            myParameter2.ParameterName = "@order"
            myParameter2.Direction = ParameterDirection.Input
            myParameter2.SqlDbType = SqlDbType.VarChar
            myParameter2.Value = order
            cmd.Parameters.Add(myParameter2)
            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            Dim adapter As New SqlDataAdapter(cmd)

            adapter.Fill(ds)
            conn.Close()

        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally

        End Try

        Return ds
    End Function

    Public Function GetStandardSalesReportByStatus(ByVal status As String) As DataSet
        Dim ds As New DataSet()
        Dim myParameter1 As SqlParameter


        Try
            Dim conn As New SqlConnection(ConnectionString)

            Dim cmd As New SqlCommand()
            cmd.Connection = conn
            cmd.CommandText = "sp_getStandardMYSSalesReportByStatus"
            cmd.CommandType = CommandType.StoredProcedure
            myParameter1 = cmd.CreateParameter()
            myParameter1.ParameterName = "@status"
            myParameter1.Direction = ParameterDirection.Input
            myParameter1.SqlDbType = SqlDbType.VarChar

            myParameter1.Value = status

            cmd.Parameters.Add(myParameter1)


            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            Dim adapter As New SqlDataAdapter(cmd)

            adapter.Fill(ds)
            conn.Close()

        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally

        End Try

        Return ds
    End Function

    Public Overloads Function getSalesReportByDate(ByVal date1 As Date, ByVal date2 As Date) As DataTable

        Dim DT As New DataTable()
        Dim conn As New SqlConnection(ConnectionString)
        Dim Query As String = "select I.InvoiceNo, PM.Status, C.CustomerName, p.AmountPaid, pr.EventCode + SUBSTRING(CONVERT(varchar,(YEAR(GETDATE()))),3,2) + '-' + CONVERT(varchar,I.InvoiceNo) As NewInvoiceNo, I.Status As [InvoiceStatus], pm.Balance_Invoice "
        Query &= "from [elawdb].[dbo].myseminars_Invoice I "
        Query &= "INNER JOIN [elawdb].[dbo].myseminars_Clients C ON c.CustomerID = i.CustomerID "
        Query &= "INNER JOIN [elawdb].[dbo].myseminars_InvoiceProduct ip ON i.InvoiceNo = ip.InvoiceNo "
        Query &= "INNER JOIN elawdb.dbo.myseminars_PaymentMaster PM ON i.InvoiceNo = PM.InvoiceNo "
        Query &= "INNER JOIN [elawdb].[dbo].myseminars_Payment p ON p.CusPayNo = PM.CusPayNo "
        Query &= "INNER JOIN [elawdb].[dbo].myseminars_Event pr ON pr.EventID = ip.EventID "
        Query &= "where I.IDate>=@date1 and I.IDate <= @date2"
        Dim cmd As New SqlCommand(Query, conn)
        Try

            cmd.Parameters.Add("date1", SqlDbType.Date).Value = date1
            cmd.Parameters.Add("date2", SqlDbType.Date).Value = date2
            conn.Open()
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)

        Catch err As Exception
            Throw New ApplicationException("Error in connecting to DB " & err.Message)
        Finally
            conn.Close()
            Query = ""
            cmd = Nothing
        End Try

        Return DT
    End Function

    Public Overloads Function getMonthlySalesReport(ByVal month As Integer, ByVal year As Integer) As DataTable

        Dim DT As New DataTable()
        Dim conn As New SqlConnection(ConnectionString)
        Dim Query As String = "select I.InvoiceNo, PM.Status, C.CustomerName, p.AmountPaid, pr.EventCode + SUBSTRING(CONVERT(varchar,(YEAR(GETDATE()))),3,2) + '-' + CONVERT(varchar,I.InvoiceNo) As NewInvoiceNo, I.Status As [InvoiceStatus], pm.Balance_Invoice "
        Query &= "from [elawdb].[dbo].myseminars_Invoice I "
        Query &= "INNER JOIN [elawdb].[dbo].myseminars_Clients C ON c.CustomerID = i.CustomerID "
        Query &= "INNER JOIN [elawdb].[dbo].myseminars_InvoiceProduct ip ON i.InvoiceNo = ip.InvoiceNo "
        Query &= "INNER JOIN elawdb.dbo.myseminars_PaymentMaster PM ON i.InvoiceNo = PM.InvoiceNo "
        Query &= "INNER JOIN [elawdb].[dbo].myseminars_Payment p ON p.CusPayNo = PM.CusPayNo "
        Query &= "INNER JOIN [elawdb].[dbo].myseminars_Event pr ON pr.EventID = ip.EventID "
        Query &= "where month(I.IDate)=@month and YEAR(I.IDate)=@year"
        Dim cmd As New SqlCommand(Query, conn)
        Try

            cmd.Parameters.Add("month", SqlDbType.Int).Value = month
            cmd.Parameters.Add("year", SqlDbType.Int).Value = year
            conn.Open()
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)

        Catch err As Exception
            Throw New ApplicationException("Error in connecting to DB " & err.Message)
        Finally
            conn.Close()
            Query = ""
            cmd = Nothing
        End Try

        Return DT
    End Function

    Public Function GetStandardUser() As DataSet
        Dim DS As DataSet = FetchDataSet3("sp_getStandardMYSUser")

        Return DS
    End Function

    Public Overloads Function getUserNameByCustomerName(ByVal customerName As String) As String

        Dim userName As String
        Dim DT As New DataTable()
        Dim conn As New SqlConnection(ConnectionString)
        Dim Query As String = "select nu.UserName from myseminars_Account a inner join myseminars_Clients c on c.CustomerID = a.CustomerID inner join myseminars_User nu on nu.AccountID =a.AccountID where c.CustomerName=@CName"
        Try
            Dim cmd As New SqlCommand(Query, conn)
            cmd.Parameters.Add("CName", SqlDbType.VarChar, 35).Value = customerName

            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)

            cmd = Nothing

            userName = DT.Rows(0).Item(0)
        Catch
            userName = ""
        Finally

        End Try

        Return userName
    End Function

    Public Overloads Function getUserNameByGroupID(ByVal groupID As String) As DataTable

        Dim DT As New DataTable()
        Dim conn As New SqlConnection(ConnectionString)
        Dim Query As String = "select nu.UserName from myseminars_Account a inner join myseminars_Clients c on c.CustomerID = a.CustomerID inner join myseminars_User nu on nu.AccountID =a.AccountID where nu.GroupID =@GID"
        Dim cmd As New SqlCommand(Query, conn)
        Try

            cmd.Parameters.Add("GID", SqlDbType.VarChar, 10).Value = groupID
            conn.Open()
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)




        Catch err As Exception
            Throw New ApplicationException("Error in connecting to DB " & err.Message)
        Finally
            conn.Close()
            Query = ""
            cmd = Nothing
        End Try

        Return DT
    End Function

    Public Function getUserId(ByVal UserName As String) As String



        Dim ErrMsg As String
        Dim conn As New SqlConnection(CnString)
        Dim Reader As SqlDataReader
        Dim user_id_no As String
        Dim SqlQuery As String = "select UserID from myseminars_User where UserName = @UserName"

        Dim cmd = New SqlCommand(SqlQuery, conn)
        cmd.Parameters.Add("UserName", SqlDbType.VarChar, 20).Value = UserName
        Dim msg As String

        Try
            conn.Open()
            Reader = cmd.ExecuteReader()
            While Reader.Read()
                user_id_no = Reader(0)
            End While


        Catch err As Exception
            msg = err.Message

        Finally
            conn.Close()
            conn = Nothing
            Reader = Nothing
            cmd = Nothing
        End Try


        Return user_id_no
    End Function

    Public Overloads Function DisplayAllDetailsOfUser(ByVal UserID As String) As DataTable
        Dim DT As New DataTable
        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand()
        'Dim Reader1 As SqlClient.SqlDataReader
        Try
            cmd.CommandText = "sp_getAllDetailsOfMYSUser"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Connection = conn
            cmd.Parameters.Add("@userid", SqlDbType.VarChar, 10).Value = UserID
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)


        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally
            conn.Close()
        End Try

        Return DT
    End Function

    Public Overloads Function DisplayUserID(ByVal InvoiceNo As String) As String
        Dim DT As New DataTable
        Dim conn As New SqlConnection(ConnectionString)
        Dim cmd As New SqlCommand()
        Dim userID As String = ""
        'Dim Reader1 As SqlClient.SqlDataReader
        Try
            cmd.CommandText = "sp_getMYSUserIDBasedOnInvoiceNo"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Connection = conn
            cmd.Parameters.Add("@InvoiceNo", SqlDbType.VarChar, 10).Value = InvoiceNo
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)

            If DT.Rows.Count > 0 Then
                userID = DT.Rows(0).Item(0)
            Else
                userID = ""
            End If


        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally
            conn.Close()
        End Try

        Return userID
    End Function

    Public Overloads Function getCusPayNo(ByVal invoiceNum As Integer) As Integer

        Dim CusPayNo As Integer
        Dim DT As New DataTable()
        Dim conn As New SqlConnection(ConnectionString)
        Dim Query As String = "select CusPayNo from myseminars_PaymentMaster where InvoiceNo=@invno"
        Try
            Dim cmd As New SqlCommand(Query, conn)
            cmd.Parameters.Add("invno", SqlDbType.BigInt).Value = invoiceNum

            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)

            cmd = Nothing

            CusPayNo = DT.Rows(0).Item(0)
        Catch
            CusPayNo = 0
        Finally

        End Try

        Return CusPayNo
    End Function

    Public Overloads Function getNoOfCusCP(ByVal productID As Integer, ByVal CPID As String) As Integer

        Dim numOfCusCP As Integer
        Dim DT As New DataTable()
        Dim conn As New SqlConnection(ConnectionString)
        Dim Query As String = "SELECT COUNT(*) As numOfCusCP from admin_CustomerCP_Product where ProductID=@productno and CPID=@CPID"
        Try
            Dim cmd As New SqlCommand(Query, conn)
            cmd.Parameters.Add("productno", SqlDbType.Int).Value = productID
            cmd.Parameters.Add("CPID", SqlDbType.VarChar, 10).Value = CPID

            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)

            cmd = Nothing

            numOfCusCP = DT.Rows(0).Item("numOfCusCP")

        Catch
            numOfCusCP = 0
        Finally

        End Try

        Return numOfCusCP
    End Function

    Public Overloads Function getNoOfUsers(ByVal customerID As String) As Integer

        Dim numOfUsers As Integer
        Dim DT As New DataTable()
        Dim conn As New SqlConnection(ConnectionString)
        Dim Query As String = "select COUNT(*) As NumOfUsers from myseminars_User u inner join myseminars_Account a on u.AccountID = a.AccountID inner join myseminars_Clients c on c.CustomerID = a.CustomerID where c.CustomerID =@cid"
        Try
            Dim cmd As New SqlCommand(Query, conn)
            cmd.Parameters.Add("cid", SqlDbType.Varchar, 10).Value = customerID

            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)

            cmd = Nothing

            numOfUsers = DT.Rows(0).Item(0)
        Catch
            numOfUsers = 0
        Finally

        End Try

        Return numOfUsers
    End Function

    Public Overloads Function getUserName(ByVal UserIdNo As String) As String

        Dim Username As String
        Dim DT As New DataTable()
        Dim conn As New SqlConnection(ConnectionString)
        Dim Query As String = "select UserName from myseminars_User where UserID=@UserID"
        Try
            Dim cmd As New SqlCommand(Query, conn)
            cmd.Parameters.Add("UserID", SqlDbType.VarChar, 10).Value = UserIdNo

            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)

            cmd = Nothing

            Username = DT.Rows(0).Item(0)
        Catch
            Username = ""
        Finally

        End Try

        Return Username
    End Function

    Public Function getUserLoginVerification(ByVal Username As String, ByVal Password As String) As Boolean

        Dim Query As String = "select UserName from myseminars_User where UserName =@UserName and Password =@Password "

        Dim conn As New SqlConnection(ConnectionString)
        Dim Reader As SqlDataReader
        Dim Result As String
        Dim Pwd As String
        Dim Found As Boolean
        Found = False
        Try
            Dim cmd As New SqlCommand(Query, conn)
            cmd.Parameters.Add("UserName", SqlDbType.VarChar, 20).Value = Username
            cmd.Parameters.Add("Password", SqlDbType.VarChar, 15).Value = Password
            conn.Open()
            Reader = cmd.ExecuteReader

            While Reader.Read()
                Result = Reader("UserName")
                '                Pwd = Reader("admin_password")
            End While


            If Result = "" Then
                Found = False
            End If
            If Result <> "" Then
                Found = True
            End If

            'If StrComp(Password, Pwd, CompareMethod.Binary) = 0 Then
            '    Found = True
            'Else
            '    Found = False
            'End If

        Catch err As Exception
            Throw New ApplicationException("Error in connecting to DB " & err.Message)
        Finally
            conn.Close()
            Reader.Close()
            Reader = Nothing
            conn = Nothing
            Result = ""
            Query = ""

        End Try

        Return Found
    End Function

    Public Function MYSCustomerExists() As Boolean
        Dim Query As String = "select CustomerID from myseminars_Clients"

        Dim conn As New SqlConnection(ConnectionString)
        Dim Reader As SqlDataReader
        Dim Result As String = ""
        Dim Pwd As String
        Dim Found As Boolean
        Found = False
        Try
            Dim cmd As New SqlCommand(Query, conn)
            conn.Open()
            Reader = cmd.ExecuteReader

            While Reader.Read()
                Result = Reader("CustomerID")

            End While


            If Result = "" Then
                Found = False
            End If
            If Result <> "" Then
                Found = True
            End If


        Catch err As Exception
            Throw New ApplicationException("Error in connecting to DB " & err.Message)
        Finally
            conn.Close()
            Reader.Close()
            Reader = Nothing
            conn = Nothing
            Result = ""
            Query = ""

        End Try

        Return Found
    End Function

    Private Overloads Function FetchDataSet(ByVal Query As String, ByVal tblName As String) As DataSet
        Dim ds As New DataSet
        'Dim Reader1 As SqlClient.SqlDataReader
        Try
            Dim conn As New SqlConnection(ConnectionString)
            Dim cmd As New SqlCommand(Query, conn)

            Dim adapter As New SqlDataAdapter(cmd)

            adapter.Fill(ds, tblName)
            conn.Close()

        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally

        End Try

        Return ds
    End Function

    Private Function FetchDataSet3(ByVal procedureName As String) As DataSet
        Dim ds As New DataSet()

        Try
            Dim conn As New SqlConnection(ConnectionString)

            Dim cmd As New SqlCommand()
            cmd.Connection = conn
            cmd.CommandText = procedureName
            cmd.CommandType = CommandType.StoredProcedure

            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            Dim adapter As New SqlDataAdapter(cmd)

            adapter.Fill(ds)
            conn.Close()

        Catch err As DataException
            Throw New ApplicationException("Error in connecting to DB  " & err.Message)
        Finally

        End Try

        Return ds
    End Function

    Public Function RenewAccount(ByVal UserID As String, ByVal AccountType As String, ByVal PaymentMode As String, ByVal InvoiceNum As Integer, ByVal chequeDate As Date, ByVal comments As String) As Boolean
        Dim UpdateRecord As Boolean
        Dim conn As New SqlConnection(ConnectionString)

        Dim cmd As New SqlCommand()
        Try

            cmd.Connection = conn
            cmd.CommandText = "sp_RenewMYSAccount"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.Add("@userid", SqlDbType.VarChar, 10).Value = UserID
            cmd.Parameters.Add("@acct_type", SqlDbType.VarChar, 10).Value = AccountType
            cmd.Parameters.Add("@paymode", SqlDbType.VarChar, 11).Value = PaymentMode
            cmd.Parameters.Add("@invoice_num", SqlDbType.BigInt).Value = InvoiceNum
            cmd.Parameters.Add("@chequedate", SqlDbType.Date).Value = chequeDate
            cmd.Parameters.Add("@comments", SqlDbType.VarChar, 50).Value = comments
            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            conn.Close()
            UpdateRecord = True
        Catch err As DataException
            Throw New ApplicationException("Error in inserting to DB  " & err.Message)
            UpdateRecord = False
        Finally
            conn.Close()
            cmd.Dispose()
        End Try

        Return UpdateRecord
    End Function

    Public Function UpdateUserBasicDetails(ByVal UserID As String, ByVal UserName As String, ByVal Status As String, ByVal UserType As String, ByVal firstName As String, ByVal lastName As String, ByVal profession As String, ByVal email As String, ByVal phone_num As String, ByVal AllotedSize As String, ByVal CustomerName As String, ByVal Address1 As String, ByVal Address2 As String, ByVal City As String, ByVal State As String, ByVal PostalCode As String, ByVal Country As String, ByVal FaxNum As String) As Boolean
        Dim UpdateRecord As Boolean
        Dim conn As New SqlConnection(ConnectionString)

        Dim cmd As New SqlCommand()
        Try

            cmd.Connection = conn
            cmd.CommandText = "sp_UpdateMYSUserBasicDetails"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.Add("@userid", SqlDbType.VarChar, 10).Value = UserID
            cmd.Parameters.Add("@username", SqlDbType.VarChar, 20).Value = UserName
            cmd.Parameters.Add("@status", SqlDbType.VarChar, 10).Value = Status
            cmd.Parameters.Add("@usertype", SqlDbType.VarChar, 10).Value = UserType
            cmd.Parameters.Add("@firstname", SqlDbType.VarChar, 35).Value = firstName
            cmd.Parameters.Add("@lastname", SqlDbType.VarChar, 35).Value = lastName
            cmd.Parameters.Add("@profession", SqlDbType.VarChar, 35).Value = profession
            cmd.Parameters.Add("@email", SqlDbType.VarChar, 35).Value = email
            cmd.Parameters.Add("@telno", SqlDbType.VarChar, 18).Value = phone_num
            cmd.Parameters.Add("@asize", SqlDbType.VarChar, 25).Value = AllotedSize
            cmd.Parameters.Add("@customername", SqlDbType.VarChar, 35).Value = CustomerName
            cmd.Parameters.Add("@address1", SqlDbType.VarChar, 35).Value = Address1
            cmd.Parameters.Add("@address2", SqlDbType.VarChar, 35).Value = Address2
            cmd.Parameters.Add("@city", SqlDbType.VarChar, 35).Value = City
            cmd.Parameters.Add("@state", SqlDbType.VarChar, 35).Value = State
            cmd.Parameters.Add("@postalcode", SqlDbType.VarChar, 35).Value = PostalCode
            cmd.Parameters.Add("@country", SqlDbType.VarChar, 35).Value = Country
            cmd.Parameters.Add("@faxno", SqlDbType.VarChar, 18).Value = FaxNum
            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            conn.Close()
            UpdateRecord = True
        Catch err As DataException
            Throw New ApplicationException("Error in inserting to DB  " & err.Message)
            UpdateRecord = False
        Finally
            conn.Close()
            cmd.Dispose()
        End Try

        Return UpdateRecord
    End Function

    Public Function UpdateUserAdvancedDetails(ByVal ReceiptNum As String, ByVal remarks As String) As Boolean
        Dim UpdateRecord As Boolean
        Dim conn As New SqlConnection(ConnectionString)

        Dim cmd As New SqlCommand()
        Try

            cmd.Connection = conn
            cmd.CommandText = "sp_UpdateMYSUserAdvancedDetails"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.Add("@receiptNum", SqlDbType.VarChar, 10).Value = ReceiptNum
            cmd.Parameters.Add("@remarks", SqlDbType.VarChar, 50).Value = remarks

            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            conn.Close()
            UpdateRecord = True
        Catch err As DataException
            Throw New ApplicationException("Error in inserting to DB  " & err.Message)
            UpdateRecord = False
        Finally
            conn.Close()
            cmd.Dispose()
        End Try

        Return UpdateRecord
    End Function

    Public Function UpdateReceiptDetails(ByVal InvoiceNo As String, ByVal ReceiptNo As String, ByVal amountPaid As Decimal, ByVal chequeNo As String, ByVal bank As String, ByVal status As String, ByVal payMode As String, ByVal ccdate As Date) As Boolean
        Dim UpdateRecord As Boolean
        Dim conn As New SqlConnection(ConnectionString)

        Dim cmd As New SqlCommand()
        Try

            cmd.Connection = conn
            cmd.CommandText = "sp_UpdateMYSReceiptDetails"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.Add("@invoice_no", SqlDbType.VarChar, 10).Value = InvoiceNo
            cmd.Parameters.Add("@receipt_no", SqlDbType.VarChar, 10).Value = ReceiptNo
            cmd.Parameters.Add("@amount_paid", SqlDbType.Money).Value = amountPaid
            cmd.Parameters.Add("@cheque_no", SqlDbType.VarChar, 25).Value = chequeNo
            cmd.Parameters.Add("@bank", SqlDbType.VarChar, 50).Value = bank
            cmd.Parameters.Add("@status", SqlDbType.VarChar, 10).Value = status
            cmd.Parameters.Add("@paymode", SqlDbType.VarChar, 11).Value = payMode
            cmd.Parameters.Add("@ccdate", SqlDbType.Date).Value = ccdate
            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            conn.Close()
            UpdateRecord = True
        Catch err As DataException
            Throw New ApplicationException("Error in inserting to DB  " & err.Message)
            UpdateRecord = False
        Finally
            conn.Close()
            cmd.Dispose()
        End Try

        Return UpdateRecord
    End Function

    Public Function UpdateReasonToDeactivate(ByVal UserID As String, ByVal Reason As String) As Boolean
        Dim UpdateRecord As Boolean
        Dim conn As New SqlConnection(ConnectionString)

        Dim cmd As New SqlCommand()
        Try

            cmd.Connection = conn
            cmd.CommandText = "sp_updateMYSReasonToActivateNDeactivate"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.Add("@user_id", SqlDbType.VarChar, 10).Value = UserID
            cmd.Parameters.Add("@criteria", SqlDbType.VarChar, 50).Value = Reason
            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            conn.Close()
            UpdateRecord = True
        Catch err As DataException
            Throw New ApplicationException("Error in inserting to DB  " & err.Message)
            UpdateRecord = False
        Finally
            conn.Close()
            cmd.Dispose()
        End Try











        Return UpdateRecord
    End Function

    Public Function UpdateInvoice(ByVal invoiceNum As Integer, ByVal customerID As String, ByVal discount As Decimal, ByVal totalAmount As Decimal, ByVal adminName As String) As Boolean
        Dim UpdateRecord As Boolean
        Dim conn As New SqlConnection(ConnectionString)

        Dim Query As String = "update myseminars_Invoice set CustomerID=@cid, IDate=GETDATE(), DiscountFactor = @discount, TotalAmount = @totalamount, Status = 'Active',CreatedStaff=@admin where InvoiceNo=@invno"
        Dim cmd As New SqlCommand(Query, conn)
        Try

            cmd.Parameters.Add("@cid", SqlDbType.VarChar, 10).Value = customerID
            Dim spm As SqlParameter = cmd.Parameters.Add("@discount", SqlDbType.Float)
            spm.Value = discount
            'spm.Precision = 4
            'spm.Scale = 2
            cmd.Parameters.Add("@totalamount", SqlDbType.Money).Value = totalAmount
            cmd.Parameters.Add("@admin", SqlDbType.VarChar, 10).Value = adminName
            cmd.Parameters.Add("@invno", SqlDbType.BigInt).Value = invoiceNum

            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            conn.Close()
            UpdateRecord = True
        Catch err As DataException
            Throw New ApplicationException("Error in inserting to DB  " & err.Message)
            UpdateRecord = False
        Finally
            conn.Close()
            cmd.Dispose()
        End Try

        Return UpdateRecord
    End Function

    Public Function UpdateInvoiceProduct(ByVal invoiceNum As Integer, ByVal newEventID As Integer, ByVal quantity As Integer, ByVal totalAmount As Decimal, ByVal adminName As String) As Boolean
        Dim UpdateRecord As Boolean
        Dim conn As New SqlConnection(ConnectionString)

        Dim Query As String = "update myseminars_InvoiceProduct set EventID=@eid, Quantity=@quantity, TotalAmount = @totalamount,CreatedStaff=@admin where InvoiceNo=@invno"
        Dim cmd As New SqlCommand(Query, conn)
        Try

            cmd.Parameters.Add("@eid", SqlDbType.BigInt).Value = newEventID
            cmd.Parameters.Add("@quantity", SqlDbType.Int).Value = quantity

            cmd.Parameters.Add("@totalamount", SqlDbType.Money).Value = totalAmount
            cmd.Parameters.Add("@admin", SqlDbType.VarChar, 10).Value = adminName
            cmd.Parameters.Add("@invno", SqlDbType.BigInt).Value = invoiceNum


            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            conn.Close()
            UpdateRecord = True
        Catch err As DataException
            Throw New ApplicationException("Error in inserting to DB  " & err.Message)
            UpdateRecord = False
        Finally
            conn.Close()
            cmd.Dispose()
        End Try

        Return UpdateRecord
    End Function

    Public Function UpdatePaymentMaster(ByVal invoiceNum As Integer, ByVal payType As String, ByVal totalAmount As Decimal, ByVal adminName As String) As Boolean
        Dim UpdateRecord As Boolean
        Dim conn As New SqlConnection(ConnectionString)

        Dim Query As String = "update myseminars_PaymentMaster set IDate=GETDATE(), PayType=@paytype, TotalAmount = @totalamount,Balance_Invoice=@totalamount,Status='Unpaid',CreatedStaff=@admin, DownPayment=0.00 where InvoiceNo=@invno"
        Dim cmd As New SqlCommand(Query, conn)
        Try

            cmd.Parameters.Add("@paytype", SqlDbType.VarChar, 10).Value = payType

            cmd.Parameters.Add("@totalamount", SqlDbType.Money).Value = totalAmount
            cmd.Parameters.Add("@admin", SqlDbType.VarChar, 10).Value = adminName
            cmd.Parameters.Add("@invno", SqlDbType.BigInt).Value = invoiceNum


            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            conn.Close()
            UpdateRecord = True
        Catch err As DataException
            Throw New ApplicationException("Error in inserting to DB  " & err.Message)
            UpdateRecord = False
        Finally
            conn.Close()
            cmd.Dispose()
        End Try

        Return UpdateRecord
    End Function

    Public Function UpdatePayment(ByVal cpNum As Integer, ByVal payMode As String, ByVal adminName As String) As Boolean
        Dim UpdateRecord As Boolean
        Dim conn As New SqlConnection(ConnectionString)

        Dim Query As String = "update myseminars_Payment set PDate=GETDATE(), AmountPaid=0.00,Form_Of_Payment=@paymode,CardNo='',CreditBankName='',CC_Expiry_Date='1/1/1900',ChequeNo='',ChequeBankName='',ChequeDate=GETDATE(),Status='Unpaid',CreatedStaff=@admin where CusPayNo=@cpn"
        Dim cmd As New SqlCommand(Query, conn)
        Try

            cmd.Parameters.Add("@paymode", SqlDbType.VarChar, 11).Value = payMode
            cmd.Parameters.Add("@admin", SqlDbType.VarChar, 10).Value = adminName
            cmd.Parameters.Add("@cpn", SqlDbType.BigInt).Value = cpNum


            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            conn.Close()
            UpdateRecord = True
        Catch err As DataException
            Throw New ApplicationException("Error in inserting to DB  " & err.Message)
            UpdateRecord = False
        Finally
            conn.Close()
            cmd.Dispose()
        End Try

        Return UpdateRecord
    End Function

    Public Function UpdateStaffFaxNo(ByVal faxNo As String, ByVal staffID As Integer) As Boolean
        Dim UpdateRecord As Boolean
        Dim conn As New SqlConnection(ConnectionString)

        Dim Query As String = "update myseminars_Participants set FaxNo=@fax where StaffID=(SELECT MAX(StaffID)- @staff_num from myseminars_Participants)"
        Dim cmd As New SqlCommand(Query, conn)
        Try

            cmd.Parameters.Add("@fax", SqlDbType.VarChar, 18).Value = faxNo
            cmd.Parameters.Add("@staff_num", SqlDbType.Int).Value = staffID

            conn.Open()

            cmd.ExecuteNonQuery() '.ExecuteReader() 

            conn.Close()
            UpdateRecord = True
        Catch err As DataException
            Throw New ApplicationException("Error in inserting to DB  " & err.Message)
            UpdateRecord = False
        Finally
            conn.Close()
            cmd.Dispose()
        End Try

        Return UpdateRecord
    End Function

    Public Shared Function isUserExist(ByVal UserName As String) As Boolean
        ''/*  This is for counting records fetched   */



        Dim FileCount As Int32 ' Because DataFile will always be 1 if it exist in table
        Dim ErrMsg As String
        Dim conn As New SqlConnection(CnString)
        Dim Reader As SqlDataReader
        Dim recCount As Int32
        Dim SqlQuery As String = "select count(*) from myseminars_User where UserName = @UserName"
        Dim cmd = New SqlCommand(SqlQuery, conn)
        cmd.Parameters.Add("UserName", SqlDbType.VarChar, 20).Value = UserName
        Dim msg As String

        Try
            conn.Open()
            Reader = cmd.ExecuteReader()
            While Reader.Read()
                FileCount = Reader(0)
            End While

            If FileCount = 0 Then
                isUserExist = False ' user not Exist
            Else
                isUserExist = True  ' user Exist
            End If

        Catch err As Exception
            msg = err.Message

        Finally
            conn.Close()
            conn = Nothing
            Reader = Nothing
            cmd = Nothing
        End Try


        Return isUserExist
    End Function

    Private Sub myErrorHandler(ByVal Err As Exception)
        Throw New ApplicationException("Error is..  " & Err.Message)
    End Sub
End Class
