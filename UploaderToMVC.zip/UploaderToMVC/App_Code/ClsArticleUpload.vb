﻿Imports Microsoft.VisualBasic
Imports System.IO
Imports System.Xml
Imports System.Data.SqlClient
Imports System.Data
Imports System.Globalization
Imports iTextSharp.text.pdf

Class ArticleInfo

    Public Shared strConnection As String
    Public Shared ConnectionStr As String
    Private ConnectionString As String
    
    Public Shared ReadOnly sGlobalConnectionString As String = "Data Source=DS09-DATASOLUTI\SQLELAW;initial catalog=elawdb;uid=sa;pwd=DSelaw@2017"

    Public Sub New(ByVal conn As String)
        ConnectionString = ConfigurationSettings.AppSettings(conn)
        ConnectionStr = conn
        If ConnectionString = "" Then
            Throw New ApplicationException("Missing ConnectionString variable in web.config file.")
        End If
    End Sub

    Public Overloads Function AddRecord(ByVal Query As String) As Boolean
        AddRecord = False
        Dim Statement As String
        Statement = Query
        Dim conn As New SqlConnection(sGlobalConnectionString)
        Dim cmd As New SqlCommand
        Try
            cmd.Connection = conn
            cmd.CommandType = CommandType.Text
            cmd.CommandText = Query
            conn.Open()
            cmd.ExecuteNonQuery()
            AddRecord = True
        Catch err As Exception
            AddRecord = False
            Throw New Exception("Error in inserting to DB  " & err.Message)
        Finally
            conn.Close()
            cmd = Nothing
        End Try
        Return AddRecord
    End Function

    Public Function ExecuteMyQuery(ByVal Query As String) As DataTable
        Dim DT As New DataTable()
        Dim conn As New SqlConnection(sGlobalConnectionString)
        Dim MSG As String

        Try
            Dim cmd As New SqlCommand(Query, conn)
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(DT)

        Catch err As Exception
            'Throw New ApplicationException("Error in connecting to DB  " & err.Message)
            MSG = err.Message
        Finally
            conn.Close()
        End Try
        Return DT

    End Function

    Public Overloads Function isFileExist(ByVal FileName As String, ByVal TableName As String) As Boolean
        Dim FileCount As Int32 ' Because DataFile will always be 1 if it exist in table
        Dim ErrMsg As String
        Dim DT As New DataTable()
        Dim msg As String
        Dim Query As String = "select count(*) from " & TableName & " where datafilename = '" & FileName & "'"
        Try
            DT = Me.ExecuteMyQuery(Query)
            FileCount = CInt(DT.Rows(0).Item(0))
            If FileCount = 0 Then
                isFileExist = False ' file not Exist
            Else
                isFileExist = True   ' File Exist
            End If
        Catch err As Exception
            msg = err.Message
        Finally
            FileCount = 0
            ErrMsg = ""
            DT = Nothing
            Query = ""
        End Try
        Return isFileExist
    End Function
End Class

Public Class ClsArticleUpload
    ' DECLARATION OF VARIABLE

    Public Shared ArticleBody As String = ""
    Public Shared Title As String = ""
    Public Shared Country As String = ""
    Public Shared Citation As String = ""
    Public Shared Author As String = ""
    Public Shared Subject As String = ""
    Public Shared Category As String = ""
    Public Shared Language As String = ""
    Public Shared Year As String = ""
    Public Shared ServerFileName As String = ""
    Public Shared BooleanText As String
    Public Shared FootNotes As String = ""
    Dim ObjDb As New ArticleInfo("ConnectionString")
    Public Shared StrError As String
    Public Shared XMLFile As String

    Public Sub ExtractArticle(ByVal Path As String)
        Dim xRead As XmlTextReader = New XmlTextReader(Path)
        Try
            While xRead.Read()
                Select Case xRead.NodeType
                    Case XmlNodeType.Element
                        If xRead.Name = "TITLE" Then
                            Title = xRead.ReadInnerXml()
                            Title = Regex.Replace(Title, "<.*?>", " ")
                            Title = Refine_XML_File_Simple(Title)

                        ElseIf xRead.Name = "LANGUAGE" Then
                            Language = xRead.ReadInnerXml()
                            Language = Regex.Replace(Language, "<.*?>", " ")

                            '   ElseIf xRead.Name = "CATEGORY" Then
                            '   Category = xRead.ReadInnerXml()
                            '   Category = Regex.Replace(Category, "<.*?>", " ")

                        ElseIf xRead.Name = "CITATION" Then
                            Citation = xRead.ReadInnerXml()
                            Citation = Regex.Replace(Citation, "<.*?>", " ")
                            Citation = Refine_XML_File_Simple(Citation)

                        ElseIf xRead.Name = "YEAR" Then
                            Year = xRead.ReadInnerXml()
                            Year = Regex.Replace(Year, "<.*?>", " ")

                        ElseIf xRead.Name = "AUTHOR" Then
                            Author = xRead.ReadInnerXml()
                            Author = Regex.Replace(Author, "<.*?>", " ")
                            Author = Refine_XML_File_Simple(Author)

                        ElseIf xRead.Name = "COUNTRY" Then
                            Country = xRead.ReadInnerXml()
                            Country = Regex.Replace(Country, "<.*?>", " ")

                        ElseIf xRead.Name = "SUBJECT" Then
                            Subject = xRead.ReadInnerXml()
                            Subject = Regex.Replace(Subject, "<.*?>", " ")
                            'Subject = Refine_XML_File_Simple(Subject)

                        ElseIf xRead.Name = "ARTICLE" Then
                            ArticleBody = xRead.ReadInnerXml()
                            ArticleBody = Regex.Replace(ArticleBody, "<.*?>", " ")
                            ArticleBody = Refine_XML_File_Simple(ArticleBody)

                        ElseIf xRead.Name = "FOOTNOTES" Then
                            FootNotes = xRead.ReadInnerXml()
                            FootNotes = Regex.Replace(FootNotes, "<.*?>", " ")
                            FootNotes = Refine_XML_File_Simple(FootNotes)
                        Else

                        End If
                End Select
            End While

            'Read Whole File For BooleanText 
            BooleanText = ReadXmlFile(Path)
            BooleanText = Regex.Replace(BooleanText, "<.*?>", " ")
            BooleanText = Refine_XML_File_Simple(BooleanText)
            ' Get Year 
            Year = ExtractTagData(Path, "YEAR")
            ' Get FootNote 
            FootNotes = ExtractTagData(Path, "FOOTNOTES")
            If FootNotes.Length > 1 Then
                FootNotes = Regex.Replace(FootNotes, "<.*?>", " ")
                FootNotes = Refine_XML_File_Simple(FootNotes)
            End If
        Catch ex As Exception
            StrError = ex.Message.ToString()
        Finally
            xRead.Close()
        End Try

    End Sub

    Public Function Refine_XML_File_Simple(ByVal sentence As String) As String
        Dim ReplacePattern As String = " "
        Dim SearchPattern As String = Nothing

        If sentence IsNot Nothing Then
            sentence = (((sentence)).ToLower()).Trim()
        End If
        ' double quotes
        If sentence IsNot Nothing Then
            sentence = sentence.Replace("'", " ")
        End If

        If sentence IsNot Nothing Then
            sentence = Replace(sentence, "+", "")
            sentence = Replace(sentence, "'", "")
            sentence = Replace(sentence, "/", "")
            sentence = Replace(sentence, "*", "")
            sentence = Replace(sentence, "$", "")
            sentence = Replace(sentence, "^", "")
            sentence = Replace(sentence, "(", "")
            sentence = Replace(sentence, ")", "")
            sentence = Replace(sentence, "&", "")
            sentence = Replace(sentence, "@", "")
            sentence = Replace(sentence, "#", "")
            sentence = Replace(sentence, "!", "")
            sentence = Replace(sentence, "~", "")
            sentence = Replace(sentence, "%", "")
            sentence = Replace(sentence, ".", "")
            sentence = Replace(sentence, ",", "")
            sentence = Replace(sentence, "<", "")
            sentence = Replace(sentence, ">", "")
            sentence = Replace(sentence, "?", "")
            sentence = Replace(sentence, "\", "")
            sentence = Replace(sentence, "|", "")
            sentence = Replace(sentence, "=", "")
            sentence = Replace(sentence, "-", "")
            sentence = Replace(sentence, "_", "")
            sentence = Replace(sentence, ";", "")
            sentence = Replace(sentence, ":", "")
            sentence = Replace(sentence, "  ", " ")
            sentence = Replace(sentence, "   ", " ")
            sentence = Replace(sentence, "    ", " ")
            sentence = Replace(sentence, "     ", " ")
            sentence = Replace(sentence, "      ", " ")
            sentence = Replace(sentence, "       ", " ")
            sentence = Replace(sentence, "        ", " ")
            sentence = Replace(sentence, "         ", " ")
            sentence = Replace(sentence, "          ", " ")
            sentence = Replace(sentence, "           ", " ")
        End If
        If sentence <> "" Then
            SearchPattern = "&em"
            sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

            SearchPattern = "&amp"
            sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)

            SearchPattern = "&nbsp"
            sentence = Regex.Replace(sentence, SearchPattern, ReplacePattern, RegexOptions.IgnoreCase)
        End If

        Return sentence
    End Function

    Public Function BuildQuery(ByVal xmlName As String) As String

        Dim Flg As String = ""
        Dim flgAli As String = ""
        Dim flgExistingData As String = ""

        Dim FormNoDoc As String = ""
        Dim SqlQuery As String = ""
        Dim DataFileName As String = xmlName
        Dim ObjDb As New ArticleInfo("ConnectionString")
        'validate Before Insert For Empty Tags ,title, author, Booleantext, citation

        If ValidateQuery() = False Then
            Return Flg = "Please check XML error " + DataFileName + ". Detail : Please Check Title, Author, Citation." & StrError & vbLf
            Exit Function
        End If

        'Check Article
        If ArticleBody.Length < 10 Then
            Return Flg = "Please check XML error " + DataFileName + ". Detail : Missing Article Tag" & StrError & vbLf
            Exit Function
        End If

        flgExistingData = ObjDb.isFileExist(DataFileName, "Reference_Article")

        If flgExistingData = False Then

            SqlQuery = "insert into Reference_Article "
            SqlQuery &= "(DATAFILENAME, TITLE , AUTHOR, LANGUAGE, SUBJECT,COUNTRY,CITATION,YEAR,FOOTNOTES,BOOLEANTEXT) "
            SqlQuery &= " values ('" & DataFileName & "' , '" & Title.Trim & "' , '" & Author.Trim() & "' , '" & Language.Trim() & "' "
            SqlQuery &= " , '" & Subject.Trim() & "' , '" & Country & "','" & Citation.Trim() & "' "
            SqlQuery &= " , '" & Year.Trim() & "' , '" & FootNotes & "' , '" & BooleanText.Trim() & "' )"

            ObjDb.AddRecord(SqlQuery)
            Flg = "Uploaded " + DataFileName + " Successfully" & vbLf

        Else 'flgExistingData=true

            SqlQuery = "Delete from Reference_Article where"
            SqlQuery += " DATAFILENAME= '" + DataFileName + "' "
            Flg = ObjDb.AddRecord(SqlQuery)

            If Flg Then
                Flg &= "*"
            End If

            SqlQuery = "insert into Reference_Article "
            SqlQuery &= "(DATAFILENAME, TITLE , AUTHOR, LANGUAGE, SUBJECT,COUNTRY,CITATION,YEAR,FOOTNOTES,BOOLEANTEXT) "
            SqlQuery &= " values ('" & DataFileName & "' , '" & Title.Trim & "' , '" & Author.Trim() & "' , '" & Language.Trim() & "' "
            SqlQuery &= " , '" & Subject.Trim() & "' , '" & Country & "','" & Citation.Trim() & "' "
            SqlQuery &= " , '" & Year.Trim() & "' , '" & FootNotes.Trim() & "' , '" & BooleanText.Trim() & "' )"

            ObjDb.AddRecord(SqlQuery)
            Flg = "Uploaded " + DataFileName + " Successfully" & vbLf
        End If

        Rest() ' clear all variable
        ObjDb = Nothing

        Return Flg

    End Function

    Private Function ReadXmlFile(ByVal DirFilePath As String) As String
        Dim FileContent As New System.Text.StringBuilder()
        Dim Result As String
        Try
            Dim R As XmlTextReader = New XmlTextReader(DirFilePath)
            Do While R.Read
                If R.Value <> "" Then
                    FileContent.Append(R.Value)
                End If
            Loop
        Catch Err As Exception
        Finally
            Result = FileContent.ToString
            FileContent = Nothing

        End Try
        Return Result
    End Function

    Private Function ExtractTagData(ByVal xmlPath As String, ByVal TagName As String) As String
        Dim TagInfo As String = ""
        Dim Info As New System.Text.StringBuilder()
        Dim Nodelst As XmlNodeList
        Dim XDoc As New XmlDocument()
        Try
            XDoc.Load(xmlPath)
            Dim i As Integer
            Nodelst = XDoc.GetElementsByTagName(TagName)
            For i = 0 To Nodelst.Count - 1
                TagInfo = Trim(Nodelst(i).InnerXml())
                If TagInfo <> "" Then
                    Info.Append(TagInfo & " ")
                End If
            Next i
        Catch Exp As Exception
            TagInfo = ""
        End Try
        TagInfo = Info.ToString
        If Len(TagInfo) = 0 Then
            TagInfo = "" ' not to send null
        End If
        Return TagInfo
    End Function

    Private Sub Rest()
        Title = ""
        Author = ""
        Language = ""
        Subject = ""
        Category = ""
        Country = ""
        FootNotes = ""
        BooleanText = ""
        ObjDb = Nothing
    End Sub

    Private Function ValidateQuery() As Boolean
        Dim Flg As Boolean = True
        If Title = "" Then
            Flg = False
        ElseIf BooleanText = "" Then
            Flg = False
        ElseIf Author = "" Then
            Flg = False
        ElseIf Citation = "" Then
            Flg = False
        End If
        Return Flg
    End Function
End Class
