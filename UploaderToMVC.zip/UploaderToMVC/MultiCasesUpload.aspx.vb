﻿Imports System.IO
Imports System.Xml
Imports elawKeyPassage

Public Class MultiCasesUpload
    Inherits System.Web.UI.Page
    Dim XmlFile As String
    Dim ClsUpload As New ClsCasesUpload("ConnectionString")
    Dim XmlExit As Boolean = False
    Dim DirPath As String
    Dim PdfPath As String = ""

    'Public Function ChangeCitation(ByVal strCitation As String) As String

    '    Dim result As String = ""
    '    Dim year As String = ""
    '    Dim 
    '    If strCitation.Length > 0 Then
    '        result = strCitation.Split({"[", "]"}, StringSplitOptions.None)
    '    End If

    'End Function

    'Public Sub GetNewCitation(ByVal strFileName As String)
    '    Dim xmlDoc As XmlDocument = New XmlDocument
    '    xmlDoc.Load(strFileName)

    '    Dim root As XmlNode = xmlDoc.DocumentElement
    '    Dim node As XmlNode = root.SelectSingleNode(root.Name & "//UNREPORTED_CITATION")

    '    Dim str As String = ""

    '    If node.InnerText.Length > 0 Then
    '        str = node.InnerText

    '    Else
    '        'do nothing 
    '    End If

    'End Sub

    'Public Function GetOldCitation(ByVal xmlFileName As String) As String

    'End Function

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
        Catch ex As Exception
            My.Computer.FileSystem.WriteAllText("C:\Elaw\Calculate_Execution_Timetest.txt", String.Join(vbCrLf, ex.Message), False)
        End Try
    End Sub

    Protected Sub btnValidate_Click(ByVal sender As Object, ByVal e As EventArgs)
        'created by Rozidee Ibrahim
        Dim filesColl As HttpFileCollection = Request.Files
        Dim i As Integer = 0
    End Sub

    Private Sub Case_Progression_Tag(ByVal XMLFileName As String)
        Dim xdoc As New XmlDocument
        ' xdoc.Load(XMLFileName)

        Dim strFromFile As String
        strFromFile = File.ReadAllText(XMLFileName)

        Dim TagInfo As String = ""
        Dim Nodelst As XmlNodeList

        Dim TagContent As String
        Dim Info As New System.Text.StringBuilder()

        Try
            xdoc.Load(XMLFileName)
            Dim i As Integer
            Nodelst = xdoc.GetElementsByTagName("CASE_PROGRESSION")
            For i = 0 To Nodelst.Count - 1
                TagContent = Trim(Nodelst(i).InnerXml())
                If TagContent <> "" Then
                    Info.Append(TagContent & " ")
                End If
            Next i
        Catch Exp As Exception

            TagContent = Exp.Message.ToString

        End Try

        TagInfo = Info.ToString

        If Len(TagInfo) = 0 Then
            TagInfo = "" ' not to send null
        Else
            TagInfo = Info.ToString
        End If

        If TagInfo.Length > 10 Then

            If TagInfo.Contains("[") And TagInfo.Contains("]") Then
                '=======> nothing to do with this file
                'Call ClsUpload.UploadCaseProgression()
            Else
                Try
                    Dim root As XmlElement = xdoc.DocumentElement
                    Dim node As XmlNode = root.SelectSingleNode("CASE_PROGRESSION")
                    root.RemoveChild(node)
                    xdoc.Save(XMLFileName)
                Catch ex As Exception
                End Try
            End If

        Else

        End If
    End Sub

    Public Function isGotContentCaseReference(ByVal strCaseProgression As String) As Boolean
        If strCaseProgression.Contains("[") And strCaseProgression.Contains("]") Then
            Return True
        Else
            Return False
        End If
    End Function
    ' ==== New declare by Rozidee on 13-09-2016 ======================================================>>>>>>

    Private Function Citation_Format_Change(ByVal CitationToChange As String, ByVal Format As String) As String
        Dim returnValue As String = ""
        Dim year As Integer
        Dim court As String
        Dim volume As Integer
        Dim pageno As Integer
        Select Case Format
            Case Is = "citation"
                Dim arrCitation As String() = CitationToChange.Split("_")

                If arrCitation.Count = 3 Then
                    court = arrCitation(0)
                    year = arrCitation(1)
                    pageno = arrCitation(2)
                    returnValue = "[" & year & "] " & court & " " & pageno

                ElseIf arrCitation.Count = 4 Then
                    court = arrCitation(0)
                    year = arrCitation(1)
                    volume = arrCitation(2)
                    pageno = arrCitation(3)
                    returnValue = "[" & year & "] " & volume & " " & court & " " & pageno

                Else
                    ' wrong or error format of citation
                End If

            Case Is = "filename"
                Dim newCitation As String = CitationToChange.Replace("[", "").Replace("]", " ")
                Dim arrCitation As String() = newCitation.Split(" ")

                If arrCitation.Count = 3 Then
                    year = arrCitation(0)
                    court = arrCitation(1)
                    pageno = arrCitation(2)
                ElseIf arrCitation.Count = 4 Then
                    year = arrCitation(0)
                    volume = arrCitation(1)
                    court = arrCitation(2)
                    pageno = arrCitation(3)
                Else
                    'wrong or error format citation
                End If
        End Select
        Return returnvalue
    End Function

    Private Sub GetUnreportedCitation(ByVal filePath As String)
        Try

            Dim unreportedPath As String = "C:\eLaw\eLaw_Data_Files\eLaw_Data_Files\cases\"
            Dim dir As String() = filePath.Split("\")
            Dim fileName As String = dir(dir.Count - 1)
            Dim reportedCitation As String = fileName.Replace(".xml", "").Replace(".XML", "")
            Dim strFromFile As String = File.ReadAllText(filePath)
            Dim unreportCitation As String = strFromFile.Split({"<UNREPORTED_CITATION>", "</UNREPORTED_CITATION>"}, StringSplitOptions.RemoveEmptyEntries)(1)

            If unreportCitation.Length > 0 Then
                Dim newFilePath As String = unreportedPath & unreportCitation & ".xml"
                fileName = fileName.Replace(".xml", "").Replace(".XML", "")
                'Call WriteNewCitation(newFilePath, Citation_Format_Change(fileName, "citation"))
            Else
                Exit Sub
            End If
        Catch ex As Exception

        End Try

        'Dim xmlDoc As New XmlDocument
        'xmlDoc.Load(fileName)

        'Dim root As XmlNode = xmlDoc.DocumentElement
        'Dim node As XmlNode = root.SelectSingleNode("UNREPORTED_CITATION")
        'Dim strNode As String

        'Try
        '    strNode = node.InnerText.ToString
        'Catch ex As Exception
        '    strNode = ""
        'End Try

        'If strNode.Length > 0 Then
        '    If File.Exists(unreportedPath & strNode & ".xml") Then
        '        Call WriteNewCitation(unreportedPath & strNode & ".xml", root.Name)
        '    End If
        'Else
        '    ' do nothing===========================
        'End If
    End Sub

    Private Sub WriteNewCitation(ByVal newFileName As String, ByVal newCitation As String)
        Dim replaceValue As String = ""
        Dim strFile As String = File.ReadAllText(newFileName)
        Dim strToWrite As String = ""

        If strFile.Contains("<REPORTED_CITATION>") And strFile.Contains("</REPORTED_CITATION>") Then
            Dim existingReportedCitation As String = strFile.Split({"<REPORTED_CITATION>", "</REPORTED_CITATION>"}, StringSplitOptions.RemoveEmptyEntries)(1)
            Dim counter As Integer = 0
            counter = existingReportedCitation.Count
            If counter > 0 Then
                If existingReportedCitation = newCitation Then
                    ' no need of update anything    
                Else ' existing is not same as new report citation inside reported_citation tag
                    strToWrite = strFile.Replace("<REPORTED_CITATION>" & existingReportedCitation & "</REPORTED_CITATION>", "<REPORTED_CITATION>" & newCitation & "</REPORTED_CITATION>")
                End If
            Else ' no citation inside of reported tag
                strToWrite = strFile.Replace("<REPORTED_CITATION></REPORTED_CITATION>", "<REPORTED_CITATION>" & newCitation & "</REPORTED_CITATION>")
            End If

        Else ' if there are no tag reported_tag inside of xml files
            replaceValue = "</OTHER_CITATION>" & Environment.NewLine & Environment.NewLine & "<REPORTED_CITATION>" & newCitation & "</REPORTED_CITATION>" & Environment.NewLine & Environment.NewLine
            strToWrite = strFile.Replace("</OTHER_CITATION>", replaceValue)
        End If

        File.WriteAllText(newFileName, strToWrite)

        'Dim fName As String = newFileName
        '' === MsgBox(fName & Environment.NewLine & File.Exists(fName) & Environment.NewLine & strToWrite)

        'If File.Exists(fName) = True Then

        '    Dim xmlDoc As New XmlDocument
        '    xmlDoc.Load(fName)
        '    Dim root As XmlNode = xmlDoc.DocumentElement
        '    Dim node As XmlNode

        '    ' Dim content As String
        '    Try
        '        node = root.SelectSingleNode("REPORTED_CITATION")
        '        'content = node.InnerText.ToString

        '        node.InnerText = strToWrite
        '        'xmlElement.InnerText = strToWrite
        '        'node.AppendChild(xmlElement)

        '    Catch ex As Exception
        '        Dim xmlElement As XmlElement = xmlDoc.CreateElement("REPORTED_CITATION")
        '        ' content = ""
        '        xmlElement.InnerText = strToWrite
        '        xmlDoc.AppendChild(xmlElement)

        '    End Try

        '    Dim writer As XmlTextWriter = New XmlTextWriter(fName, Encoding.UTF8)
        '    xmlDoc.Save(writer)
        'Else

        'End If
    End Sub
    'Dim connString As String = ConfigurationSettings.AppSettings("ConnectionString")
    Protected Sub btnUpload_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnUpload.Click
        'On Error Resume Next
        Dim FlgUploadJudge As String = ""
        Dim FlgUploadCouncel As String = ""
        Dim FlgUpload As String = ""
        Dim FlgCasesReferred As String = ""
        Dim flgLegislationReferred As String = ""
        Dim lstImg As IList(Of String)
        Dim StrImg As String = ""
        Dim flgUploadPDF As String = ""
        Dim flgCaseProgression As String = "" ' new declaration 

        Dim TempDir As String = "C:\eLaw\eLaw_Data_Files\eLaw_Data_Files\cases\"   ' exact location is : Server.MapPath("~/cases/")
        PdfPath = "C:\eLaw\eLaw_Data_Files\eLaw_Data_Files\pdf\"
        lblcheckupload.Text = ""

        Dim fileUploadState As Boolean = False
        Dim xmlFileCount As Integer 'xmlfile choosed to upload counting total of it

        If fu_file.HasFile Then
            fileUploadState = True
        Else
            fileUploadState = False
        End If

        If fileUploadState = True Then

            'Rozidee edited on 2016-08-04==========
            'previously input from fu_file changed to pFile get from pColl (HTTP FIle collection)

            Dim pColl As HttpFileCollection = Request.Files
            xmlFileCount = pColl.Count

            If xmlFileCount > 500 Then
                MsgBox("Exceeded maximum files allowed to be upload at the time", vbExclamation, "Maximum files detected")
                Exit Sub
            Else

                For i As Integer = 0 To pColl.Count - 1
                    Dim pFile As HttpPostedFile = pColl(i)
                    Dim fName As String = pFile.FileName
                    Dim FileExtension As String = Path.GetExtension(pFile.FileName)

                    ' function moved into new loop
                    If FileExtension = ".xml" Or FileExtension = ".pdf" Then

                        If FileExtension = ".pdf" Then
                            Dim CaseExist As Boolean = ClsUpload.IsCaseExist("CasesIndustrialCourt", pFile.FileName.Replace(".pdf", ".xml"))
                            If i = 0 Then
                                lblcheckupload.Text = "<b>" & i + 1 & ". " & fName & "</b><BR/>"
                            Else
                                lblcheckupload.Text &= "<b>" & i + 1 & ". " & fName & "</b><BR/>"
                            End If

                            '======>>>>> lblcheckupload.Text &= "Upload Status : "
                            If CaseExist = False Then
                                lblcheckupload.Text &= "<span style='color:red; font-weight:700;'>Upload Status : No XML for " & fName & " found. Please upload XML.</span><br>"
                                lblcheckupload.Text &= "Total page : Not Available"

                            Else
                                flgUploadPDF = ClsUpload.UploadPDFFileInfo(PdfPath & pFile.FileName)
                                If flgUploadPDF.Contains("Please check your") = False Then ' no error found in pdf 
                                    lblcheckupload.Text &= "<span style='color:green; font-weight:700;'>Upload Status : PDF for " & fName.Replace(".pdf", "") & " successfully uploaded.</span><br>"
                                    lblcheckupload.Text &= "Total page : " & flgUploadPDF
                                Else
                                    lblcheckupload.Text &= "<span style='color:red; font-weight:700;'>Upload Status : PDF for " & fName.Replace(".pdf", "") & " failed to uploaded. PLEASE CHECK THE PDF AGAIN</span><br>"
                                    lblcheckupload.Text &= "Total page : Not Available"
                                End If

                                'lblcheckupload.Text &= "<hr/><br/>"
                                'lblcheckupload.Text &= "xxxxx"
                            End If


                            pFile.SaveAs(PdfPath & pFile.FileName)
                            Dim info As FileInfo
                            Dim length As Long

                            Try
                                info = New FileInfo(PdfPath & pFile.FileName)
                                length = info.Length
                            Catch ex As Exception
                                length = 0
                            End Try

                            'lblcheckupload.Text &= "<hr/>" 'flgUploadPDF & "<span color:Green; font-weight:700;>Pdf File Uploaded Successfully. </span>"

                        Else '========================XML FILES SELECT TO UPLOAD==================

                            '  ClsCasesUpload.FileXmlToClass = ""
                            '  ClsCasesUpload.FileNameToClass = ""
                            '  ClsUpload = Nothing
                            '  reset imgtag
                            StrImg = Nothing
                            DirPath = "C:\eLaw\eLaw_Data_Files\eLaw_Data_Files\cases\" & pFile.FileName

                            ClsCasesUpload.FileXmlToClass = DirPath
                            ClsCasesUpload.FileNameToClass = pFile.FileName

                            XmlFile = pFile.FileName
                            XmlExit = ClsUpload.IsXmlExit(DirPath)

                            pFile.SaveAs(DirPath)

                            FlgUpload = ClsUpload.UploadCase()
                            If FlgUpload.Contains("Please Check Xml File Citation") Then
                                lblcheckupload.Text &= "<br/><b>" & i + 1 & ". File Name : " & XmlFile & "</b><br/>Upload Status : <span style='color:red; font-weight:700;'>Failed</span>. Detail : " & FlgUpload & "<br/>"
 
                            Else
                                If FlgUpload.Contains("                                                                                                                                                    ") Then
                                    lblcheckupload.Text &= "<br/><b>" & i + 1 & ".File Name : " & XmlFile & "<br/>Upload Status : <span style='color:red; font-weight:700;'>Failed</span>. Detail : " & FlgUpload & "<br/>"

                                Else
                                    '===================================NO ERROR FOUND DURING UPLOAD PROCESS===================
                                    '=================================================== abdo subjectindex
                                    Dim iistr As Boolean = ClsUpload.UploadSubjectIndex()
                                    '=================================================== end of abdo subjectindex 

                                    'If FlgUpload.IndexOf("Please Check Xml File Error is") > -1 Then
                                    '    lblcheckupload.Text &= "<br>File Name : " & XmlFile & "<br>Upload Status : " & FlgUpload
                                    '    'Exit Sub    'skip upload if detect any error
                                    'End If

                                    'rozidee edit
                                    '======================
                                    'edit by Rozidee on 04-08-2016

                                    lblcheckupload.Text &= "<br/><b>" & i + 1 & ". File Name : " & XmlFile & "</b><br/>Case : " & FlgUpload & "<br/>"

                                    flgCaseProgression = ClsUpload.UploadCaseProgression()
                                    Dim CaseProgressionList As String = ClsCasesUpload.ListOfCaseProgression

                                    If CaseProgressionList.Length > 0 Then
                                        lblcheckupload.Text &= "<br/><u>Case Progression</u> : <span style='color:Green; font-weight:700;'>YES</span><br/>" & CaseProgressionList
                                    Else
                                        lblcheckupload.Text &= "<br/><u>Case Progression</u> : <span style='color:red; font-weight:700;'>NO</span><br/>"
                                    End If

                                    'FlgCasesReferred = ClsUpload.UploadCaseReferred()
                                    'lblcheckupload.Text &= "<br><u>Case Referred</u> : <br/>" & FlgCasesReferred

                                    'flgLegislationReferred = ClsUpload.UploadLegislationReferred()
                                    'lblcheckupload.Text &= "<br/><br/><u>Legislation Referred</u> : " & flgLegislationReferred & "<br/>"

                                    'START INDEXING PROCESS
                                    'Dim indexDir As String = "C:\eLaw\elawCaseIndex"
                                    'Dim indexObj As New elawKeyPassage.elawKPMain(TempDir, indexDir, connString, XmlFile)
                                    'Dim AddToDB = indexObj.StartIndex()
                                    'Response.Write(AddToDB)

                                    lblcheckupload.Text &= "<br/><br/>Index Status : " & ClsCasesUpload.strIndexStatus & "<br/>"



                                    '''''''''  =====IMAGE SECTION====================
                                    lstImg = ClsUpload.GetImgTag()

                                    If lstImg.Count Then
                                        UploadPhoto.Visible = True
                                    Else
                                        UploadPhoto.Visible = False
                                    End If

                                    If lstImg.Count Then
                                        StrImg = String.Join(" , ", lstImg.ToArray())
                                        lblcheckupload.Text &= "<br><span style='color:Green; font-weight:700;'>Images available and need to be upload: </span> <br>" & StrImg
                                        'UploadPhoto.Visible = True

                                    Else
                                        lblcheckupload.Text &= "<br><span style='color:red; font-weight:700;'> No Images available For This File</span> <br>" & StrImg
                                        'UploadPhoto.Visible = False
                                    End If

                                    ' lblcheckupload.Text &= "<hr/>"
                                    '===================================NO ERROR FOUND DURING UPLOAD PROCESS===================
                                    'lblcheckupload.Text &= "<br/>File Name : " & XmlFile & "<br/>Upload Status : Successfully Upload. "
                                End If
                            End If
                            '' New Counsel strcture - Ali
                            lblcheckupload.Text &= "<br>" & ClsUpload.AddingCounselToDB(DirPath)
                            ' CUT FROM HERE>>>>>
                            ' CUT UNTIL HERE>>>>>

                            ' ClsCasesUpload.FileXmlToClass = ""
                            'ClsCasesUpload.FileNameToClass = ""
                            'ClsUpload = Nothing
                        End If
                        lblcheckupload.Text &= "<hr/>"
                    Else
                        lblcheckupload.Text = "<span style='color:red; font-weight:700;'>Upload only file as Xml. </span>"
                    End If

SkipToNextFile:
                    '========================================= lblcheckupload.Text &= "<hr/>"

                    '========================================= IMAGE SECTION ================================================
                Next
                'for display total count files uploaded
                lblUploaded.Text = "Upload Information(s) <br> "
                lblUploaded.Text &= "Total files Upload : " & pColl.Count & "<br>"
            End If
        Else
            lblcheckupload.Text = "<span color:Red; font-weight:700;>Please Select files to upload </span>"
        End If
    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button1.Click ' image upload

        Dim filepath As String = "C:\eLaw\eLaw-Images\case_notes\cases"
        Dim uploadedFiles As HttpFileCollection = Request.Files
        Dim FileExtension As String
        Span1.Text = String.Empty

        For i As Integer = 0 To uploadedFiles.Count - 1
            Dim userPostedFile As HttpPostedFile = uploadedFiles(i)
            Try
                If userPostedFile.ContentLength > 0 Then
                    FileExtension = Path.GetExtension(userPostedFile.FileName)
                    Span1.Text += "<u>File #" & (i + 1) & "</u><br>"
                    Span1.Text += "File Content Type: " & userPostedFile.ContentType & "  --" & FileExtension & "<br>"
                    Span1.Text += "File Size: " & userPostedFile.ContentLength & "kb<br>"
                    Span1.Text += "File Name: " & userPostedFile.FileName & "<br>"

                    If FileExtension.ToLower() = ".png" Or FileExtension.ToLower() = ".jpg" Or FileExtension.ToLower() = ".jpeg" Then
                        userPostedFile.SaveAs(filepath & "\" & Path.GetFileName(userPostedFile.FileName))
                        Span1.Text &= " Uploaded"
                    Else
                        Span1.Text &= "Only image file(s) are allowed to be upload"
                    End If
                    'Span1.Text &= "Location where saved: " & filepath + "\" & Path.GetFileName(userPostedFile.FileName) & "<p>"

                End If

            Catch Ex As Exception
                Span1.Text &= "Error: <br>" & Ex.Message
                My.Computer.FileSystem.WriteAllText("C:\Elaw\Calculate_Execution_Timetest.txt", String.Join(vbCrLf, Ex.Message), False)

            End Try
        Next
    End Sub

End Class
